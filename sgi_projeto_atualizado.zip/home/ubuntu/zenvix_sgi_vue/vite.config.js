import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'
import { VitePWA } from 'vite-plugin-pwa'

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [
    vue(),
    VitePWA({
      registerType: 'autoUpdate', // Or 'prompt' for user confirmation
      includeAssets: ['favicon.ico', 'apple-touch-icon.png', 'masked-icon.svg'], // Add necessary icons
      manifest: {
        // Assuming manifest.json is in the public folder or use the object directly
        // If manifest.json is in /public, VitePWA might pick it up automatically
        // Or define it here explicitly:
        name: 'ZENVIX SGI',
        short_name: 'ZENVIX',
        description: 'Sistema de Gestão em Segurança e Saúde no Trabalho',
        theme_color: '#005f73', // Match primary color
        background_color: '#ffffff',
        display: 'standalone',
        scope: '/',
        start_url: '/',
        icons: [
          // Define icons based on files in public/assets/icons (or create them)
          {
            src: '/assets/icons/icon-192x192.png', // Example path - ensure icons exist
            sizes: '192x192',
            type: 'image/png'
          },
          {
            src: '/assets/icons/icon-512x512.png', // Example path - ensure icons exist
            sizes: '512x512',
            type: 'image/png'
          },
          {
            src: '/assets/icons/icon-512x512-maskable.png', // Example maskable icon
            sizes: '512x512',
            type: 'image/png',
            purpose: 'maskable'
          }
        ]
      },
      // Optional: Service worker configuration
      workbox: {
        globPatterns: ['**/*.{js,css,html,ico,png,svg,vue}'], // Files to cache
        runtimeCaching: [
          {
            urlPattern: /^https?:\/\/cdnjs\.cloudflare\.com\/.*/i, // Cache FontAwesome
            handler: 'CacheFirst',
            options: {
              cacheName: 'fontawesome-cache',
              expiration: {
                maxEntries: 10,
                maxAgeSeconds: 60 * 60 * 24 * 365 // <== 365 days
              },
              cacheableResponse: {
                statuses: [0, 200]
              }
            }
          },
          {
            // Example: Cache API calls (use NetworkFirst or StaleWhileRevalidate)
            urlPattern: /^\/api\/.*/i, // Adjust to your API endpoint pattern
            handler: 'NetworkFirst', // Or 'StaleWhileRevalidate'
            options: {
              cacheName: 'api-cache',
              expiration: {
                maxEntries: 50,
                maxAgeSeconds: 60 * 60 * 24 // 1 day
              },
              cacheableResponse: {
                statuses: [0, 200]
              }
            }
          }
        ]
      }
    })
  ],
  // Optional: Configure server for development (e.g., proxy API requests)
  server: {
    port: 5173, // Default Vite port
    // proxy: {
    //   '/api': {
    //     target: 'http://your-backend-api.com',
    //     changeOrigin: true,
    //     rewrite: (path) => path.replace(/^\/api/, '')
    //   }
    // }
  }
})

