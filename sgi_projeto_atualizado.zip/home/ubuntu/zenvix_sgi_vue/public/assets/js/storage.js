/**
 * ZENVIX SGI - Módulo de Armazenamento de Dados
 * 
 * Este arquivo contém funções para gerenciar o armazenamento e recuperação de dados
 * usando LocalStorage e IndexedDB, garantindo persistência entre sessões.
 */

// Namespace para evitar conflitos
const STORAGE = {
    // Configurações
    config: {
        dbName: 'soc_sst_db',
        dbVersion: 1,
        stores: {
            funcionarios: { keyPath: 'id', autoIncrement: true },
            empresas: { keyPath: 'id', autoIncrement: true },
            exames: { keyPath: 'id', autoIncrement: true },
            treinamentos: { keyPath: 'id', autoIncrement: true },
            epis: { keyPath: 'id', autoIncrement: true },
            documentos: { keyPath: 'id', autoIncrement: true },
            cipa: { keyPath: 'id', autoIncrement: true },
            auditorias: { keyPath: 'id', autoIncrement: true },
            usuarios: { keyPath: 'id', autoIncrement: true }
        }
    },
    
    // Referência ao banco de dados
    db: null,
    
    /**
     * Inicializa o módulo de armazenamento
     * @returns {Promise} Promessa que resolve quando o banco de dados está pronto
     */
    init: function() {
        console.log('Inicializando módulo de armazenamento...');
        
        // Verificar suporte a IndexedDB
        if (!window.indexedDB) {
            console.error('Seu navegador não suporta IndexedDB. Algumas funcionalidades podem não funcionar corretamente.');
            return Promise.reject('IndexedDB não suportado');
        }
        
        // Abrir/criar banco de dados
        return new Promise((resolve, reject) => {
            const request = indexedDB.open(this.config.dbName, this.config.dbVersion);
            
            // Criar ou atualizar estrutura do banco
            request.onupgradeneeded = (event) => {
                const db = event.target.result;
                
                // Criar object stores
                for (const storeName in this.config.stores) {
                    if (!db.objectStoreNames.contains(storeName)) {
                        const storeConfig = this.config.stores[storeName];
                        const store = db.createObjectStore(storeName, storeConfig);
                        
                        // Adicionar índices conforme necessário
                        switch (storeName) {
                            case 'funcionarios':
                                store.createIndex('nome', 'nome', { unique: false });
                                store.createIndex('cpf', 'cpf', { unique: true });
                                break;
                            case 'empresas':
                                store.createIndex('nome', 'nome', { unique: false });
                                store.createIndex('cnpj', 'cnpj', { unique: true });
                                break;
                            case 'exames':
                                store.createIndex('funcionarioId', 'funcionarioId', { unique: false });
                                store.createIndex('data', 'data', { unique: false });
                                break;
                            case 'treinamentos':
                                store.createIndex('funcionarioId', 'funcionarioId', { unique: false });
                                store.createIndex('data', 'data', { unique: false });
                                break;
                            case 'usuarios':
                                store.createIndex('username', 'username', { unique: true });
                                break;
                        }
                    }
                }
                
                console.log('Estrutura do banco de dados criada/atualizada.');
            };
            
            // Sucesso na abertura do banco
            request.onsuccess = (event) => {
                this.db = event.target.result;
                console.log('Banco de dados aberto com sucesso.');
                
                // Verificar se há dados iniciais
                this.verificarDadosIniciais().then(() => {
                    resolve(this.db);
                });
            };
            
            // Erro na abertura do banco
            request.onerror = (event) => {
                console.error('Erro ao abrir banco de dados:', event.target.error);
                reject(event.target.error);
            };
        });
    },
    
    /**
     * Verifica se existem dados iniciais e os cria se necessário
     * @returns {Promise} Promessa que resolve quando a verificação é concluída
     */
    verificarDadosIniciais: function() {
        return new Promise((resolve) => {
            // Verificar se já existem usuários
            this.count('usuarios').then((count) => {
                if (count === 0) {
                    console.log('Criando dados iniciais...');
                    
                    // Criar usuário admin
                    const adminUser = {
                        username: 'admin',
                        password: this.hashPassword('admin123'), // Em produção, usar bcrypt ou similar
                        nome: 'Administrador',
                        email: 'admin@exemplo.com',
                        role: 'admin',
                        ativo: true,
                        dataCriacao: new Date().toISOString()
                    };
                    
                    // Criar usuário técnico
                    const tecnicoUser = {
                        username: 'tecnico',
                        password: this.hashPassword('tecnico123'),
                        nome: 'Técnico SST',
                        email: 'tecnico@exemplo.com',
                        role: 'tecnico',
                        ativo: true,
                        dataCriacao: new Date().toISOString()
                    };
                    
                    // Criar usuário comum
                    const usuarioUser = {
                        username: 'usuario',
                        password: this.hashPassword('usuario123'),
                        nome: 'Usuário Comum',
                        email: 'usuario@exemplo.com',
                        role: 'usuario',
                        ativo: true,
                        dataCriacao: new Date().toISOString()
                    };
                    
                    // Adicionar usuários
                    Promise.all([
                        this.add('usuarios', adminUser),
                        this.add('usuarios', tecnicoUser),
                        this.add('usuarios', usuarioUser)
                    ]).then(() => {
                        console.log('Usuários iniciais criados.');
                        
                        // Criar empresas de exemplo
                        const empresas = [
                            {
                                nome: 'Empresa ABC Ltda',
                                cnpj: '12.345.678/0001-90',
                                endereco: 'Rua Exemplo, 123',
                                cidade: 'São Paulo',
                                estado: 'SP',
                                telefone: '(11) 1234-5678',
                                email: 'contato@empresaabc.com',
                                responsavel: 'João Silva',
                                ativo: true
                            },
                            {
                                nome: 'Indústria XYZ S.A.',
                                cnpj: '98.765.432/0001-10',
                                endereco: 'Av. Industrial, 456',
                                cidade: 'Campinas',
                                estado: 'SP',
                                telefone: '(19) 8765-4321',
                                email: 'contato@industriaxyz.com',
                                responsavel: 'Maria Oliveira',
                                ativo: true
                            },
                            {
                                nome: 'Comércio 123 Ltda',
                                cnpj: '45.678.901/0001-23',
                                endereco: 'Rua Comercial, 789',
                                cidade: 'Rio de Janeiro',
                                estado: 'RJ',
                                telefone: '(21) 2345-6789',
                                email: 'contato@comercio123.com',
                                responsavel: 'Carlos Santos',
                                ativo: true
                            }
                        ];
                        
                        // Adicionar empresas
                        const empresasPromises = empresas.map(empresa => this.add('empresas', empresa));
                        
                        Promise.all(empresasPromises).then(() => {
                            console.log('Empresas de exemplo criadas.');
                            
                            // Criar funcionários de exemplo
                            this.getAll('empresas').then((empresasDb) => {
                                const funcionarios = [
                                    {
                                        nome: 'João Silva',
                                        cpf: '123.456.789-00',
                                        dataNascimento: '1985-05-15',
                                        cargo: 'Operador de Máquina',
                                        setor: 'Produção',
                                        dataAdmissao: '2020-01-10',
                                        empresaId: empresasDb[0].id,
                                        ativo: true
                                    },
                                    {
                                        nome: 'Maria Oliveira',
                                        cpf: '987.654.321-00',
                                        dataNascimento: '1990-08-22',
                                        cargo: 'Analista de Qualidade',
                                        setor: 'Qualidade',
                                        dataAdmissao: '2019-03-15',
                                        empresaId: empresasDb[0].id,
                                        ativo: true
                                    },
                                    {
                                        nome: 'Carlos Santos',
                                        cpf: '456.789.123-00',
                                        dataNascimento: '1982-11-30',
                                        cargo: 'Técnico de Segurança',
                                        setor: 'SST',
                                        dataAdmissao: '2018-06-05',
                                        empresaId: empresasDb[1].id,
                                        ativo: true
                                    },
                                    {
                                        nome: 'Ana Pereira',
                                        cpf: '789.123.456-00',
                                        dataNascimento: '1988-04-12',
                                        cargo: 'Auxiliar Administrativo',
                                        setor: 'Administrativo',
                                        dataAdmissao: '2021-02-20',
                                        empresaId: empresasDb[2].id,
                                        ativo: true
                                    }
                                ];
                                
                                // Adicionar funcionários
                                const funcionariosPromises = funcionarios.map(funcionario => this.add('funcionarios', funcionario));
                                
                                Promise.all(funcionariosPromises).then(() => {
                                    console.log('Funcionários de exemplo criados.');
                                    resolve();
                                });
                            });
                        });
                    });
                } else {
                    console.log('Dados iniciais já existem.');
                    resolve();
                }
            });
        });
    },
    
    /**
     * Hash simples para senhas (apenas para simulação)
     * Em produção, usar bcrypt ou similar
     * @param {string} password - Senha a ser hasheada
     * @returns {string} Senha hasheada
     */
    hashPassword: function(password) {
        // Simulação simples de hash (NÃO USAR EM PRODUÇÃO)
        let hash = 0;
        for (let i = 0; i < password.length; i++) {
            const char = password.charCodeAt(i);
            hash = ((hash << 5) - hash) + char;
            hash = hash & hash; // Converter para 32bit integer
        }
        return 'hashed_' + hash.toString(16);
    },
    
    /**
     * Adiciona um item a uma store
     * @param {string} storeName - Nome da store
     * @param {Object} item - Item a ser adicionado
     * @returns {Promise} Promessa que resolve com o ID do item adicionado
     */
    add: function(storeName, item) {
        return new Promise((resolve, reject) => {
            if (!this.db) {
                reject('Banco de dados não inicializado');
                return;
            }
            
            try {
                const transaction = this.db.transaction([storeName], 'readwrite');
                const store = transaction.objectStore(storeName);
                const request = store.add(item);
                
                request.onsuccess = (event) => {
                    resolve(event.target.result);
                };
                
                request.onerror = (event) => {
                    console.error(`Erro ao adicionar item em ${storeName}:`, event.target.error);
                    reject(event.target.error);
                };
            } catch (error) {
                console.error(`Erro ao adicionar item em ${storeName}:`, error);
                reject(error);
            }
        });
    },
    
    /**
     * Atualiza um item em uma store
     * @param {string} storeName - Nome da store
     * @param {Object} item - Item a ser atualizado (deve conter o ID)
     * @returns {Promise} Promessa que resolve quando o item é atualizado
     */
    update: function(storeName, item) {
        return new Promise((resolve, reject) => {
            if (!this.db) {
                reject('Banco de dados não inicializado');
                return;
            }
            
            try {
                const transaction = this.db.transaction([storeName], 'readwrite');
                const store = transaction.objectStore(storeName);
                const request = store.put(item);
                
                request.onsuccess = () => {
                    resolve();
                };
                
                request.onerror = (event) => {
                    console.error(`Erro ao atualizar item em ${storeName}:`, event.target.error);
                    reject(event.target.error);
                };
            } catch (error) {
                console.error(`Erro ao atualizar item em ${storeName}:`, error);
                reject(error);
            }
        });
    },
    
    /**
     * Remove um item de uma store
     * @param {string} storeName - Nome da store
     * @param {number|string} id - ID do item a ser removido
     * @returns {Promise} Promessa que resolve quando o item é removido
     */
    remove: function(storeName, id) {
        return new Promise((resolve, reject) => {
            if (!this.db) {
                reject('Banco de dados não inicializado');
                return;
            }
            
            try {
                const transaction = this.db.transaction([storeName], 'readwrite');
                const store = transaction.objectStore(storeName);
                const request = store.delete(id);
                
                request.onsuccess = () => {
                    resolve();
                };
                
                request.onerror = (event) => {
                    console.error(`Erro ao remover item de ${storeName}:`, event.target.error);
                    reject(event.target.error);
                };
            } catch (error) {
                console.error(`Erro ao remover item de ${storeName}:`, error);
                reject(error);
            }
        });
    },
    
    /**
     * Obtém um item de uma store pelo ID
     * @param {string} storeName - Nome da store
     * @param {number|string} id - ID do item
     * @returns {Promise} Promessa que resolve com o item ou null se não encontrado
     */
    get: function(storeName, id) {
        return new Promise((resolve, reject) => {
            if (!this.db) {
                reject('Banco de dados não inicializado');
                return;
            }
            
            try {
                const transaction = this.db.transaction([storeName], 'readonly');
                const store = transaction.objectStore(storeName);
                const request = store.get(id);
                
                request.onsuccess = (event) => {
                    resolve(event.target.result);
                };
                
                request.onerror = (event) => {
                    console.error(`Erro ao obter item de ${storeName}:`, event.target.error);
                    reject(event.target.error);
                };
            } catch (error) {
                console.error(`Erro ao obter item de ${storeName}:`, error);
                reject(error);
            }
        });
    },
    
    /**
     * Obtém todos os itens de uma store
     * @param {string} storeName - Nome da store
     * @returns {Promise} Promessa que resolve com array de itens
     */
    getAll: function(storeName) {
        return new Promise((resolve, reject) => {
            if (!this.db) {
                reject('Banco de dados não inicializado');
                return;
            }
            
            try {
                const transaction = this.db.transaction([storeName], 'readonly');
                const store = transaction.objectStore(storeName);
                const request = store.getAll();
                
                request.onsuccess = (event) => {
                    resolve(event.target.result);
                };
                
                request.onerror = (event) => {
                    console.error(`Erro ao obter itens de ${storeName}:`, event.target.error);
                    reject(event.target.error);
                };
            } catch (error) {
                console.error(`Erro ao obter itens de ${storeName}:`, error);
                reject(error);
            }
        });
    },
    
    /**
     * Conta o número de itens em uma store
     * @param {string} storeName - Nome da store
     * @returns {Promise} Promessa que resolve com o número de itens
     */
    count: function(storeName) {
        return new Promise((resolve, reject) => {
            if (!this.db) {
                reject('Banco de dados não inicializado');
                return;
            }
            
            try {
                const transaction = this.db.transaction([storeName], 'readonly');
                const store = transaction.objectStore(storeName);
                const request = store.count();
                
                request.onsuccess = (event) => {
                    resolve(event.target.result);
                };
                
                request.onerror = (event) => {
                    console.error(`Erro ao contar itens em ${storeName}:`, event.target.error);
                    reject(event.target.error);
                };
            } catch (error) {
                console.error(`Erro ao contar itens em ${storeName}:`, error);
                reject(error);
            }
        });
    },
    
    /**
     * Busca itens por um índice específico
     * @param {string} storeName - Nome da store
     * @param {string} indexName - Nome do índice
     * @param {any} value - Valor a ser buscado
     * @returns {Promise} Promessa que resolve com array de itens encontrados
     */
    getByIndex: function(storeName, indexName, value) {
        return new Promise((resolve, reject) => {
            if (!this.db) {
                reject('Banco de dados não inicializado');
                return;
            }
            
            try {
                const transaction = this.db.transaction([storeName], 'readonly');
                const store = transaction.objectStore(storeName);
                const index = store.index(indexName);
                const request = index.getAll(value);
                
                request.onsuccess = (event) => {
                    resolve(event.target.result);
                };
                
                request.onerror = (event) => {
                    console.error(`Erro ao buscar itens por índice em ${storeName}:`, event.target.error);
                    reject(event.target.error);
                };
            } catch (error) {
                console.error(`Erro ao buscar itens por índice em ${storeName}:`, error);
                reject(error);
            }
        });
    },
    
    /**
     * Salva um valor no localStorage
     * @param {string} key - Chave para o valor
     * @param {any} value - Valor a ser salvo (será convertido para JSON)
     */
    setLocalItem: function(key, value) {
        try {
            localStorage.setItem(key, JSON.stringify(value));
        } catch (error) {
            console.error('Erro ao salvar no localStorage:', error);
        }
    },
    
    /**
     * Obtém um valor do localStorage
     * @param {string} key - Chave do valor
     * @param {any} defaultValue - Valor padrão se a chave não existir
     * @returns {any} Valor obtido ou valor padrão
     */
    getLocalItem: function(key, defaultValue = null) {
        try {
            const item = localStorage.getItem(key);
            return item ? JSON.parse(item) : defaultValue;
        } catch (error) {
            console.error('Erro ao obter do localStorage:', error);
            return defaultValue;
        }
    },
    
    /**
     * Remove um valor do localStorage
     * @param {string} key - Chave do valor a ser removido
     */
    removeLocalItem: function(key) {
        try {
            localStorage.removeItem(key);
        } catch (error) {
            console.error('Erro ao remover do localStorage:', error);
        }
    },
    
    /**
     * Verifica se um usuário está autenticado
     * @returns {boolean} True se autenticado, false caso contrário
     */
    isAuthenticated: function() {
        return !!this.getLocalItem('auth_token');
    },
    
    /**
     * Obtém informações do usuário atual
     * @returns {Object|null} Objeto com informações do usuário ou null se não autenticado
     */
    getCurrentUser: function() {
        return this.getLocalItem('current_user');
    },
    
    /**
     * Realiza login de usuário
     * @param {string} username - Nome de usuário
     * @param {string} password - Senha
     * @returns {Promise} Promessa que resolve com o usuário se autenticado
     */
    login: function(username, password) {
        return new Promise((resolve, reject) => {
            if (!this.db) {
                reject('Banco de dados não inicializado');
                return;
            }
            
            try {
                const transaction = this.db.transaction(['usuarios'], 'readonly');
                const store = transaction.objectStore('usuarios');
                const index = store.index('username');
                const request = index.get(username);
                
                request.onsuccess = (event) => {
                    const user = event.target.result;
                    
                    if (!user) {
                        reject('Usuário não encontrado');
                        return;
                    }
                    
                    if (!user.ativo) {
                        reject('Usuário inativo');
                        return;
                    }
                    
                    // Verificar senha (em produção, usar bcrypt.compare ou similar)
                    if (user.password === this.hashPassword(password)) {
                        // Gerar token (simulado)
                        const token = 'token_' + Math.random().toString(36).substr(2) + Date.now().toString(36);
                        
                        // Salvar token e usuário
                        this.setLocalItem('auth_token', token);
                        
                        // Remover senha antes de salvar no localStorage
                        const userInfo = { ...user };
                        delete userInfo.password;
                        this.setLocalItem('current_user', userInfo);
                        
                        // Registrar último login
                        user.ultimoLogin = new Date().toISOString();
                        this.update('usuarios', user);
                        
                        resolve(userInfo);
                    } else {
                        reject('Senha incorreta');
                    }
                };
                
                request.onerror = (event) => {
                    console.error('Erro ao buscar usuário:', event.target.error);
                    reject('Erro ao buscar usuário');
                };
            } catch (error) {
                console.error('Erro ao realizar login:', error);
                reject('Erro ao realizar login');
            }
        });
    },
    
    /**
     * Realiza logout do usuário
     */
    logout: function() {
        this.removeLocalItem('auth_token');
        this.removeLocalItem('current_user');
    }
};

// Inicializar módulo quando o DOM estiver carregado
document.addEventListener('DOMContentLoaded', function() {
    STORAGE.init().catch(error => {
        console.error('Erro ao inicializar módulo de armazenamento:', error);
    });
});
