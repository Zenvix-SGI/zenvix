/**
 * ZENVIX SGI - Módulo Mapa de Riscos
 * 
 * Este arquivo contém funções para gerenciar o Mapa de Riscos, permitindo upload de imagens ou criação visual simples.
 */

// Namespace para evitar conflitos
const MAPA_RISCOS = {
    // Configurações
    config: {
        tiposRisco: [
            { nome: 'Físico', cor: '#00FF00', icone: 'fas fa-radiation' },
            { nome: 'Químico', cor: '#FF0000', icone: 'fas fa-flask' },
            { nome: 'Biológico', cor: '#A020F0', icone: 'fas fa-biohazard' },
            { nome: 'Ergonômico', cor: '#FFFF00', icone: 'fas fa-user-tie' },
            { nome: 'Acidentes', cor: '#0000FF', icone: 'fas fa-car-crash' }
        ],
        tamanhosRisco: [
            { nome: 'Pequeno', valor: 1 },
            { nome: 'Médio', valor: 2 },
            { nome: 'Grande', valor: 3 }
        ]
    },
    
    // Estado
    state: {
        mapaAtual: null, // ID do mapa sendo editado
        mapaData: null,  // Dados do mapa (imagem ou elementos visuais)
        modoEdicao: false,
        ferramentaSelecionada: null,
        corSelecionada: null,
        tamanhoSelecionado: null,
        desenhando: false,
        ultimoX: 0,
        ultimoY: 0
    },
    
    /**
     * Inicializa o módulo Mapa de Riscos
     */
    init: function() {
        console.log('Inicializando módulo Mapa de Riscos...');
        
        // Verificar se usuário está autenticado
        if (!STORAGE.isAuthenticated()) {
            console.warn('Usuário não autenticado. Redirecionando para login...');
            window.location.href = 'login.html';
            return;
        }
        
        // Inicializar componentes
        this.initComponents();
        
        // Configurar eventos
        this.setupEvents();
        
        // Carregar dados iniciais
        this.carregarMapas();
        
        console.log('Módulo Mapa de Riscos inicializado.');
    },
    
    /**
     * Inicializa componentes da interface
     */
    initComponents: function() {
        // Preencher paleta de cores e tamanhos
        const paletaCores = document.getElementById('paletaCores');
        const paletaTamanhos = document.getElementById('paletaTamanhos');
        
        if (paletaCores) {
            this.config.tiposRisco.forEach(tipo => {
                const button = document.createElement('button');
                button.className = 'btn-paleta';
                button.style.backgroundColor = tipo.cor;
                button.setAttribute('data-cor', tipo.cor);
                button.setAttribute('title', tipo.nome);
                button.innerHTML = `<i class="${tipo.icone}"></i>`;
                paletaCores.appendChild(button);
            });
        }
        
        if (paletaTamanhos) {
            this.config.tamanhosRisco.forEach(tamanho => {
                const button = document.createElement('button');
                button.className = 'btn-paleta';
                button.setAttribute('data-tamanho', tamanho.valor);
                button.setAttribute('title', tamanho.nome);
                button.innerHTML = `<span style="font-size: ${tamanho.valor * 0.5 + 0.5}em;">●</span>`;
                paletaTamanhos.appendChild(button);
            });
        }
        
        // Carregar setores/locais
        STORAGE.getAll('setores').then(setores => {
            const setorSelect = document.getElementById('setorMapa');
            if (setorSelect) {
                setorSelect.innerHTML = '<option value="">Selecione...</option>';
                setores.sort((a, b) => a.nome.localeCompare(b.nome));
                setores.forEach(setor => {
                    const option = document.createElement('option');
                    option.value = setor.id;
                    option.textContent = setor.nome;
                    setorSelect.appendChild(option);
                });
            }
        }).catch(error => {
            console.error('Erro ao carregar setores:', error);
        });
    },
    
    /**
     * Configura eventos da interface
     */
    setupEvents: function() {
        // Botão Novo Mapa
        const btnNovoMapa = document.getElementById('btnNovoMapa');
        if (btnNovoMapa) {
            btnNovoMapa.addEventListener('click', () => this.mostrarFormulario());
        }
        
        // Botão Salvar Mapa (Formulário)
        const formMapa = document.getElementById('formMapa');
        if (formMapa) {
            formMapa.addEventListener('submit', (e) => {
                e.preventDefault();
                this.salvarMapa();
            });
        }
        
        // Botão Cancelar (Formulário)
        const btnCancelarForm = document.getElementById('btnCancelarForm');
        if (btnCancelarForm) {
            btnCancelarForm.addEventListener('click', () => this.mostrarListagem());
        }
        
        // Upload de Imagem
        const inputImagem = document.getElementById('imagemMapa');
        const previewImagem = document.getElementById('previewImagem');
        if (inputImagem && previewImagem) {
            inputImagem.addEventListener('change', (e) => {
                const file = e.target.files[0];
                if (file) {
                    const reader = new FileReader();
                    reader.onload = (event) => {
                        previewImagem.src = event.target.result;
                        previewImagem.style.display = 'block';
                        this.state.mapaData = { tipo: 'imagem', url: event.target.result };
                    }
                    reader.readAsDataURL(file);
                }
            });
        }
        
        // Botão Criar Visualmente
        const btnCriarVisualmente = document.getElementById('btnCriarVisualmente');
        if (btnCriarVisualmente) {
            btnCriarVisualmente.addEventListener('click', () => this.iniciarEdicaoVisual());
        }
        
        // Ferramentas de Desenho
        const paletaCores = document.getElementById('paletaCores');
        if (paletaCores) {
            paletaCores.addEventListener('click', (e) => {
                const button = e.target.closest('.btn-paleta');
                if (button) {
                    this.state.corSelecionada = button.getAttribute('data-cor');
                    // Desmarcar outros botões
                    paletaCores.querySelectorAll('.btn-paleta').forEach(btn => btn.classList.remove('active'));
                    button.classList.add('active');
                }
            });
        }
        
        const paletaTamanhos = document.getElementById('paletaTamanhos');
        if (paletaTamanhos) {
            paletaTamanhos.addEventListener('click', (e) => {
                const button = e.target.closest('.btn-paleta');
                if (button) {
                    this.state.tamanhoSelecionado = parseInt(button.getAttribute('data-tamanho'));
                    // Desmarcar outros botões
                    paletaTamanhos.querySelectorAll('.btn-paleta').forEach(btn => btn.classList.remove('active'));
                    button.classList.add('active');
                }
            });
        }
        
        // Canvas de Desenho
        const canvas = document.getElementById('canvasDesenho');
        if (canvas) {
            canvas.addEventListener('mousedown', (e) => this.iniciarDesenho(e));
            canvas.addEventListener('mousemove', (e) => this.desenhar(e));
            canvas.addEventListener('mouseup', () => this.pararDesenho());
            canvas.addEventListener('mouseout', () => this.pararDesenho());
            
            // Touch events
            canvas.addEventListener('touchstart', (e) => this.iniciarDesenho(e.touches[0]));
            canvas.addEventListener('touchmove', (e) => {
                e.preventDefault(); // Prevenir scroll
                this.desenhar(e.touches[0]);
            });
            canvas.addEventListener('touchend', () => this.pararDesenho());
        }
        
        // Botão Salvar Desenho
        const btnSalvarDesenho = document.getElementById('btnSalvarDesenho');
        if (btnSalvarDesenho) {
            btnSalvarDesenho.addEventListener('click', () => this.salvarDesenho());
        }
        
        // Botão Cancelar Desenho
        const btnCancelarDesenho = document.getElementById('btnCancelarDesenho');
        if (btnCancelarDesenho) {
            btnCancelarDesenho.addEventListener('click', () => this.cancelarDesenho());
        }
        
        // Botão Limpar Canvas
        const btnLimparCanvas = document.getElementById('btnLimparCanvas');
        if (btnLimparCanvas) {
            btnLimparCanvas.addEventListener('click', () => this.limparCanvas());
        }
    },
    
    /**
     * Carrega mapas salvos
     */
    carregarMapas: function() {
        STORAGE.getAll('mapasRisco').then(mapas => {
            this.exibirMapas(mapas);
        }).catch(error => {
            console.error('Erro ao carregar mapas de risco:', error);
            this.exibirNotificacao('Erro ao carregar mapas de risco', 'error');
        });
    },
    
    /**
     * Exibe mapas na listagem
     * @param {Array} mapas - Lista de mapas de risco
     */
    exibirMapas: function(mapas) {
        const listaMapas = document.getElementById('listaMapas');
        if (!listaMapas) return;
        
        listaMapas.innerHTML = ''; // Limpar lista
        
        if (mapas.length === 0) {
            listaMapas.innerHTML = '<p class="text-center">Nenhum mapa de risco cadastrado.</p>';
            return;
        }
        
        // Obter nomes dos setores
        STORAGE.getAll('setores').then(setores => {
            const setoresMap = {};
            setores.forEach(s => setoresMap[s.id] = s.nome);
            
            mapas.forEach(mapa => {
                const div = document.createElement('div');
                div.className = 'mapa-item card mb-3';
                
                const nomeSetor = setoresMap[mapa.setorId] || 'Setor não encontrado';
                const dataCriacao = mapa.dataCriacao ? new Date(mapa.dataCriacao).toLocaleDateString('pt-BR') : 'Data desconhecida';
                
                div.innerHTML = `
                    <div class="card-body">
                        <h5 class="card-title">${mapa.nome}</h5>
                        <h6 class="card-subtitle mb-2 text-muted">Setor: ${nomeSetor}</h6>
                        <p class="card-text">Criado em: ${dataCriacao}</p>
                        <div class="mapa-preview mb-2">
                            ${this.gerarPreview(mapa.data)}
                        </div>
                        <button class="btn btn-sm btn-primary view-btn" data-id="${mapa.id}"><i class="fas fa-eye"></i> Visualizar</button>
                        <button class="btn btn-sm btn-secondary edit-btn" data-id="${mapa.id}"><i class="fas fa-edit"></i> Editar</button>
                        <button class="btn btn-sm btn-danger delete-btn" data-id="${mapa.id}"><i class="fas fa-trash"></i> Excluir</button>
                    </div>
                `;
                listaMapas.appendChild(div);
            });
            
            // Adicionar eventos aos botões
            listaMapas.querySelectorAll('.view-btn').forEach(btn => {
                btn.addEventListener('click', () => this.visualizarMapa(parseInt(btn.getAttribute('data-id'))));
            });
            listaMapas.querySelectorAll('.edit-btn').forEach(btn => {
                btn.addEventListener('click', () => this.editarMapa(parseInt(btn.getAttribute('data-id'))));
            });
            listaMapas.querySelectorAll('.delete-btn').forEach(btn => {
                btn.addEventListener('click', () => this.excluirMapa(parseInt(btn.getAttribute('data-id'))));
            });
            
        }).catch(error => {
            console.error('Erro ao carregar setores para exibir mapas:', error);
            listaMapas.innerHTML = '<p class="text-center text-danger">Erro ao carregar dados dos setores.</p>';
        });
    },
    
    /**
     * Gera o preview do mapa (imagem ou canvas)
     * @param {object} data - Dados do mapa ({ tipo: 'imagem', url: '...' } ou { tipo: 'visual', dataUrl: '...' })
     * @returns {string} HTML do preview
     */
    gerarPreview: function(data) {
        if (!data) return '<p>Sem preview disponível.</p>';
        
        if (data.tipo === 'imagem' && data.url) {
            return `<img src="${data.url}" alt="Preview do Mapa" style="max-width: 100%; max-height: 150px; object-fit: contain;">`;
        } else if (data.tipo === 'visual' && data.dataUrl) {
            return `<img src="${data.dataUrl}" alt="Preview do Mapa Visual" style="max-width: 100%; max-height: 150px; object-fit: contain; border: 1px solid #ccc;">`;
        } else {
            return '<p>Preview indisponível.</p>';
        }
    },
    
    /**
     * Mostra o formulário de cadastro/edição
     */
    mostrarFormulario: function(mapa = null) {
        this.limparFormulario();
        
        const formContainer = document.getElementById('formContainer');
        const listContainer = document.getElementById('listContainer');
        const editorVisual = document.getElementById('editorVisual');
        const formTitle = document.getElementById('formTitle');
        
        if (mapa) {
            // Preencher formulário para edição
            formTitle.textContent = 'Editar Mapa de Risco';
            document.getElementById('formMapa').setAttribute('data-id', mapa.id);
            document.getElementById('nomeMapa').value = mapa.nome;
            document.getElementById('setorMapa').value = mapa.setorId;
            document.getElementById('descricaoMapa').value = mapa.descricao || '';
            
            // Exibir preview da imagem ou canvas existente
            const previewImagem = document.getElementById('previewImagem');
            if (mapa.data && mapa.data.tipo === 'imagem' && mapa.data.url) {
                previewImagem.src = mapa.data.url;
                previewImagem.style.display = 'block';
                this.state.mapaData = mapa.data; // Manter dados da imagem
            } else if (mapa.data && mapa.data.tipo === 'visual' && mapa.data.dataUrl) {
                previewImagem.src = mapa.data.dataUrl;
                previewImagem.style.display = 'block';
                this.state.mapaData = mapa.data; // Manter dados do canvas
            } else {
                previewImagem.style.display = 'none';
                previewImagem.src = '#';
                this.state.mapaData = null;
            }
            
            this.state.mapaAtual = mapa.id;
        } else {
            formTitle.textContent = 'Novo Mapa de Risco';
            this.state.mapaAtual = null;
            this.state.mapaData = null;
        }
        
        if (formContainer) formContainer.style.display = 'block';
        if (listContainer) listContainer.style.display = 'none';
        if (editorVisual) editorVisual.style.display = 'none';
    },
    
    /**
     * Mostra a listagem de mapas
     */
    mostrarListagem: function() {
        const formContainer = document.getElementById('formContainer');
        const listContainer = document.getElementById('listContainer');
        const editorVisual = document.getElementById('editorVisual');
        
        if (formContainer) formContainer.style.display = 'none';
        if (listContainer) listContainer.style.display = 'block';
        if (editorVisual) editorVisual.style.display = 'none';
        
        this.limparFormulario();
        this.carregarMapas(); // Recarregar lista
    },
    
    /**
     * Limpa o formulário
     */
    limparFormulario: function() {
        const formMapa = document.getElementById('formMapa');
        const previewImagem = document.getElementById('previewImagem');
        
        if (formMapa) {
            formMapa.reset();
            formMapa.removeAttribute('data-id');
        }
        if (previewImagem) {
            previewImagem.style.display = 'none';
            previewImagem.src = '#';
        }
        this.state.mapaAtual = null;
        this.state.mapaData = null;
    },
    
    /**
     * Salva o mapa (novo ou edição)
     */
    salvarMapa: function() {
        const formMapa = document.getElementById('formMapa');
        const id = formMapa.getAttribute('data-id');
        const nome = document.getElementById('nomeMapa').value.trim();
        const setorId = parseInt(document.getElementById('setorMapa').value);
        const descricao = document.getElementById('descricaoMapa').value.trim();
        
        if (!nome || isNaN(setorId)) {
            this.exibirNotificacao('Nome e Setor são obrigatórios.', 'error');
            return;
        }
        
        if (!this.state.mapaData) {
            this.exibirNotificacao('É necessário fazer upload de uma imagem ou criar um mapa visualmente.', 'error');
            return;
        }
        
        const mapa = {
            nome: nome,
            setorId: setorId,
            descricao: descricao,
            dataCriacao: id ? undefined : new Date().toISOString(), // Só define na criação
            dataAtualizacao: new Date().toISOString(),
            data: this.state.mapaData // { tipo: 'imagem', url: '...' } ou { tipo: 'visual', dataUrl: '...' }
        };
        
        if (id) {
            mapa.id = parseInt(id);
            // Manter data de criação original
            STORAGE.get('mapasRisco', mapa.id).then(mapaExistente => {
                mapa.dataCriacao = mapaExistente.dataCriacao;
                
                STORAGE.update('mapasRisco', mapa).then(() => {
                    this.exibirNotificacao('Mapa atualizado com sucesso!', 'success');
                    DASHBOARD.adicionarHistorico({ tipo: 'edicao', titulo: 'Mapa de Risco Atualizado', descricao: `Mapa "${nome}" foi atualizado.` });
                    this.mostrarListagem();
                }).catch(error => {
                    console.error('Erro ao atualizar mapa:', error);
                    this.exibirNotificacao('Erro ao atualizar mapa.', 'error');
                });
            }).catch(err => {
                 console.error('Erro ao buscar mapa existente:', err);
                 this.exibirNotificacao('Erro ao buscar dados originais do mapa.', 'error');
            });
            
        } else {
            STORAGE.add('mapasRisco', mapa).then(() => {
                this.exibirNotificacao('Mapa criado com sucesso!', 'success');
                DASHBOARD.adicionarHistorico({ tipo: 'criacao', titulo: 'Novo Mapa de Risco', descricao: `Mapa "${nome}" foi criado.` });
                this.mostrarListagem();
            }).catch(error => {
                console.error('Erro ao criar mapa:', error);
                this.exibirNotificacao('Erro ao criar mapa.', 'error');
            });
        }
    },
    
    /**
     * Inicia a edição visual (mostra o canvas)
     */
    iniciarEdicaoVisual: function() {
        const formContainer = document.getElementById('formContainer');
        const editorVisual = document.getElementById('editorVisual');
        
        if (formContainer) formContainer.style.display = 'none';
        if (editorVisual) editorVisual.style.display = 'block';
        
        this.state.modoEdicao = true;
        this.limparCanvas();
        
        // Se já existia um mapa visual, carregá-lo
        if (this.state.mapaData && this.state.mapaData.tipo === 'visual' && this.state.mapaData.dataUrl) {
            const canvas = document.getElementById('canvasDesenho');
            const ctx = canvas.getContext('2d');
            const img = new Image();
            img.onload = () => {
                ctx.drawImage(img, 0, 0);
            };
            img.src = this.state.mapaData.dataUrl;
        }
    },
    
    /**
     * Limpa o canvas de desenho
     */
    limparCanvas: function() {
        const canvas = document.getElementById('canvasDesenho');
        if (!canvas) return;
        const ctx = canvas.getContext('2d');
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        // Opcional: Adicionar fundo branco
        ctx.fillStyle = '#FFFFFF';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
    },
    
    /**
     * Inicia o desenho no canvas
     */
    iniciarDesenho: function(e) {
        if (!this.state.modoEdicao || !this.state.corSelecionada || !this.state.tamanhoSelecionado) return;
        
        const canvas = document.getElementById('canvasDesenho');
        const rect = canvas.getBoundingClientRect();
        this.state.desenhando = true;
        this.state.ultimoX = e.clientX - rect.left;
        this.state.ultimoY = e.clientY - rect.top;
        
        // Desenhar o ponto inicial
        this.desenharPonto(this.state.ultimoX, this.state.ultimoY);
    },
    
    /**
     * Desenha no canvas
     */
    desenhar: function(e) {
        if (!this.state.desenhando || !this.state.modoEdicao) return;
        
        const canvas = document.getElementById('canvasDesenho');
        const ctx = canvas.getContext('2d');
        const rect = canvas.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;
        
        // Desenhar linha do último ponto até o atual
        ctx.beginPath();
        ctx.moveTo(this.state.ultimoX, this.state.ultimoY);
        ctx.lineTo(x, y);
        ctx.strokeStyle = this.state.corSelecionada;
        ctx.lineWidth = this.state.tamanhoSelecionado * 5; // Ajustar tamanho
        ctx.lineCap = 'round';
        ctx.lineJoin = 'round';
        ctx.stroke();
        
        this.state.ultimoX = x;
        this.state.ultimoY = y;
    },
    
    /**
     * Desenha um ponto no canvas (para o clique inicial)
     */
    desenharPonto: function(x, y) {
        const canvas = document.getElementById('canvasDesenho');
        const ctx = canvas.getContext('2d');
        
        ctx.beginPath();
        ctx.arc(x, y, (this.state.tamanhoSelecionado * 5) / 2, 0, Math.PI * 2);
        ctx.fillStyle = this.state.corSelecionada;
        ctx.fill();
    },
    
    /**
     * Para o desenho no canvas
     */
    pararDesenho: function() {
        this.state.desenhando = false;
    },
    
    /**
     * Salva o desenho do canvas de volta para o formulário
     */
    salvarDesenho: function() {
        const canvas = document.getElementById('canvasDesenho');
        const dataUrl = canvas.toDataURL('image/png');
        
        this.state.mapaData = { tipo: 'visual', dataUrl: dataUrl };
        
        // Atualizar preview no formulário
        const previewImagem = document.getElementById('previewImagem');
        if (previewImagem) {
            previewImagem.src = dataUrl;
            previewImagem.style.display = 'block';
        }
        
        // Voltar para o formulário
        const formContainer = document.getElementById('formContainer');
        const editorVisual = document.getElementById('editorVisual');
        if (formContainer) formContainer.style.display = 'block';
        if (editorVisual) editorVisual.style.display = 'none';
        
        this.state.modoEdicao = false;
    },
    
    /**
     * Cancela a edição visual e volta para o formulário
     */
    cancelarDesenho: function() {
        // Voltar para o formulário sem salvar o desenho
        const formContainer = document.getElementById('formContainer');
        const editorVisual = document.getElementById('editorVisual');
        if (formContainer) formContainer.style.display = 'block';
        if (editorVisual) editorVisual.style.display = 'none';
        
        this.state.modoEdicao = false;
        // Não alterar this.state.mapaData, mantém o que estava antes
    },
    
    /**
     * Visualiza um mapa em um modal
     * @param {number} id - ID do mapa
     */
    visualizarMapa: function(id) {
        STORAGE.get('mapasRisco', id).then(mapa => {
            if (!mapa) {
                this.exibirNotificacao('Mapa não encontrado.', 'error');
                return;
            }
            
            STORAGE.get('setores', mapa.setorId).then(setor => {
                const nomeSetor = setor ? setor.nome : 'Setor não encontrado';
                const dataCriacao = new Date(mapa.dataCriacao).toLocaleString('pt-BR');
                const dataAtualizacao = new Date(mapa.dataAtualizacao).toLocaleString('pt-BR');
                
                const modal = document.createElement('div');
                modal.className = 'modal fade show';
                modal.style.display = 'block';
                modal.innerHTML = `
                    <div class="modal-dialog modal-lg modal-dialog-centered">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title">${mapa.nome}</h5>
                                <button type="button" class="close" data-dismiss="modal">&times;</button>
                            </div>
                            <div class="modal-body">
                                <p><strong>Setor:</strong> ${nomeSetor}</p>
                                <p><strong>Descrição:</strong> ${mapa.descricao || 'Nenhuma'}</p>
                                <p><strong>Criado em:</strong> ${dataCriacao}</p>
                                <p><strong>Atualizado em:</strong> ${dataAtualizacao}</p>
                                <div class="mapa-visualizacao mt-3" style="text-align: center;">
                                    ${this.gerarPreview(mapa.data).replace('max-height: 150px', 'max-height: 400px')}
                                </div>
                                ${this.gerarLegenda(mapa.data)}
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Fechar</button>
                                <button type="button" class="btn btn-primary" id="btnEditarModal">Editar</button>
                            </div>
                        </div>
                    </div>
                `;
                
                document.body.appendChild(modal);
                const backdrop = document.createElement('div');
                backdrop.className = 'modal-backdrop fade show';
                document.body.appendChild(backdrop);
                document.body.classList.add('modal-open');
                
                modal.querySelector('[data-dismiss="modal"]').addEventListener('click', () => {
                    document.body.removeChild(modal);
                    document.body.removeChild(backdrop);
                    document.body.classList.remove('modal-open');
                });
                modal.querySelector('#btnEditarModal').addEventListener('click', () => {
                    document.body.removeChild(modal);
                    document.body.removeChild(backdrop);
                    document.body.classList.remove('modal-open');
                    this.editarMapa(id);
                });
                
            }).catch(err => {
                 console.error('Erro ao buscar setor:', err);
                 this.exibirNotificacao('Erro ao carregar dados do setor.', 'error');
            });
        }).catch(error => {
            console.error('Erro ao visualizar mapa:', error);
            this.exibirNotificacao('Erro ao carregar mapa.', 'error');
        });
    },
    
    /**
     * Gera a legenda para o mapa visual
     * @param {object} data - Dados do mapa
     * @returns {string} HTML da legenda ou string vazia
     */
    gerarLegenda: function(data) {
        if (!data || data.tipo !== 'visual') return '';
        
        let legendaHTML = '<div class="mapa-legenda mt-3"><h6>Legenda:</h6><ul class="list-inline">';
        this.config.tiposRisco.forEach(tipo => {
            legendaHTML += `
                <li class="list-inline-item mr-3">
                    <span style="display: inline-block; width: 15px; height: 15px; background-color: ${tipo.cor}; border-radius: 50%; margin-right: 5px; vertical-align: middle;"></span>
                    ${tipo.nome}
                </li>`;
        });
        legendaHTML += '</ul></div>';
        return legendaHTML;
    },
    
    /**
     * Prepara para editar um mapa existente
     * @param {number} id - ID do mapa
     */
    editarMapa: function(id) {
        STORAGE.get('mapasRisco', id).then(mapa => {
            if (!mapa) {
                this.exibirNotificacao('Mapa não encontrado.', 'error');
                return;
            }
            this.mostrarFormulario(mapa);
        }).catch(error => {
            console.error('Erro ao carregar mapa para edição:', error);
            this.exibirNotificacao('Erro ao carregar mapa para edição.', 'error');
        });
    },
    
    /**
     * Exclui um mapa
     * @param {number} id - ID do mapa
     */
    excluirMapa: function(id) {
        if (confirm('Tem certeza que deseja excluir este mapa de risco?')) {
            STORAGE.get('mapasRisco', id).then(mapa => {
                if (!mapa) {
                    this.exibirNotificacao('Mapa não encontrado.', 'error');
                    return;
                }
                STORAGE.remove('mapasRisco', id).then(() => {
                    this.exibirNotificacao('Mapa excluído com sucesso!', 'success');
                    DASHBOARD.adicionarHistorico({ tipo: 'exclusao', titulo: 'Mapa de Risco Excluído', descricao: `Mapa "${mapa.nome}" foi excluído.` });
                    this.carregarMapas(); // Recarregar lista
                }).catch(error => {
                    console.error('Erro ao excluir mapa:', error);
                    this.exibirNotificacao('Erro ao excluir mapa.', 'error');
                });
            }).catch(error => {
                 console.error('Erro ao buscar mapa para exclusão:', error);
                 this.exibirNotificacao('Erro ao buscar mapa para exclusão.', 'error');
            });
        }
    },
    
    /**
     * Exibe uma notificação para o usuário
     * @param {string} mensagem - Mensagem a ser exibida
     * @param {string} tipo - Tipo de notificação (success, error, warning, info)
     */
    exibirNotificacao: function(mensagem, tipo) {
        // Reutiliza a função de notificação do dashboard se disponível
        if (typeof DASHBOARD !== 'undefined' && DASHBOARD.exibirNotificacao) {
            DASHBOARD.exibirNotificacao(mensagem, tipo);
        } else {
            // Fallback simples
            alert(`[${tipo.toUpperCase()}] ${mensagem}`);
        }
    }
};

// Inicializar módulo quando o DOM estiver carregado
document.addEventListener('DOMContentLoaded', function() {
    // Verificar se estamos na página de Mapa de Riscos
    if (document.querySelector('.riscos-container')) {
        MAPA_RISCOS.init();
    }
});
