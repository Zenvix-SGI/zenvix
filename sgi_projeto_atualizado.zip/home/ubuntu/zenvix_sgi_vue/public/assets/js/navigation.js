/**
 * ZENVIX SGI - Módulo de Navegação
 * 
 * Este módulo gerencia a navegação entre páginas e o comportamento do menu lateral,
 * otimizado para funcionar em dispositivos móveis e desktop.
 */

document.addEventListener('DOMContentLoaded', function() {
    // --- Elementos DOM ---
    const sidebar = document.querySelector('.sidebar');
    const sidebarToggle = document.querySelector('.sidebar-toggle');
    const mainContent = document.querySelector('.main-content');
    const logoutButton = document.getElementById('logoutButton');
    const logoutButtonHeader = document.getElementById('logoutButtonHeader');
    const userDropdownToggle = document.querySelector('.user-button');
    const userDropdownMenu = document.querySelector('.dropdown-menu');
    const usernameDisplay = document.getElementById('usernameDisplay');
    const userRoleDisplay = document.getElementById('userRoleDisplay');
    
    // --- Configurações ---
    const MOBILE_BREAKPOINT = 768; // Ponto de quebra para dispositivos móveis
    
    // --- Funções de Navegação ---
    
    /**
     * Inicializa o módulo de navegação
     */
    function init() {
        setupSidebar();
        setupUserInfo();
        setupLogoutButtons();
        setupDropdowns();
        setupTheme();
        
        // Verifica autenticação
        checkAuthentication();
    }
    
    /**
     * Configura o comportamento do menu lateral
     */
    function setupSidebar() {
        // Adiciona classe ao body para indicar que tem sidebar
        document.body.classList.add('with-sidebar');
        
        // Configura o toggle do sidebar em dispositivos móveis
        if (sidebarToggle) {
            sidebarToggle.addEventListener('click', function(e) {
                e.preventDefault();
                toggleSidebar();
            });
        }
        
        // Fecha o sidebar ao clicar fora em dispositivos móveis
        document.addEventListener('click', function(e) {
            if (window.innerWidth <= MOBILE_BREAKPOINT) {
                // Verifica se o clique foi fora do sidebar e do botão toggle
                if (sidebar && 
                    !sidebar.contains(e.target) && 
                    sidebarToggle && 
                    !sidebarToggle.contains(e.target)) {
                    closeSidebar();
                }
            }
        });
        
        // Ajusta o sidebar ao redimensionar a janela
        window.addEventListener('resize', function() {
            adjustSidebarForScreenSize();
        });
        
        // Configura inicialmente com base no tamanho da tela
        adjustSidebarForScreenSize();
    }
    
    /**
     * Alterna a visibilidade do menu lateral
     */
    function toggleSidebar() {
        if (sidebar) {
            sidebar.classList.toggle('active');
            
            // Adiciona/remove classe no body para ajustar o conteúdo principal
            document.body.classList.toggle('sidebar-open');
        }
    }
    
    /**
     * Fecha o menu lateral
     */
    function closeSidebar() {
        if (sidebar && sidebar.classList.contains('active')) {
            sidebar.classList.remove('active');
            document.body.classList.remove('sidebar-open');
        }
    }
    
    /**
     * Ajusta o comportamento do sidebar com base no tamanho da tela
     */
    function adjustSidebarForScreenSize() {
        if (window.innerWidth <= MOBILE_BREAKPOINT) {
            // Em dispositivos móveis, o sidebar começa fechado
            if (sidebar) {
                sidebar.classList.remove('active');
            }
            
            // Ajusta o conteúdo principal
            if (mainContent) {
                mainContent.style.marginLeft = '0';
            }
            
            // Mostra o botão de toggle
            if (sidebarToggle) {
                sidebarToggle.style.display = 'flex';
            }
        } else {
            // Em desktop, o sidebar fica sempre visível
            if (sidebar) {
                sidebar.classList.add('active');
            }
            
            // Esconde o botão de toggle
            if (sidebarToggle) {
                sidebarToggle.style.display = 'none';
            }
        }
    }
    
    /**
     * Configura as informações do usuário logado
     */
    function setupUserInfo() {
        const username = localStorage.getItem('username');
        const userRole = localStorage.getItem('userRole');
        const userName = localStorage.getItem('userName');
        
        // Atualiza o nome de usuário na interface
        if (usernameDisplay && userName) {
            usernameDisplay.textContent = userName;
        }
        
        // Atualiza o cargo/função na interface
        if (userRoleDisplay && userRole) {
            let roleText = 'Usuário';
            
            switch (userRole) {
                case 'admin':
                    roleText = 'Administrador';
                    break;
                case 'tecnico':
                    roleText = 'Técnico SST';
                    break;
                case 'medico':
                    roleText = 'Médico do Trabalho';
                    break;
            }
            
            userRoleDisplay.textContent = roleText;
        }
    }
    
    /**
     * Configura os botões de logout
     */
    function setupLogoutButtons() {
        // Botão de logout no sidebar
        if (logoutButton) {
            logoutButton.addEventListener('click', function(e) {
                e.preventDefault();
                logout();
            });
        }
        
        // Botão de logout no dropdown do header
        if (logoutButtonHeader) {
            logoutButtonHeader.addEventListener('click', function(e) {
                e.preventDefault();
                logout();
            });
        }
    }
    
    /**
     * Realiza o logout do usuário
     */
    function logout() {
        // Limpa os dados de sessão
        localStorage.removeItem('loggedIn');
        localStorage.removeItem('username');
        localStorage.removeItem('userRole');
        localStorage.removeItem('userName');
        localStorage.removeItem('sessionExpiry');
        
        // Redireciona para a página de login
        window.location.href = 'login.html';
    }
    
    /**
     * Configura os dropdowns da interface
     */
    function setupDropdowns() {
        // Toggle do dropdown de usuário
        if (userDropdownToggle && userDropdownMenu) {
            userDropdownToggle.addEventListener('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                userDropdownMenu.classList.toggle('show');
            });
            
            // Fecha o dropdown ao clicar fora
            document.addEventListener('click', function(e) {
                if (userDropdownMenu.classList.contains('show') && 
                    !userDropdownToggle.contains(e.target)) {
                    userDropdownMenu.classList.remove('show');
                }
            });
        }
    }
    
    /**
     * Configura o tema da interface
     */
    function setupTheme() {
        const themeToggle = document.getElementById('themeToggle');
        
        // Carrega o tema salvo ou usa a preferência do sistema
        const savedTheme = localStorage.getItem('theme');
        if (savedTheme) {
            document.documentElement.setAttribute('data-theme', savedTheme);
            updateThemeIcon(savedTheme);
        } else if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
            document.documentElement.setAttribute('data-theme', 'dark');
            updateThemeIcon('dark');
        }
        
        // Configura o botão de alternar tema
        if (themeToggle) {
            themeToggle.addEventListener('click', function() {
                const currentTheme = document.documentElement.getAttribute('data-theme') || 'light';
                const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
                
                document.documentElement.setAttribute('data-theme', newTheme);
                localStorage.setItem('theme', newTheme);
                
                updateThemeIcon(newTheme);
            });
        }
    }
    
    /**
     * Atualiza o ícone do botão de tema
     * @param {string} theme - O tema atual ('light' ou 'dark')
     */
    function updateThemeIcon(theme) {
        const themeToggle = document.getElementById('themeToggle');
        if (themeToggle) {
            const icon = themeToggle.querySelector('i');
            if (icon) {
                if (theme === 'dark') {
                    icon.className = 'fas fa-sun';
                } else {
                    icon.className = 'fas fa-moon';
                }
            }
        }
    }
    
    /**
     * Verifica se o usuário está autenticado
     */
    function checkAuthentication() {
        // Verifica se estamos em uma página que requer autenticação
        const isLoginPage = window.location.pathname.includes('login.html');
        const isIndexPage = window.location.pathname.includes('index.html') || 
                           window.location.pathname.endsWith('/');
        
        if (!isLoginPage && !isIndexPage) {
            const isLoggedIn = localStorage.getItem('loggedIn') === 'true';
            const sessionExpiry = parseInt(localStorage.getItem('sessionExpiry') || '0');
            
            // Se não estiver logado ou a sessão expirou, redireciona para login
            if (!isLoggedIn || sessionExpiry < Date.now()) {
                window.location.href = 'login.html';
            }
        }
    }
    
    // Inicializa o módulo
    init();
});
