/**
 * ZENVIX SGI - Módulo de Gestão de Brigada de Incêndio e CIPA
 * 
 * Funções para gerenciar membros, reuniões, treinamentos, documentos e eleições
 * tanto da Brigada de Incêndio quanto da CIPA (Comissão Interna de Prevenção de Acidentes).
 */

// Namespace
const BRIGADA_CIPA = {
    // Configurações
    config: {
        tiposEquipe: ["Brigada de Incêndio", "CIPA"],
        funcoesBrigada: ["Chefe", "Líder", "Brigadista", "Apoio"],
        funcoesCIPA: ["Presidente (Indicado)", "Vice-Presidente (Eleito)", "Secretário", "Membro Titular (Eleito)", "Membro Suplente (Eleito)", "Membro Titular (Indicado)", "Membro Suplente (Indicado)"],
        tiposReuniao: ["Ordinária", "Extraordinária", "Posse", "Eleição"],
        tiposDocumento: ["Ata de Reunião", "Edital de Convocação", "Certificado de Treinamento", "Plano de Emergência", "Relatório Anual", "Outro"]
    },
    
    // Estado
    state: {
        equipeSelecionada: "Brigada de Incêndio", // ou "CIPA"
        editandoMembroId: null,
        editandoReuniaoId: null,
        editandoTreinamentoId: null,
        editandoDocumentoId: null,
        editandoEleicaoId: null
    },
    
    /**
     * Inicializa o módulo
     */
    init: function() {
        console.log("Inicializando módulo Brigada/CIPA...");
        
        if (!STORAGE.isAuthenticated()) {
            console.warn("Usuário não autenticado. Redirecionando para login...");
            window.location.href = "login.html";
            return;
        }
        
        this.initComponents();
        this.setupEvents();
        this.selecionarEquipe("Brigada de Incêndio"); // Inicia com Brigada
        
        console.log("Módulo Brigada/CIPA inicializado.");
    },
    
    /**
     * Inicializa componentes da interface
     */
    initComponents: function() {
        // Preencher selects de formulários
        this.preencherSelect("membroFuncao", []); // Será preenchido ao selecionar equipe
        this.preencherSelect("reuniaoTipo", this.config.tiposReuniao);
        this.preencherSelect("documentoTipo", this.config.tiposDocumento);
        
        // Carregar funcionários para selects
        STORAGE.getAll("funcionarios").then(funcionarios => {
            funcionarios.sort((a, b) => a.nome.localeCompare(b.nome));
            const options = funcionarios.filter(f => f.ativo).map(f => ({ value: f.id, text: f.nome }));
            this.preencherSelect("membroFuncionario", options, "Selecione...");
            this.preencherSelect("reuniaoParticipantes", options, null, true); // Múltipla seleção
            this.preencherSelect("treinamentoParticipantes", options, null, true);
            this.preencherSelect("eleicaoCandidatos", options, null, true);
            this.preencherSelect("eleicaoEleitores", options, null, true);
        }).catch(error => console.error("Erro ao carregar funcionários:", error));
        
        // Inicializar datepickers
        document.querySelectorAll(".datepicker").forEach(el => {
            // Adicionar validação ou inicializar biblioteca de datepicker se houver
        });
    },
    
    /**
     * Configura eventos da interface
     */
    setupEvents: function() {
        // Abas de seleção (Brigada/CIPA)
        document.querySelectorAll(".tab-button").forEach(button => {
            button.addEventListener("click", (e) => {
                const equipe = e.target.getAttribute("data-equipe");
                this.selecionarEquipe(equipe);
            });
        });
        
        // Botões "Novo"
        document.getElementById("btnNovoMembro")?.addEventListener("click", () => this.mostrarFormulario("formMembro"));
        document.getElementById("btnNovaReuniao")?.addEventListener("click", () => this.mostrarFormulario("formReuniao"));
        document.getElementById("btnNovoTreinamento")?.addEventListener("click", () => this.mostrarFormulario("formTreinamento"));
        document.getElementById("btnNovoDocumento")?.addEventListener("click", () => this.mostrarFormulario("formDocumento"));
        document.getElementById("btnNovaEleicao")?.addEventListener("click", () => this.mostrarFormulario("formEleicao"));
        
        // Botões "Cancelar" dos formulários
        document.querySelectorAll(".btn-cancelar").forEach(button => {
            button.addEventListener("click", (e) => {
                const formId = e.target.closest("form").id;
                this.ocultarFormulario(formId);
            });
        });
        
        // Submissão dos formulários
        document.getElementById("formMembro")?.addEventListener("submit", (e) => { e.preventDefault(); this.salvarMembro(); });
        document.getElementById("formReuniao")?.addEventListener("submit", (e) => { e.preventDefault(); this.salvarReuniao(); });
        document.getElementById("formTreinamento")?.addEventListener("submit", (e) => { e.preventDefault(); this.salvarTreinamento(); });
        document.getElementById("formDocumento")?.addEventListener("submit", (e) => { e.preventDefault(); this.salvarDocumento(); });
        document.getElementById("formEleicao")?.addEventListener("submit", (e) => { e.preventDefault(); this.salvarEleicao(); });
        
        // Upload de arquivo (Documento)
        const inputFile = document.getElementById("documentoArquivo");
        const fileInfo = document.getElementById("documentoFileInfo");
        if (inputFile && fileInfo) {
            inputFile.addEventListener("change", (e) => {
                const file = e.target.files[0];
                if (file) {
                    fileInfo.textContent = `Arquivo selecionado: ${file.name} (${(file.size / 1024).toFixed(1)} KB)`;
                } else {
                    fileInfo.textContent = "Nenhum arquivo selecionado.";
                }
            });
        }
    },
    
    /**
     * Seleciona a equipe (Brigada ou CIPA) e atualiza a interface
     * @param {string} equipe - "Brigada de Incêndio" ou "CIPA"
     */
    selecionarEquipe: function(equipe) {
        this.state.equipeSelecionada = equipe;
        console.log(`Equipe selecionada: ${equipe}`);
        
        // Atualizar Abas
        document.querySelectorAll(".tab-button").forEach(button => {
            button.classList.toggle("active", button.getAttribute("data-equipe") === equipe);
        });
        
        // Atualizar Título Principal
        const tituloPrincipal = document.querySelector(".main-content h1");
        if (tituloPrincipal) {
            tituloPrincipal.textContent = equipe;
        }
        
        // Atualizar Títulos das Seções
        document.querySelectorAll("[data-section-title]").forEach(title => {
            title.textContent = title.getAttribute("data-section-title").replace("{equipe}", equipe);
        });
        
        // Atualizar Select de Funções no formulário de membro
        const funcoes = equipe === "Brigada de Incêndio" ? this.config.funcoesBrigada : this.config.funcoesCIPA;
        this.preencherSelect("membroFuncao", funcoes);
        
        // Mostrar/Ocultar Seção de Eleições (apenas CIPA)
        const secaoEleicoes = document.getElementById("secaoEleicoes");
        if (secaoEleicoes) {
            secaoEleicoes.style.display = equipe === "CIPA" ? "block" : "none";
        }
        
        // Recarregar dados da equipe selecionada
        this.carregarDadosEquipe();
    },
    
    /**
     * Carrega todos os dados da equipe selecionada (membros, reuniões, etc.)
     */
    carregarDadosEquipe: function() {
        const equipe = this.state.equipeSelecionada;
        console.log(`Carregando dados para ${equipe}...`);
        
        // Carregar Membros
        STORAGE.getAll("equipeMembros").then(membros => {
            const membrosFiltrados = membros.filter(m => m.equipe === equipe);
            this.exibirMembros(membrosFiltrados);
        }).catch(err => console.error("Erro ao carregar membros:", err));
        
        // Carregar Reuniões
        STORAGE.getAll("equipeReunioes").then(reunioes => {
            const reunioesFiltradas = reunioes.filter(r => r.equipe === equipe);
            this.exibirReunioes(reunioesFiltradas);
        }).catch(err => console.error("Erro ao carregar reuniões:", err));
        
        // Carregar Treinamentos
        STORAGE.getAll("equipeTreinamentos").then(treinamentos => {
            const treinamentosFiltrados = treinamentos.filter(t => t.equipe === equipe);
            this.exibirTreinamentos(treinamentosFiltrados);
        }).catch(err => console.error("Erro ao carregar treinamentos:", err));
        
        // Carregar Documentos
        STORAGE.getAll("equipeDocumentos").then(documentos => {
            const documentosFiltrados = documentos.filter(d => d.equipe === equipe);
            this.exibirDocumentos(documentosFiltrados);
        }).catch(err => console.error("Erro ao carregar documentos:", err));
        
        // Carregar Eleições (se CIPA)
        if (equipe === "CIPA") {
            STORAGE.getAll("equipeEleicoes").then(eleicoes => {
                this.exibirEleicoes(eleicoes);
            }).catch(err => console.error("Erro ao carregar eleições:", err));
        }
    },
    
    // --- Funções de Exibição --- //
    
    exibirMembros: function(membros) {
        const tbody = document.getElementById("tabelaMembros")?.querySelector("tbody");
        if (!tbody) return;
        tbody.innerHTML = "";
        
        if (membros.length === 0) {
            tbody.innerHTML = `<tr><td colspan="5" class="text-center">Nenhum membro cadastrado para ${this.state.equipeSelecionada}.</td></tr>`;
            return;
        }
        
        STORAGE.getAll("funcionarios").then(funcionarios => {
            const funcMap = {};
            funcionarios.forEach(f => funcMap[f.id] = f.nome);
            
            membros.forEach(membro => {
                const tr = document.createElement("tr");
                const nomeFuncionario = funcMap[membro.funcionarioId] || "Funcionário não encontrado";
                const mandatoInicio = membro.mandatoInicio ? new Date(membro.mandatoInicio).toLocaleDateString("pt-BR") : "-";
                const mandatoFim = membro.mandatoFim ? new Date(membro.mandatoFim).toLocaleDateString("pt-BR") : "-";
                
                tr.innerHTML = `
                    <td>${nomeFuncionario}</td>
                    <td>${membro.funcao}</td>
                    <td>${mandatoInicio}</td>
                    <td>${mandatoFim}</td>
                    <td>
                        <button class="btn-sm edit-btn" data-id="${membro.id}" data-type="membro"><i class="fas fa-edit"></i></button>
                        <button class="btn-sm delete-btn" data-id="${membro.id}" data-type="membro"><i class="fas fa-trash"></i></button>
                    </td>
                `;
                tbody.appendChild(tr);
            });
            this.adicionarEventosBotoesTabela(tbody);
        }).catch(err => {
            console.error("Erro ao buscar funcionários para exibir membros:", err);
            tbody.innerHTML = `<tr><td colspan="5" class="text-center text-danger">Erro ao carregar dados dos funcionários.</td></tr>`;
        });
    },
    
    exibirReunioes: function(reunioes) {
        const tbody = document.getElementById("tabelaReunioes")?.querySelector("tbody");
        if (!tbody) return;
        tbody.innerHTML = "";
        
        if (reunioes.length === 0) {
            tbody.innerHTML = `<tr><td colspan="5" class="text-center">Nenhuma reunião registrada para ${this.state.equipeSelecionada}.</td></tr>`;
            return;
        }
        
        reunioes.forEach(reuniao => {
            const tr = document.createElement("tr");
            const data = reuniao.data ? new Date(reuniao.data).toLocaleDateString("pt-BR") : "-";
            tr.innerHTML = `
                <td>${data}</td>
                <td>${reuniao.tipo}</td>
                <td>${reuniao.pauta.substring(0, 50)}${reuniao.pauta.length > 50 ? "..." : ""}</td>
                <td>${reuniao.participantes ? reuniao.participantes.length : 0}</td>
                <td>
                    <button class="btn-sm view-btn" data-id="${reuniao.id}" data-type="reuniao"><i class="fas fa-eye"></i></button>
                    <button class="btn-sm edit-btn" data-id="${reuniao.id}" data-type="reuniao"><i class="fas fa-edit"></i></button>
                    <button class="btn-sm delete-btn" data-id="${reuniao.id}" data-type="reuniao"><i class="fas fa-trash"></i></button>
                </td>
            `;
            tbody.appendChild(tr);
        });
        this.adicionarEventosBotoesTabela(tbody);
    },
    
    exibirTreinamentos: function(treinamentos) {
        const tbody = document.getElementById("tabelaTreinamentos")?.querySelector("tbody");
        if (!tbody) return;
        tbody.innerHTML = "";
        
        if (treinamentos.length === 0) {
            tbody.innerHTML = `<tr><td colspan="5" class="text-center">Nenhum treinamento registrado para ${this.state.equipeSelecionada}.</td></tr>`;
            return;
        }
        
        treinamentos.forEach(treinamento => {
            const tr = document.createElement("tr");
            const data = treinamento.data ? new Date(treinamento.data).toLocaleDateString("pt-BR") : "-";
            const validade = treinamento.validade ? new Date(treinamento.validade).toLocaleDateString("pt-BR") : "-";
            tr.innerHTML = `
                <td>${treinamento.nome}</td>
                <td>${data}</td>
                <td>${validade}</td>
                <td>${treinamento.cargaHoraria || "-"}h</td>
                <td>
                    <button class="btn-sm view-btn" data-id="${treinamento.id}" data-type="treinamento"><i class="fas fa-eye"></i></button>
                    <button class="btn-sm edit-btn" data-id="${treinamento.id}" data-type="treinamento"><i class="fas fa-edit"></i></button>
                    <button class="btn-sm delete-btn" data-id="${treinamento.id}" data-type="treinamento"><i class="fas fa-trash"></i></button>
                </td>
            `;
            tbody.appendChild(tr);
        });
        this.adicionarEventosBotoesTabela(tbody);
    },
    
    exibirDocumentos: function(documentos) {
        const tbody = document.getElementById("tabelaDocumentos")?.querySelector("tbody");
        if (!tbody) return;
        tbody.innerHTML = "";
        
        if (documentos.length === 0) {
            tbody.innerHTML = `<tr><td colspan="4" class="text-center">Nenhum documento registrado para ${this.state.equipeSelecionada}.</td></tr>`;
            return;
        }
        
        documentos.forEach(doc => {
            const tr = document.createElement("tr");
            const data = doc.data ? new Date(doc.data).toLocaleDateString("pt-BR") : "-";
            const temArquivo = doc.arquivoDataUrl ? "." : ""; // Indicador visual
            tr.innerHTML = `
                <td>${doc.nome}${temArquivo}</td>
                <td>${doc.tipo}</td>
                <td>${data}</td>
                <td>
                    ${doc.arquivoDataUrl ? 
                        `<button class="btn-sm download-btn" data-id="${doc.id}" data-type="documento"><i class="fas fa-download"></i></button>` : 
                        `<button class="btn-sm download-btn disabled" title="Sem arquivo anexado" disabled><i class="fas fa-download"></i></button>`}
                    <button class="btn-sm edit-btn" data-id="${doc.id}" data-type="documento"><i class="fas fa-edit"></i></button>
                    <button class="btn-sm delete-btn" data-id="${doc.id}" data-type="documento"><i class="fas fa-trash"></i></button>
                </td>
            `;
            tbody.appendChild(tr);
        });
        this.adicionarEventosBotoesTabela(tbody);
    },
    
    exibirEleicoes: function(eleicoes) {
        const tbody = document.getElementById("tabelaEleicoes")?.querySelector("tbody");
        if (!tbody) return;
        tbody.innerHTML = "";
        
        if (eleicoes.length === 0) {
            tbody.innerHTML = `<tr><td colspan="4" class="text-center">Nenhuma eleição registrada.</td></tr>`;
            return;
        }
        
        eleicoes.forEach(eleicao => {
            const tr = document.createElement("tr");
            const data = eleicao.data ? new Date(eleicao.data).toLocaleDateString("pt-BR") : "-";
            const gestao = `${eleicao.gestaoInicio} - ${eleicao.gestaoFim}`;
            tr.innerHTML = `
                <td>${gestao}</td>
                <td>${data}</td>
                <td>${eleicao.status || "-"}</td>
                <td>
                    <button class="btn-sm view-btn" data-id="${eleicao.id}" data-type="eleicao"><i class="fas fa-eye"></i></button>
                    <button class="btn-sm edit-btn" data-id="${eleicao.id}" data-type="eleicao"><i class="fas fa-edit"></i></button>
                    <button class="btn-sm delete-btn" data-id="${eleicao.id}" data-type="eleicao"><i class="fas fa-trash"></i></button>
                </td>
            `;
            tbody.appendChild(tr);
        });
        this.adicionarEventosBotoesTabela(tbody);
    },
    
    // --- Funções de Formulário --- //
    
    mostrarFormulario: function(formId, id = null) {
        const formElement = document.getElementById(formId);
        if (!formElement) return;
        
        const listContainer = formElement.closest(".card").querySelector(".table-responsive, .list-container"); // Encontra a lista associada
        const formContainer = formElement.closest(".form-container");
        
        this.limparFormulario(formId);
        
        if (id) {
            // Modo Edição
            const tipo = formId.replace("form", "").toLowerCase(); // membro, reuniao, etc.
            const storeName = `equipe${tipo.charAt(0).toUpperCase() + tipo.slice(1)}s`; // equipeMembros, equipeReunioes...
            
            STORAGE.get(storeName, id).then(item => {
                if (!item) {
                    this.exibirNotificacao("Item não encontrado para edição.", "error");
                    return;
                }
                this.preencherFormulario(formId, item);
                formElement.setAttribute("data-id", id);
                formContainer.querySelector(".form-title").textContent = `Editar ${tipo.charAt(0).toUpperCase() + tipo.slice(1)}`;
                
                if (listContainer) listContainer.style.display = "none";
                formContainer.style.display = "block";
                
            }).catch(err => {
                console.error(`Erro ao carregar ${tipo} para edição:`, err);
                this.exibirNotificacao(`Erro ao carregar ${tipo} para edição.`, "error");
            });
        } else {
            // Modo Novo
            const tipo = formId.replace("form", "").toLowerCase();
            formContainer.querySelector(".form-title").textContent = `Novo ${tipo.charAt(0).toUpperCase() + tipo.slice(1)}`;
            if (listContainer) listContainer.style.display = "none";
            formContainer.style.display = "block";
        }
    },
    
    ocultarFormulario: function(formId) {
        const formElement = document.getElementById(formId);
        if (!formElement) return;
        
        const listContainer = formElement.closest(".card").querySelector(".table-responsive, .list-container");
        const formContainer = formElement.closest(".form-container");
        
        formContainer.style.display = "none";
        if (listContainer) listContainer.style.display = "block";
        this.limparFormulario(formId);
    },
    
    limparFormulario: function(formId) {
        const form = document.getElementById(formId);
        if (form) {
            form.reset();
            form.removeAttribute("data-id");
            // Limpar selects múltiplos se houver
            form.querySelectorAll("select[multiple]").forEach(select => {
                Array.from(select.options).forEach(option => option.selected = false);
            });
            // Limpar info de arquivo
            const fileInfo = form.querySelector(".file-info");
            if (fileInfo) fileInfo.textContent = "Nenhum arquivo selecionado.";
        }
    },
    
    preencherFormulario: function(formId, data) {
        const form = document.getElementById(formId);
        if (!form) return;
        
        for (const key in data) {
            const input = form.elements[key]; // Busca pelo name
            if (input) {
                if (input.type === "checkbox") {
                    input.checked = data[key];
                } else if (input.type === "date" && data[key]) {
                    // Formatar data para YYYY-MM-DD
                    try {
                        input.value = new Date(data[key]).toISOString().split("T")[0];
                    } catch (e) { console.warn(`Data inválida para ${key}: ${data[key]}`); }
                } else if (input.tagName === "SELECT" && input.multiple) {
                    if (Array.isArray(data[key])) {
                        Array.from(input.options).forEach(option => {
                            option.selected = data[key].includes(parseInt(option.value)) || data[key].includes(option.value);
                        });
                    }
                } else if (input.tagName === "SELECT") {
                     input.value = data[key];
                } else {
                    input.value = data[key];
                }
            }
        }
        
        // Caso especial para arquivo (não preenchemos o input, apenas mostramos info se houver)
        if (formId === "formDocumento" && data.arquivoNome) {
            const fileInfo = document.getElementById("documentoFileInfo");
            if (fileInfo) fileInfo.textContent = `Arquivo existente: ${data.arquivoNome}`;
        }
    },
    
    // --- Funções de Salvamento --- //
    
    salvarMembro: function() {
        const form = document.getElementById("formMembro");
        const id = form.getAttribute("data-id");
        const funcionarioId = parseInt(form.elements["membroFuncionario"].value);
        const funcao = form.elements["membroFuncao"].value;
        const mandatoInicio = form.elements["membroMandatoInicio"].value;
        const mandatoFim = form.elements["membroMandatoFim"].value;
        
        if (isNaN(funcionarioId) || !funcao) {
            this.exibirNotificacao("Funcionário e Função são obrigatórios.", "error");
            return;
        }
        
        const membro = {
            equipe: this.state.equipeSelecionada,
            funcionarioId: funcionarioId,
            funcao: funcao,
            mandatoInicio: mandatoInicio || null,
            mandatoFim: mandatoFim || null,
            dataAtualizacao: new Date().toISOString()
        };
        
        const storeName = "equipeMembros";
        const promise = id 
            ? STORAGE.update(storeName, { ...membro, id: parseInt(id) }) 
            : STORAGE.add(storeName, { ...membro, dataCadastro: new Date().toISOString() });
            
        promise.then(() => {
            this.exibirNotificacao(`Membro ${id ? "atualizado" : "adicionado"} com sucesso!`, "success");
            this.ocultarFormulario("formMembro");
            this.carregarDadosEquipe(); // Recarrega a lista
        }).catch(err => {
            console.error("Erro ao salvar membro:", err);
            this.exibirNotificacao("Erro ao salvar membro.", "error");
        });
    },
    
    salvarReuniao: function() {
        const form = document.getElementById("formReuniao");
        const id = form.getAttribute("data-id");
        const data = form.elements["reuniaoData"].value;
        const tipo = form.elements["reuniaoTipo"].value;
        const pauta = form.elements["reuniaoPauta"].value.trim();
        const ata = form.elements["reuniaoAta"].value.trim();
        const participantes = Array.from(form.elements["reuniaoParticipantes"].selectedOptions).map(opt => parseInt(opt.value));
        
        if (!data || !tipo || !pauta) {
            this.exibirNotificacao("Data, Tipo e Pauta são obrigatórios.", "error");
            return;
        }
        
        const reuniao = {
            equipe: this.state.equipeSelecionada,
            data: data,
            tipo: tipo,
            pauta: pauta,
            ata: ata,
            participantes: participantes,
            dataAtualizacao: new Date().toISOString()
        };
        
        const storeName = "equipeReunioes";
        const promise = id 
            ? STORAGE.update(storeName, { ...reuniao, id: parseInt(id) }) 
            : STORAGE.add(storeName, { ...reuniao, dataCadastro: new Date().toISOString() });
            
        promise.then(() => {
            this.exibirNotificacao(`Reunião ${id ? "atualizada" : "registrada"} com sucesso!`, "success");
            this.ocultarFormulario("formReuniao");
            this.carregarDadosEquipe();
        }).catch(err => {
            console.error("Erro ao salvar reunião:", err);
            this.exibirNotificacao("Erro ao salvar reunião.", "error");
        });
    },
    
    salvarTreinamento: function() {
        const form = document.getElementById("formTreinamento");
        const id = form.getAttribute("data-id");
        const nome = form.elements["treinamentoNome"].value.trim();
        const data = form.elements["treinamentoData"].value;
        const validade = form.elements["treinamentoValidade"].value;
        const cargaHoraria = parseInt(form.elements["treinamentoCargaHoraria"].value) || null;
        const instrutor = form.elements["treinamentoInstrutor"].value.trim();
        const conteudo = form.elements["treinamentoConteudo"].value.trim();
        const participantes = Array.from(form.elements["treinamentoParticipantes"].selectedOptions).map(opt => parseInt(opt.value));
        
        if (!nome || !data) {
            this.exibirNotificacao("Nome e Data são obrigatórios.", "error");
            return;
        }
        
        const treinamento = {
            equipe: this.state.equipeSelecionada,
            nome: nome,
            data: data,
            validade: validade || null,
            cargaHoraria: cargaHoraria,
            instrutor: instrutor,
            conteudo: conteudo,
            participantes: participantes,
            dataAtualizacao: new Date().toISOString()
        };
        
        const storeName = "equipeTreinamentos";
        const promise = id 
            ? STORAGE.update(storeName, { ...treinamento, id: parseInt(id) }) 
            : STORAGE.add(storeName, { ...treinamento, dataCadastro: new Date().toISOString() });
            
        promise.then(() => {
            this.exibirNotificacao(`Treinamento ${id ? "atualizado" : "registrado"} com sucesso!`, "success");
            this.ocultarFormulario("formTreinamento");
            this.carregarDadosEquipe();
        }).catch(err => {
            console.error("Erro ao salvar treinamento:", err);
            this.exibirNotificacao("Erro ao salvar treinamento.", "error");
        });
    },
    
    salvarDocumento: function() {
        const form = document.getElementById("formDocumento");
        const id = form.getAttribute("data-id");
        const nome = form.elements["documentoNome"].value.trim();
        const tipo = form.elements["documentoTipo"].value;
        const data = form.elements["documentoData"].value;
        const descricao = form.elements["documentoDescricao"].value.trim();
        const arquivoInput = form.elements["documentoArquivo"];
        const arquivo = arquivoInput.files[0];
        
        if (!nome || !tipo) {
            this.exibirNotificacao("Nome e Tipo são obrigatórios.", "error");
            return;
        }
        
        const documentoBase = {
            equipe: this.state.equipeSelecionada,
            nome: nome,
            tipo: tipo,
            data: data || null,
            descricao: descricao,
            dataAtualizacao: new Date().toISOString()
        };
        
        const storeName = "equipeDocumentos";
        
        const finalizarSalvar = (docFinal) => {
            const promise = id 
                ? STORAGE.update(storeName, { ...docFinal, id: parseInt(id) }) 
                : STORAGE.add(storeName, { ...docFinal, dataCadastro: new Date().toISOString() });
                
            promise.then(() => {
                this.exibirNotificacao(`Documento ${id ? "atualizado" : "salvo"} com sucesso!`, "success");
                this.ocultarFormulario("formDocumento");
                this.carregarDadosEquipe();
            }).catch(err => {
                console.error("Erro ao salvar documento:", err);
                this.exibirNotificacao("Erro ao salvar documento.", "error");
            });
        };
        
        if (arquivo) {
            // Se um novo arquivo foi selecionado, lê como Data URL
            const reader = new FileReader();
            reader.onload = (event) => {
                const docComArquivo = {
                    ...documentoBase,
                    arquivoNome: arquivo.name,
                    arquivoTipo: arquivo.type,
                    arquivoDataUrl: event.target.result
                };
                finalizarSalvar(docComArquivo);
            };
            reader.onerror = (error) => {
                console.error("Erro ao ler arquivo:", error);
                this.exibirNotificacao("Erro ao processar o arquivo selecionado.", "error");
            };
            reader.readAsDataURL(arquivo);
        } else if (id) {
            // Se está editando e não selecionou novo arquivo, mantém o antigo (se houver)
            STORAGE.get(storeName, parseInt(id)).then(docExistente => {
                const docFinal = {
                    ...documentoBase,
                    arquivoNome: docExistente.arquivoNome || null,
                    arquivoTipo: docExistente.arquivoTipo || null,
                    arquivoDataUrl: docExistente.arquivoDataUrl || null
                };
                finalizarSalvar(docFinal);
            }).catch(err => {
                console.error("Erro ao buscar documento existente:", err);
                this.exibirNotificacao("Erro ao manter arquivo existente.", "error");
            });
        } else {
            // Se é novo e não selecionou arquivo
            finalizarSalvar(documentoBase);
        }
    },
    
    salvarEleicao: function() {
        if (this.state.equipeSelecionada !== "CIPA") return; // Segurança extra
        
        const form = document.getElementById("formEleicao");
        const id = form.getAttribute("data-id");
        const gestaoInicio = form.elements["eleicaoGestaoInicio"].value;
        const gestaoFim = form.elements["eleicaoGestaoFim"].value;
        const data = form.elements["eleicaoData"].value;
        const status = form.elements["eleicaoStatus"].value;
        const edital = form.elements["eleicaoEdital"].value.trim();
        const candidatos = Array.from(form.elements["eleicaoCandidatos"].selectedOptions).map(opt => parseInt(opt.value));
        const eleitores = Array.from(form.elements["eleicaoEleitores"].selectedOptions).map(opt => parseInt(opt.value));
        const resultados = form.elements["eleicaoResultados"].value.trim();
        
        if (!gestaoInicio || !gestaoFim || !data || !status) {
            this.exibirNotificacao("Gestão (Início e Fim), Data e Status são obrigatórios.", "error");
            return;
        }
        
        const eleicao = {
            equipe: "CIPA", // Sempre CIPA
            gestaoInicio: gestaoInicio,
            gestaoFim: gestaoFim,
            data: data,
            status: status,
            edital: edital,
            candidatos: candidatos,
            eleitores: eleitores,
            resultados: resultados,
            dataAtualizacao: new Date().toISOString()
        };
        
        const storeName = "equipeEleicoes";
        const promise = id 
            ? STORAGE.update(storeName, { ...eleicao, id: parseInt(id) }) 
            : STORAGE.add(storeName, { ...eleicao, dataCadastro: new Date().toISOString() });
            
        promise.then(() => {
            this.exibirNotificacao(`Eleição ${id ? "atualizada" : "registrada"} com sucesso!`, "success");
            this.ocultarFormulario("formEleicao");
            this.carregarDadosEquipe();
        }).catch(err => {
            console.error("Erro ao salvar eleição:", err);
            this.exibirNotificacao("Erro ao salvar eleição.", "error");
        });
    },
    
    // --- Funções de Ação (Visualizar, Editar, Excluir, Download) --- //
    
    adicionarEventosBotoesTabela: function(tbody) {
        tbody.querySelectorAll(".view-btn").forEach(btn => {
            btn.addEventListener("click", (e) => {
                const id = parseInt(e.currentTarget.getAttribute("data-id"));
                const type = e.currentTarget.getAttribute("data-type");
                this.visualizarItem(id, type);
            });
        });
        tbody.querySelectorAll(".edit-btn").forEach(btn => {
            btn.addEventListener("click", (e) => {
                const id = parseInt(e.currentTarget.getAttribute("data-id"));
                const type = e.currentTarget.getAttribute("data-type");
                this.mostrarFormulario(`form${type.charAt(0).toUpperCase() + type.slice(1)}`, id);
            });
        });
        tbody.querySelectorAll(".delete-btn").forEach(btn => {
            btn.addEventListener("click", (e) => {
                const id = parseInt(e.currentTarget.getAttribute("data-id"));
                const type = e.currentTarget.getAttribute("data-type");
                this.excluirItem(id, type);
            });
        });
        tbody.querySelectorAll(".download-btn:not(.disabled)").forEach(btn => {
            btn.addEventListener("click", (e) => {
                const id = parseInt(e.currentTarget.getAttribute("data-id"));
                this.downloadDocumento(id);
            });
        });
    },
    
    visualizarItem: function(id, type) {
        const storeName = `equipe${type.charAt(0).toUpperCase() + type.slice(1)}s`;
        STORAGE.get(storeName, id).then(item => {
            if (!item) {
                this.exibirNotificacao("Item não encontrado.", "error");
                return;
            }
            
            // Implementar lógica para exibir detalhes em um modal
            // Exemplo simples com alert:
            alert(`Visualizando ${type} ID ${id}:\n${JSON.stringify(item, null, 2)}`);
            
            // TODO: Criar um modal genérico ou específico para exibir detalhes
            // Ex: this.exibirDetalhesModal(item, type);
            
        }).catch(err => {
            console.error(`Erro ao visualizar ${type}:`, err);
            this.exibirNotificacao(`Erro ao carregar ${type} para visualização.`, "error");
        });
    },
    
    excluirItem: function(id, type) {
        if (!confirm(`Tem certeza que deseja excluir este item (${type})?`)) {
            return;
        }
        
        const storeName = `equipe${type.charAt(0).toUpperCase() + type.slice(1)}s`;
        STORAGE.remove(storeName, id).then(() => {
            this.exibirNotificacao(`${type.charAt(0).toUpperCase() + type.slice(1)} excluído com sucesso!`, "success");
            this.carregarDadosEquipe(); // Recarrega a lista
        }).catch(err => {
            console.error(`Erro ao excluir ${type}:`, err);
            this.exibirNotificacao(`Erro ao excluir ${type}.`, "error");
        });
    },
    
    downloadDocumento: function(id) {
        STORAGE.get("equipeDocumentos", id).then(doc => {
            if (!doc || !doc.arquivoDataUrl) {
                this.exibirNotificacao("Arquivo não encontrado ou inválido.", "error");
                return;
            }
            
            const link = document.createElement("a");
            link.href = doc.arquivoDataUrl;
            link.download = doc.arquivoNome || `documento_${id}`;
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            
        }).catch(err => {
            console.error("Erro ao fazer download do documento:", err);
            this.exibirNotificacao("Erro ao fazer download do documento.", "error");
        });
    },
    
    // --- Funções Utilitárias --- //
    
    preencherSelect: function(selectId, options, placeholder = "Selecione...", multiple = false) {
        const select = document.getElementById(selectId);
        if (!select) return;
        
        select.innerHTML = ""; // Limpar
        select.multiple = multiple;
        
        if (placeholder && !multiple) {
            const placeholderOption = document.createElement("option");
            placeholderOption.value = "";
            placeholderOption.textContent = placeholder;
            placeholderOption.disabled = true;
            placeholderOption.selected = true;
            select.appendChild(placeholderOption);
        }
        
        options.forEach(optionData => {
            const option = document.createElement("option");
            if (typeof optionData === "string") {
                option.value = optionData;
                option.textContent = optionData;
            } else {
                option.value = optionData.value;
                option.textContent = optionData.text;
            }
            select.appendChild(option);
        });
    },
    
    exibirNotificacao: function(mensagem, tipo) {
        if (typeof DASHBOARD !== "undefined" && DASHBOARD.exibirNotificacao) {
            DASHBOARD.exibirNotificacao(mensagem, tipo);
        } else {
            alert(`[${tipo.toUpperCase()}] ${mensagem}`);
        }
    }
};

// Inicializar
document.addEventListener("DOMContentLoaded", () => {
    if (document.querySelector(".brigada-cipa-container")) {
        BRIGADA_CIPA.init();
    }
});
