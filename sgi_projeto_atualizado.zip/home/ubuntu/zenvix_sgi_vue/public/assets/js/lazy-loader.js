/**
 * ZENVIX SGI - Módulo de Lazy Loading para imagens
 * 
 * Este módulo implementa o carregamento preguiçoso (lazy loading) de imagens,
 * melhorando a performance de carregamento das páginas.
 */

const LAZY_LOADER = {
    /**
     * Inicializa o lazy loading para imagens
     */
    init: function() {
        console.log("Inicializando lazy loading para imagens...");
        
        // Verificar se o navegador suporta IntersectionObserver
        if ('IntersectionObserver' in window) {
            this.setupIntersectionObserver();
        } else {
            this.loadAllImages(); // Fallback para navegadores que não suportam
        }
        
        console.log("Lazy loading inicializado.");
    },
    
    /**
     * Configura o IntersectionObserver para monitorar imagens
     */
    setupIntersectionObserver: function() {
        const options = {
            root: null, // viewport
            rootMargin: '0px',
            threshold: 0.1 // 10% da imagem visível
        };
        
        const observer = new IntersectionObserver((entries, observer) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    this.loadImage(entry.target);
                    observer.unobserve(entry.target);
                }
            });
        }, options);
        
        // Observar todas as imagens com atributo data-src
        document.querySelectorAll('img[data-src]').forEach(img => {
            observer.observe(img);
        });
        
        // Observar backgrounds com data-bg
        document.querySelectorAll('[data-bg]').forEach(el => {
            observer.observe(el);
        });
    },
    
    /**
     * Carrega uma imagem específica
     * @param {HTMLElement} element - Elemento de imagem a ser carregado
     */
    loadImage: function(element) {
        if (element.tagName.toLowerCase() === 'img') {
            // Carregar src da imagem
            if (element.dataset.src) {
                element.src = element.dataset.src;
                delete element.dataset.src;
            }
            
            // Carregar srcset se existir
            if (element.dataset.srcset) {
                element.srcset = element.dataset.srcset;
                delete element.dataset.srcset;
            }
        } else if (element.dataset.bg) {
            // Carregar background-image
            element.style.backgroundImage = `url('${element.dataset.bg}')`;
            delete element.dataset.bg;
        }
        
        // Adicionar classe para fade-in
        element.classList.add('lazy-loaded');
    },
    
    /**
     * Carrega todas as imagens (fallback)
     */
    loadAllImages: function() {
        // Carregar todas as imagens com data-src
        document.querySelectorAll('img[data-src]').forEach(img => {
            img.src = img.dataset.src;
            delete img.dataset.src;
            
            if (img.dataset.srcset) {
                img.srcset = img.dataset.srcset;
                delete img.dataset.srcset;
            }
            
            img.classList.add('lazy-loaded');
        });
        
        // Carregar todos os backgrounds com data-bg
        document.querySelectorAll('[data-bg]').forEach(el => {
            el.style.backgroundImage = `url('${el.dataset.bg}')`;
            delete el.dataset.bg;
            el.classList.add('lazy-loaded');
        });
    }
};

// Inicializar quando o DOM estiver pronto
document.addEventListener('DOMContentLoaded', () => {
    LAZY_LOADER.init();
});
