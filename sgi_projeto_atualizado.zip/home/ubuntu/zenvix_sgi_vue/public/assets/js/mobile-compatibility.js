/**
 * ZENVIX SGI - Módulo de Compatibilidade Mobile
 * 
 * Este módulo implementa ajustes específicos para garantir compatibilidade
 * com dispositivos móveis, especialmente no ambiente Spck Android.
 */

document.addEventListener('DOMContentLoaded', function() {
    // --- Detecção de Ambiente ---
    const isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
    const isAndroid = /Android/i.test(navigator.userAgent);
    const isSpckEditor = navigator.userAgent.includes('Spck');
    
    // --- Configurações ---
    const VIEWPORT_HEIGHT_FIX = isAndroid || isSpckEditor; // Aplicar fix de altura de viewport
    const DISABLE_COMPLEX_ANIMATIONS = isAndroid || isSpckEditor; // Desabilitar animações complexas
    const USE_LOCALSTORAGE_FALLBACK = isSpckEditor; // Usar fallback para localStorage
    
    // --- Inicialização ---
    function init() {
        console.log("Inicializando módulo de compatibilidade mobile...");
        
        // Aplicar ajustes específicos para mobile
        if (isMobile) {
            applyMobileAdjustments();
        }
        
        // Aplicar ajustes específicos para Android
        if (isAndroid) {
            applyAndroidAdjustments();
        }
        
        // Aplicar ajustes específicos para Spck Editor
        if (isSpckEditor) {
            applySpckEditorAdjustments();
        }
        
        // Configurar fallbacks para recursos não suportados
        setupFallbacks();
        
        console.log("Módulo de compatibilidade mobile inicializado.");
    }
    
    // --- Ajustes para Dispositivos Móveis ---
    function applyMobileAdjustments() {
        // Corrigir problema de altura em dispositivos móveis
        if (VIEWPORT_HEIGHT_FIX) {
            fixViewportHeight();
            window.addEventListener('resize', fixViewportHeight);
            window.addEventListener('orientationchange', fixViewportHeight);
        }
        
        // Melhorar desempenho em dispositivos móveis
        if (DISABLE_COMPLEX_ANIMATIONS) {
            disableComplexAnimations();
        }
        
        // Ajustar tamanho de toque para elementos interativos
        adjustTouchTargets();
        
        // Garantir que o zoom esteja desabilitado
        ensureProperViewport();
    }
    
    // --- Ajustes Específicos para Android ---
    function applyAndroidAdjustments() {
        // Corrigir problemas de renderização em WebView do Android
        fixAndroidWebViewIssues();
        
        // Ajustar comportamento de teclado virtual
        handleVirtualKeyboard();
    }
    
    // --- Ajustes Específicos para Spck Editor ---
    function applySpckEditorAdjustments() {
        // Implementar fallback para localStorage
        if (USE_LOCALSTORAGE_FALLBACK) {
            setupLocalStorageFallback();
        }
        
        // Simplificar efeitos visuais para melhor compatibilidade
        simplifyVisualEffects();
    }
    
    // --- Funções de Ajuste ---
    
    /**
     * Corrige problemas de altura de viewport em dispositivos móveis
     */
    function fixViewportHeight() {
        // Usar altura da janela como altura do viewport
        const vh = window.innerHeight * 0.01;
        document.documentElement.style.setProperty('--vh', `${vh}px`);
        
        // Ajustar altura de elementos que usam 100vh
        document.querySelectorAll('.sidebar, .main-content, .login-page').forEach(el => {
            el.style.height = `calc(var(--vh, 1vh) * 100)`;
        });
    }
    
    /**
     * Desabilita animações complexas para melhorar desempenho
     */
    function disableComplexAnimations() {
        // Adicionar classe ao body para controlar animações via CSS
        document.body.classList.add('reduced-motion');
        
        // Remover animações que podem causar problemas de desempenho
        const animatedElements = document.querySelectorAll('.fade-in, .slide-in-up, .slide-in-left, .slide-in-right');
        animatedElements.forEach(el => {
            el.style.animation = 'none';
            el.style.opacity = '1';
            el.style.transform = 'none';
        });
    }
    
    /**
     * Ajusta tamanho de elementos interativos para melhor experiência de toque
     */
    function adjustTouchTargets() {
        // Aumentar área de toque para botões e links
        const touchTargets = document.querySelectorAll('button, a, .dropdown-toggle, input[type="checkbox"], input[type="radio"]');
        touchTargets.forEach(el => {
            // Garantir tamanho mínimo de 44x44px para área de toque (recomendação WCAG)
            if (el.offsetWidth < 44 || el.offsetHeight < 44) {
                el.style.minWidth = '44px';
                el.style.minHeight = '44px';
                
                // Para elementos inline, adicionar padding
                if (window.getComputedStyle(el).display === 'inline') {
                    el.style.display = 'inline-block';
                    el.style.padding = '10px';
                }
            }
        });
    }
    
    /**
     * Garante configuração correta do viewport
     */
    function ensureProperViewport() {
        // Verificar se a meta tag viewport existe
        let viewportMeta = document.querySelector('meta[name="viewport"]');
        
        // Se não existir, criar
        if (!viewportMeta) {
            viewportMeta = document.createElement('meta');
            viewportMeta.name = 'viewport';
            document.head.appendChild(viewportMeta);
        }
        
        // Configurar viewport para evitar zoom indesejado
        viewportMeta.content = 'width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no';
    }
    
    /**
     * Corrige problemas específicos de WebView do Android
     */
    function fixAndroidWebViewIssues() {
        // Corrigir problema de posicionamento fixed
        document.querySelectorAll('.sidebar, .theme-toggle, .sidebar-toggle, #notification-container').forEach(el => {
            if (window.getComputedStyle(el).position === 'fixed') {
                el.style.position = 'absolute';
            }
        });
        
        // Corrigir problema de backdrop-filter
        if (!CSS.supports('backdrop-filter', 'blur(10px)')) {
            document.querySelectorAll('.glass-card').forEach(el => {
                el.style.backgroundColor = 'rgba(255, 255, 255, 0.9)';
                
                // Se for tema escuro, ajustar
                if (document.documentElement.getAttribute('data-theme') === 'dark') {
                    el.style.backgroundColor = 'rgba(20, 20, 40, 0.9)';
                }
            });
        }
    }
    
    /**
     * Ajusta comportamento quando teclado virtual é exibido
     */
    function handleVirtualKeyboard() {
        // Detectar quando o teclado virtual é exibido
        const inputs = document.querySelectorAll('input, textarea');
        inputs.forEach(input => {
            input.addEventListener('focus', () => {
                // Rolar para o elemento em foco
                setTimeout(() => {
                    input.scrollIntoView({ behavior: 'smooth', block: 'center' });
                }, 300);
            });
        });
    }
    
    /**
     * Implementa fallback para localStorage em ambientes problemáticos
     */
    function setupLocalStorageFallback() {
        // Verificar se localStorage está funcionando corretamente
        try {
            localStorage.setItem('test', 'test');
            localStorage.removeItem('test');
        } catch (e) {
            // Criar fallback usando variáveis em memória
            console.warn('LocalStorage não disponível, usando fallback em memória');
            
            const memoryStorage = {};
            
            // Substituir métodos do localStorage
            Storage.prototype.setItem = function(key, value) {
                memoryStorage[key] = value.toString();
            };
            
            Storage.prototype.getItem = function(key) {
                return memoryStorage[key] || null;
            };
            
            Storage.prototype.removeItem = function(key) {
                delete memoryStorage[key];
            };
            
            Storage.prototype.clear = function() {
                Object.keys(memoryStorage).forEach(key => {
                    delete memoryStorage[key];
                });
            };
        }
    }
    
    /**
     * Simplifica efeitos visuais para melhor compatibilidade
     */
    function simplifyVisualEffects() {
        // Remover efeitos de glassmorphism
        document.querySelectorAll('.glass-card').forEach(el => {
            el.classList.remove('glass-card');
            el.classList.add('card');
        });
        
        // Simplificar sombras
        document.querySelectorAll('.card, button, .button').forEach(el => {
            el.style.boxShadow = '0 2px 5px rgba(0, 0, 0, 0.2)';
        });
        
        // Remover marca d'água de fundo
        const watermark = document.querySelector('.soc-watermark');
        if (watermark) {
            watermark.style.display = 'none';
        }
    }
    
    /**
     * Configura fallbacks para recursos não suportados
     */
    function setupFallbacks() {
        // Fallback para fetch API
        if (!window.fetch) {
            console.warn('Fetch API não suportada, usando XMLHttpRequest como fallback');
            
            window.fetch = function(url, options) {
                return new Promise((resolve, reject) => {
                    const xhr = new XMLHttpRequest();
                    xhr.open(options?.method || 'GET', url);
                    
                    if (options?.headers) {
                        Object.keys(options.headers).forEach(key => {
                            xhr.setRequestHeader(key, options.headers[key]);
                        });
                    }
                    
                    xhr.onload = function() {
                        const response = {
                            ok: xhr.status >= 200 && xhr.status < 300,
                            status: xhr.status,
                            statusText: xhr.statusText,
                            headers: new Headers(),
                            url: xhr.responseURL,
                            text: () => Promise.resolve(xhr.responseText),
                            json: () => Promise.resolve(JSON.parse(xhr.responseText))
                        };
                        
                        resolve(response);
                    };
                    
                    xhr.onerror = function() {
                        reject(new TypeError('Network request failed'));
                    };
                    
                    xhr.send(options?.body);
                });
            };
        }
        
        // Fallback para Promise
        if (!window.Promise) {
            console.warn('Promise não suportada, carregando polyfill');
            
            // Implementação simplificada de Promise
            window.Promise = function(executor) {
                let state = 'pending';
                let value = null;
                let handlers = [];
                
                function resolve(result) {
                    if (state !== 'pending') return;
                    state = 'fulfilled';
                    value = result;
                    handlers.forEach(handle);
                }
                
                function reject(error) {
                    if (state !== 'pending') return;
                    state = 'rejected';
                    value = error;
                    handlers.forEach(handle);
                }
                
                function handle(handler) {
                    if (state === 'pending') {
                        handlers.push(handler);
                    } else {
                        if (state === 'fulfilled' && typeof handler.onFulfilled === 'function') {
                            handler.onFulfilled(value);
                        }
                        if (state === 'rejected' && typeof handler.onRejected === 'function') {
                            handler.onRejected(value);
                        }
                    }
                }
                
                this.then = function(onFulfilled, onRejected) {
                    return new Promise((resolve, reject) => {
                        handle({
                            onFulfilled: function(result) {
                                if (typeof onFulfilled === 'function') {
                                    try {
                                        resolve(onFulfilled(result));
                                    } catch (ex) {
                                        reject(ex);
                                    }
                                } else {
                                    resolve(result);
                                }
                            },
                            onRejected: function(error) {
                                if (typeof onRejected === 'function') {
                                    try {
                                        resolve(onRejected(error));
                                    } catch (ex) {
                                        reject(ex);
                                    }
                                } else {
                                    reject(error);
                                }
                            }
                        });
                    });
                };
                
                this.catch = function(onRejected) {
                    return this.then(null, onRejected);
                };
                
                try {
                    executor(resolve, reject);
                } catch (error) {
                    reject(error);
                }
            };
        }
    }
    
    // Inicializar o módulo
    init();
});
