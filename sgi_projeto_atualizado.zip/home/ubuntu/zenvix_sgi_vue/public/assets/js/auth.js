// auth.js - Versão corrigida para ambiente mobile

document.addEventListener("DOMContentLoaded", () => {
    // --- DOM Elements ---
    const loginForm = document.getElementById("loginForm");
    const usernameInput = document.getElementById("username");
    const passwordInput = document.getElementById("password");
    const errorElement = document.getElementById("errorLogin");
    const loginButton = document.getElementById("loginButton");
    const rememberMeCheckbox = document.getElementById("rememberMe");
    const forgotPasswordLink = document.getElementById("forgotPassword");
    
    // --- Configurações de Segurança ---
    const MAX_LOGIN_ATTEMPTS = 5; // Máximo de tentativas antes de bloqueio
    const LOCKOUT_TIME = 5 * 60 * 1000; // 5 minutos em milissegundos
    
    // --- Credenciais Válidas ---
    // ATENÇÃO: Em produção, NUNCA armazene senhas no frontend.
    // Isso é apenas para demonstração. Use um backend seguro para autenticação.
    const validCredentials = [
        { username: "admin", password: "admin123", role: "admin", name: "Administrador" },
        { username: "tecnico", password: "tecnico123", role: "tecnico", name: "Técnico SST" },
        { username: "medico", password: "medico123", role: "medico", name: "Médico do Trabalho" }
    ];
    
    // --- Funções de Segurança ---
    
    /**
     * Verifica se o usuário está bloqueado por excesso de tentativas.
     * @returns {boolean} True se o usuário está bloqueado, false caso contrário.
     */
    function isUserLocked() {
        const lockoutUntil = parseInt(localStorage.getItem("loginLockoutUntil") || "0");
        if (lockoutUntil > Date.now()) {
            const remainingMinutes = Math.ceil((lockoutUntil - Date.now()) / 60000);
            showError(`Conta temporariamente bloqueada. Tente novamente em ${remainingMinutes} minuto(s).`);
            return true;
        }
        return false;
    }
    
    /**
     * Incrementa o contador de tentativas de login e verifica se deve bloquear.
     * @returns {boolean} True se o usuário excedeu o limite de tentativas.
     */
    function incrementLoginAttempts() {
        const attempts = parseInt(localStorage.getItem("loginAttempts") || "0") + 1;
        localStorage.setItem("loginAttempts", attempts.toString());
        
        if (attempts >= MAX_LOGIN_ATTEMPTS) {
            const lockoutUntil = Date.now() + LOCKOUT_TIME;
            localStorage.setItem("loginLockoutUntil", lockoutUntil.toString());
            showError(`Muitas tentativas de login. Conta bloqueada por 5 minutos.`);
            return true;
        }
        return false;
    }
    
    /**
     * Reseta o contador de tentativas de login após login bem-sucedido.
     */
    function resetLoginAttempts() {
        localStorage.removeItem("loginAttempts");
        localStorage.removeItem("loginLockoutUntil");
    }
    
    /**
     * Exibe uma mensagem de erro na interface.
     * @param {string} message - A mensagem de erro a ser exibida.
     */
    function showError(message) {
        if (errorElement) {
            errorElement.textContent = message;
            errorElement.style.display = "block";
            
            // Adiciona classe para animação de shake
            if (loginForm) {
                loginForm.classList.add("shake");
                setTimeout(() => {
                    loginForm.classList.remove("shake");
                }, 500);
            }
        }
    }
    
    /**
     * Limpa mensagens de erro na interface.
     */
    function clearError() {
        if (errorElement) {
            errorElement.textContent = "";
            errorElement.style.display = "none";
        }
    }
    
    /**
     * Valida a força da senha.
     * @param {string} password - A senha a ser validada.
     * @returns {boolean} True se a senha é forte o suficiente.
     */
    function isStrongPassword(password) {
        // Simplificado para ambiente de teste
        return password.length >= 6;
    }
    
    /**
     * Valida o formato do nome de usuário.
     * @param {string} username - O nome de usuário a ser validado.
     * @returns {boolean} True se o nome de usuário é válido.
     */
    function isValidUsername(username) {
        // Simplificado para ambiente de teste
        return username.length >= 3;
    }
    
    /**
     * Sanitiza uma string para prevenir XSS.
     * @param {string} input - A string a ser sanitizada.
     * @returns {string} A string sanitizada.
     */
    function sanitizeInput(input) {
        const div = document.createElement('div');
        div.textContent = input;
        return div.innerHTML;
    }
    
    // --- Funções de Autenticação ---
    
    /**
     * Verifica se o usuário já está logado e redireciona para o dashboard.
     * Corrigido para evitar loops de redirecionamento.
     */
    function checkLoggedInStatus() {
        // Verifica se estamos na página de login
        const isLoginPage = window.location.pathname.includes('login.html');
        
        const isLoggedIn = localStorage.getItem("loggedIn") === "true";
        const sessionExpiry = parseInt(localStorage.getItem("sessionExpiry") || "0");
        
        if (isLoggedIn && sessionExpiry > Date.now()) {
            // Usuário está logado e sessão válida
            if (isLoginPage) {
                // Redireciona para dashboard apenas se estiver na página de login
                window.location.href = "dashboard.html";
            }
            return true;
        } else if (isLoggedIn) {
            // Sessão expirada, limpa dados
            logout(false);
        }
        
        // Usuário não está logado
        if (!isLoginPage && !window.location.pathname.includes('index.html')) {
            // Se não estiver na página de login ou index, redireciona para login
            window.location.href = "login.html";
            return false;
        }
        
        return false;
    }
    
    /**
     * Realiza o logout do usuário.
     * @param {boolean} redirect - Se deve redirecionar para a página de login.
     */
    function logout(redirect = true) {
        localStorage.removeItem("loggedIn");
        localStorage.removeItem("username");
        localStorage.removeItem("userRole");
        localStorage.removeItem("userName");
        localStorage.removeItem("sessionExpiry");
        
        if (redirect) {
            // Evita loops de redirecionamento verificando se já está na página de login
            if (!window.location.pathname.includes('login.html')) {
                window.location.href = "login.html";
            }
        }
    }
    
    /**
     * Lida com a tentativa de login.
     * @param {Event} event - O evento de submit do formulário.
     */
    function handleLogin(event) {
        if (event) {
            event.preventDefault();
        }
        
        // Limpa erros anteriores
        clearError();
        
        // Verifica se o usuário está bloqueado
        if (isUserLocked()) {
            return;
        }
        
        // Obtém e sanitiza os valores dos campos
        const username = sanitizeInput(usernameInput.value.trim());
        const password = passwordInput.value.trim(); // Não sanitizamos a senha
        const rememberMe = rememberMeCheckbox ? rememberMeCheckbox.checked : false;
        
        // Validação básica de campos
        if (!username || !password) {
            showError("Por favor, preencha usuário e senha.");
            return;
        }
        
        // Validação de formato de usuário
        if (!isValidUsername(username)) {
            showError("Nome de usuário inválido. Use pelo menos 3 caracteres.");
            return;
        }
        
        // Simula processamento (UX)
        if (loginButton) {
            loginButton.disabled = true;
            loginButton.innerHTML = '<i class="fas fa-circle-notch fa-spin"></i> Autenticando...';
        }
        
        // Simula uma chamada de API com timeout
        setTimeout(() => {
            // Verifica as credenciais
            const user = validCredentials.find(
                cred => cred.username === username && cred.password === password
            );
            
            if (user) {
                // Login bem-sucedido
                resetLoginAttempts();
                
                // Define o tempo de expiração da sessão (24 horas ou 30 dias se "lembrar-me")
                const expiryTime = rememberMe ? 30 * 24 * 60 * 60 * 1000 : 24 * 60 * 60 * 1000;
                const sessionExpiry = Date.now() + expiryTime;
                
                // Armazena dados da sessão
                localStorage.setItem("loggedIn", "true");
                localStorage.setItem("username", username);
                localStorage.setItem("userRole", user.role);
                localStorage.setItem("userName", user.name);
                localStorage.setItem("sessionExpiry", sessionExpiry.toString());
                localStorage.setItem("lastLogin", new Date().toISOString());
                
                // Redireciona para o dashboard com um pequeno atraso para evitar problemas de renderização
                setTimeout(() => {
                    window.location.href = "dashboard.html";
                }, 100);
            } else {
                // Login falhou
                if (incrementLoginAttempts()) {
                    // Usuário excedeu tentativas, já mostramos mensagem em incrementLoginAttempts()
                } else {
                    const attempts = parseInt(localStorage.getItem("loginAttempts") || "0");
                    const remainingAttempts = MAX_LOGIN_ATTEMPTS - attempts;
                    showError(`Usuário ou senha inválidos. Tentativas restantes: ${remainingAttempts}`);
                }
                
                // Reseta o botão
                if (loginButton) {
                    loginButton.disabled = false;
                    loginButton.innerHTML = 'Entrar';
                }
            }
        }, 500); // Reduzido para 500ms para melhor experiência em mobile
    }
    
    // --- Funções de Recuperação de Senha ---
    
    /**
     * Lida com a solicitação de recuperação de senha.
     * @param {Event} event - O evento de clique.
     */
    function handleForgotPassword(event) {
        event.preventDefault();
        
        const username = prompt("Digite seu nome de usuário para recuperar a senha:");
        
        if (username) {
            // Em um sistema real, enviaria um email ou SMS
            // Aqui apenas simulamos uma mensagem
            alert(`Se o usuário ${username} existir em nosso sistema, enviaremos instruções de recuperação de senha para o email associado.`);
        }
    }
    
    // --- Event Listeners ---
    
    // Verifica se o usuário já está logado
    if (checkLoggedInStatus()) {
        return; // Impede a execução do restante do script se já estiver logado
    }
    
    // Adiciona o listener ao formulário
    if (loginForm) {
        loginForm.addEventListener("submit", handleLogin);
    }
    
    // Listener para recuperação de senha
    if (forgotPasswordLink) {
        forgotPasswordLink.addEventListener("click", handleForgotPassword);
    }
    
    // Listener para tecla Enter no campo de senha
    if (passwordInput) {
        passwordInput.addEventListener("keypress", (event) => {
            if (event.key === "Enter") {
                event.preventDefault(); // Previne comportamento padrão
                handleLogin(null);
            }
        });
    }
    
    // Listener para tecla Enter no campo de usuário
    if (usernameInput) {
        usernameInput.addEventListener("keypress", (event) => {
            if (event.key === "Enter") {
                event.preventDefault(); // Previne comportamento padrão
                passwordInput.focus();
            }
        });
    }
    
    // Adiciona função de logout ao objeto window para acesso global
    window.logoutUser = logout;
    
    // --- Inicialização ---
    
    // Foca no campo de usuário ao carregar a página
    if (usernameInput) {
        setTimeout(() => {
            usernameInput.focus();
        }, 300); // Pequeno atraso para garantir que a página esteja pronta
    }
    
    // Verifica se há um nome de usuário salvo (para "lembrar-me")
    const savedUsername = localStorage.getItem("rememberedUsername");
    if (savedUsername && usernameInput && rememberMeCheckbox) {
        usernameInput.value = savedUsername;
        rememberMeCheckbox.checked = true;
        passwordInput.focus();
    }
});
