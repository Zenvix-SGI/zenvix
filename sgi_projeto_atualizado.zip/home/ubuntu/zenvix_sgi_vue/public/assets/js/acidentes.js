/**
 * ZENVIX SGI - Módulo de Gestão de Acidentes e Incidentes
 * 
 * Este arquivo contém funções para registrar, analisar e prevenir acidentes e incidentes de trabalho.
 */

// Namespace para evitar conflitos
const ACIDENTE = {
    // Configurações
    config: {
        limitePorPagina: 10
    },
    
    // Dados
    data: {
        tiposOcorrencia: [
            'Acidente Típico', 
            'Acidente de Trajeto', 
            'Doença Ocupacional', 
            'Incidente (Quase Acidente)'
        ],
        partesCorpo: [
            'Cabeça', 'Olhos', 'Pescoço', 'Tronco', 'Membros Superiores', 
            'Mãos', 'Membros Inferiores', 'Pés', 'Múltiplas Partes', 'Outro'
        ],
        agentesCausadores: [
            'Máquinas e Equipamentos', 'Ferramentas Manuais', 'Queda de Altura', 
            'Queda de Mesmo Nível', 'Impacto Contra Objeto', 'Queda de Objeto', 
            'Esforço Excessivo', 'Exposição a Ruído', 'Exposição a Agentes Químicos', 
            'Exposição a Agentes Biológicos', 'Choque Elétrico', 'Incêndio/Explosão', 
            'Acidente de Trânsito', 'Violência/Agressão', 'Outro'
        ],
        tiposLesao: [
            'Corte/Laceração', 'Fratura', 'Contusão/Hematoma', 'Queimadura', 
            'Amputação', 'Lesão Ocular', 'Entorse/Distensão', 'Intoxicação', 
            'Lesão Auditiva', 'Doença Respiratória', 'Dermatose', 'LER/DORT', 
            'Estresse/Psicológico', 'Fatalidade', 'Sem Lesão (Incidente)', 'Outro'
        ]
    },
    
    /**
     * Inicializa o módulo de Acidentes e Incidentes
     */
    init: function() {
        console.log('Inicializando módulo de Acidentes e Incidentes...');
        
        if (!STORAGE.isAuthenticated()) {
            console.warn('Usuário não autenticado. Redirecionando para login...');
            window.location.href = 'login.html';
            return;
        }
        
        this.initComponents();
        this.setupEvents();
        this.carregarDados();
        
        console.log('Módulo de Acidentes e Incidentes inicializado.');
    },
    
    /**
     * Inicializa componentes da interface
     */
    initComponents: function() {
        // Preencher selects
        this.preencherSelect('tipoOcorrencia', this.data.tiposOcorrencia);
        this.preencherSelect('parteCorpoAtingida', this.data.partesCorpo);
        this.preencherSelect('agenteCausador', this.data.agentesCausadores);
        this.preencherSelect('tipoLesao', this.data.tiposLesao);
        
        // Preencher selects de filtro
        this.preencherSelect('filtroTipoOcorrencia', this.data.tiposOcorrencia, 'Todos');
        this.preencherSelect('filtroTipoLesao', this.data.tiposLesao, 'Todas');
        
        // Inicializar datepickers
        const datepickers = document.querySelectorAll('.datepicker');
        datepickers.forEach(datepicker => {
            datepicker.addEventListener('change', function() {
                const regex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
                if (this.value && !regex.test(this.value)) {
                    this.value = '';
                    alert('Formato de data inválido. Use DD/MM/AAAA.');
                }
            });
        });
        
        // Carregar funcionários para selects
        STORAGE.getAll('funcionarios').then(funcionarios => {
            funcionarios.sort((a, b) => a.nome.localeCompare(b.nome));
            this.preencherSelect('funcionarioEnvolvido', funcionarios.filter(f => f.ativo).map(f => ({ value: f.id, text: f.nome })), 'Selecione...');
            this.preencherSelect('filtroFuncionario', funcionarios.filter(f => f.ativo).map(f => ({ value: f.id, text: f.nome })), 'Todos');
        }).catch(error => console.error('Erro ao carregar funcionários:', error));
        
        // Carregar setores para selects
        STORAGE.getAll('setores').then(setores => {
            setores.sort((a, b) => a.nome.localeCompare(b.nome));
            this.preencherSelect('setorOcorrencia', setores.map(s => ({ value: s.id, text: s.nome })), 'Selecione...');
            this.preencherSelect('filtroSetor', setores.map(s => ({ value: s.id, text: s.nome })), 'Todos');
        }).catch(error => console.error('Erro ao carregar setores:', error));
    },
    
    /**
     * Preenche um elemento select com opções
     * @param {string} selectId - ID do elemento select
     * @param {Array} options - Array de strings ou objetos {value, text}
     * @param {string|null} placeholder - Texto da opção inicial (opcional)
     */
    preencherSelect: function(selectId, options, placeholder = 'Selecione...') {
        const select = document.getElementById(selectId);
        if (!select) return;
        
        select.innerHTML = ''; // Limpar opções existentes
        
        if (placeholder) {
            const placeholderOption = document.createElement('option');
            placeholderOption.value = '';
            placeholderOption.textContent = placeholder;
            select.appendChild(placeholderOption);
        }
        
        options.forEach(optionData => {
            const option = document.createElement('option');
            if (typeof optionData === 'string') {
                option.value = optionData;
                option.textContent = optionData;
            } else {
                option.value = optionData.value;
                option.textContent = optionData.text;
            }
            select.appendChild(option);
        });
    },
    
    /**
     * Configura eventos da interface
     */
    setupEvents: function() {
        // Botão Nova Ocorrência
        const btnNovaOcorrencia = document.getElementById('btnNovaOcorrencia');
        if (btnNovaOcorrencia) {
            btnNovaOcorrencia.addEventListener('click', () => this.mostrarFormulario());
        }
        
        // Formulário de Ocorrência
        const formOcorrencia = document.getElementById('formOcorrencia');
        if (formOcorrencia) {
            formOcorrencia.addEventListener('submit', (e) => {
                e.preventDefault();
                this.salvarOcorrencia();
            });
        }
        
        // Botão Cancelar (Formulário)
        const btnCancelar = document.getElementById('btnCancelar');
        if (btnCancelar) {
            btnCancelar.addEventListener('click', () => this.mostrarListagem());
        }
        
        // Botões de Filtro
        const btnFiltrar = document.getElementById('btnFiltrar');
        if (btnFiltrar) {
            btnFiltrar.addEventListener('click', () => this.filtrarOcorrencias());
        }
        
        const btnLimparFiltros = document.getElementById('btnLimparFiltros');
        if (btnLimparFiltros) {
            btnLimparFiltros.addEventListener('click', () => this.limparFiltros());
        }
        
        // Botão Exportar
        const btnExportar = document.getElementById('btnExportar');
        if (btnExportar) {
            btnExportar.addEventListener('click', () => this.exportarDados());
        }
        
        // Checkbox CAT emitida
        const catEmitidaCheckbox = document.getElementById('catEmitida');
        const numeroCatInput = document.getElementById('numeroCat');
        if (catEmitidaCheckbox && numeroCatInput) {
            catEmitidaCheckbox.addEventListener('change', () => {
                numeroCatInput.disabled = !catEmitidaCheckbox.checked;
                if (!catEmitidaCheckbox.checked) {
                    numeroCatInput.value = '';
                }
            });
        }
    },
    
    /**
     * Carrega dados iniciais (ocorrências)
     */
    carregarDados: function() {
        STORAGE.getAll('acidentesIncidentes').then(ocorrencias => {
            this.exibirOcorrencias(ocorrencias);
            this.atualizarResumo(ocorrencias);
        }).catch(error => {
            console.error('Erro ao carregar ocorrências:', error);
            this.exibirNotificacao('Erro ao carregar dados de ocorrências', 'error');
        });
    },
    
    /**
     * Exibe ocorrências na tabela
     * @param {Array} ocorrencias - Lista de ocorrências
     */
    exibirOcorrencias: function(ocorrencias) {
        const tabela = document.getElementById('tabelaOcorrencias');
        if (!tabela) return;
        const tbody = tabela.querySelector('tbody');
        if (!tbody) return;
        
        tbody.innerHTML = '';
        
        if (ocorrencias.length === 0) {
            tbody.innerHTML = '<tr><td colspan="7" class="text-center">Nenhuma ocorrência registrada.</td></tr>';
            return;
        }
        
        Promise.all([
            STORAGE.getAll('funcionarios'),
            STORAGE.getAll('setores')
        ]).then(([funcionarios, setores]) => {
            const funcionariosMap = {};
            funcionarios.forEach(f => funcionariosMap[f.id] = f.nome);
            const setoresMap = {};
            setores.forEach(s => setoresMap[s.id] = s.nome);
            
            ocorrencias.forEach(ocorrencia => {
                const tr = document.createElement('tr');
                const dataOcorrencia = ocorrencia.dataOcorrencia ? new Date(ocorrencia.dataOcorrencia).toLocaleDateString('pt-BR') : '-';
                const nomeFuncionario = funcionariosMap[ocorrencia.funcionarioId] || 'Não informado';
                const nomeSetor = setoresMap[ocorrencia.setorId] || 'Não informado';
                const tipoLesao = ocorrencia.tipoLesao || 'N/A';
                const catStatus = ocorrencia.catEmitida ? `<span class="badge badge-success">Sim (${ocorrencia.numeroCat || 'N/A'})</span>` : '<span class="badge badge-secondary">Não</span>';
                
                tr.innerHTML = `
                    <td>${ocorrencia.tipoOcorrencia}</td>
                    <td>${dataOcorrencia}</td>
                    <td>${nomeFuncionario}</td>
                    <td>${nomeSetor}</td>
                    <td>${tipoLesao}</td>
                    <td>${catStatus}</td>
                    <td>
                        <button class="btn-sm view-btn" data-id="${ocorrencia.id}"><i class="fas fa-eye"></i></button>
                        <button class="btn-sm edit-btn" data-id="${ocorrencia.id}"><i class="fas fa-edit"></i></button>
                        <button class="btn-sm delete-btn" data-id="${ocorrencia.id}"><i class="fas fa-trash"></i></button>
                    </td>
                `;
                tbody.appendChild(tr);
            });
            
            // Adicionar eventos aos botões
            tbody.querySelectorAll('.view-btn').forEach(btn => btn.addEventListener('click', () => this.visualizarOcorrencia(parseInt(btn.dataset.id))));
            tbody.querySelectorAll('.edit-btn').forEach(btn => btn.addEventListener('click', () => this.editarOcorrencia(parseInt(btn.dataset.id))));
            tbody.querySelectorAll('.delete-btn').forEach(btn => btn.addEventListener('click', () => this.excluirOcorrencia(parseInt(btn.dataset.id))));
            
        }).catch(error => {
            console.error('Erro ao carregar dados de funcionários/setores:', error);
            tbody.innerHTML = '<tr><td colspan="7" class="text-center text-danger">Erro ao carregar dados auxiliares.</td></tr>';
        });
    },
    
    /**
     * Atualiza os cards de resumo
     * @param {Array} ocorrencias - Lista de ocorrências
     */
    atualizarResumo: function(ocorrencias) {
        const totalOcorrencias = ocorrencias.length;
        const totalAcidentes = ocorrencias.filter(o => o.tipoOcorrencia.includes('Acidente')).length;
        const totalIncidentes = ocorrencias.filter(o => o.tipoOcorrencia.includes('Incidente')).length;
        const totalComAfastamento = ocorrencias.filter(o => o.houveAfastamento).length;
        
        document.getElementById('totalOcorrencias').textContent = totalOcorrencias;
        document.getElementById('totalAcidentes').textContent = totalAcidentes;
        document.getElementById('totalIncidentes').textContent = totalIncidentes;
        document.getElementById('totalComAfastamento').textContent = totalComAfastamento;
    },
    
    /**
     * Mostra o formulário de cadastro/edição
     */
    mostrarFormulario: function(ocorrencia = null) {
        this.limparFormulario();
        const formContainer = document.getElementById('formContainer');
        const listContainer = document.getElementById('listContainer');
        const formTitle = document.getElementById('formTitle');
        
        if (ocorrencia) {
            formTitle.textContent = 'Editar Ocorrência';
            document.getElementById('formOcorrencia').setAttribute('data-id', ocorrencia.id);
            
            // Preencher campos
            document.getElementById('tipoOcorrencia').value = ocorrencia.tipoOcorrencia;
            document.getElementById('dataOcorrencia').value = ocorrencia.dataOcorrencia ? this.formatarDataInput(ocorrencia.dataOcorrencia) : '';
            document.getElementById('horaOcorrencia').value = ocorrencia.horaOcorrencia || '';
            document.getElementById('funcionarioEnvolvido').value = ocorrencia.funcionarioId;
            document.getElementById('setorOcorrencia').value = ocorrencia.setorId;
            document.getElementById('localOcorrencia').value = ocorrencia.localOcorrencia || '';
            document.getElementById('descricaoOcorrencia').value = ocorrencia.descricaoOcorrencia || '';
            document.getElementById('parteCorpoAtingida').value = ocorrencia.parteCorpoAtingida || '';
            document.getElementById('agenteCausador').value = ocorrencia.agenteCausador || '';
            document.getElementById('tipoLesao').value = ocorrencia.tipoLesao || '';
            document.getElementById('houveAfastamento').checked = ocorrencia.houveAfastamento || false;
            document.getElementById('diasAfastamento').value = ocorrencia.diasAfastamento || '';
            document.getElementById('catEmitida').checked = ocorrencia.catEmitida || false;
            document.getElementById('numeroCat').value = ocorrencia.numeroCat || '';
            document.getElementById('testemunhas').value = ocorrencia.testemunhas || '';
            document.getElementById('analiseCausa').value = ocorrencia.analiseCausa || '';
            document.getElementById('acoesCorretivas').value = ocorrencia.acoesCorretivas || '';
            
            // Habilitar/desabilitar campo CAT
            document.getElementById('numeroCat').disabled = !ocorrencia.catEmitida;
            
        } else {
            formTitle.textContent = 'Registrar Nova Ocorrência';
            document.getElementById('numeroCat').disabled = true; // Desabilitar por padrão
        }
        
        if (formContainer) formContainer.style.display = 'block';
        if (listContainer) listContainer.style.display = 'none';
    },
    
    /**
     * Mostra a listagem de ocorrências
     */
    mostrarListagem: function() {
        const formContainer = document.getElementById('formContainer');
        const listContainer = document.getElementById('listContainer');
        if (formContainer) formContainer.style.display = 'none';
        if (listContainer) listContainer.style.display = 'block';
        this.limparFormulario();
        this.carregarDados(); // Recarregar lista
    },
    
    /**
     * Limpa o formulário
     */
    limparFormulario: function() {
        const form = document.getElementById('formOcorrencia');
        if (form) {
            form.reset();
            form.removeAttribute('data-id');
        }
        const numeroCatInput = document.getElementById('numeroCat');
        if (numeroCatInput) numeroCatInput.disabled = true;
    },
    
    /**
     * Salva a ocorrência (nova ou edição)
     */
    salvarOcorrencia: function() {
        const form = document.getElementById('formOcorrencia');
        const id = form.getAttribute('data-id');
        
        // Coletar dados
        const ocorrencia = {
            tipoOcorrencia: document.getElementById('tipoOcorrencia').value,
            dataOcorrencia: this.formatarDataISO(document.getElementById('dataOcorrencia').value),
            horaOcorrencia: document.getElementById('horaOcorrencia').value,
            funcionarioId: parseInt(document.getElementById('funcionarioEnvolvido').value),
            setorId: parseInt(document.getElementById('setorOcorrencia').value),
            localOcorrencia: document.getElementById('localOcorrencia').value.trim(),
            descricaoOcorrencia: document.getElementById('descricaoOcorrencia').value.trim(),
            parteCorpoAtingida: document.getElementById('parteCorpoAtingida').value,
            agenteCausador: document.getElementById('agenteCausador').value,
            tipoLesao: document.getElementById('tipoLesao').value,
            houveAfastamento: document.getElementById('houveAfastamento').checked,
            diasAfastamento: document.getElementById('houveAfastamento').checked ? parseInt(document.getElementById('diasAfastamento').value) || 0 : 0,
            catEmitida: document.getElementById('catEmitida').checked,
            numeroCat: document.getElementById('catEmitida').checked ? document.getElementById('numeroCat').value.trim() : '',
            testemunhas: document.getElementById('testemunhas').value.trim(),
            analiseCausa: document.getElementById('analiseCausa').value.trim(),
            acoesCorretivas: document.getElementById('acoesCorretivas').value.trim(),
            dataRegistro: id ? undefined : new Date().toISOString(),
            dataAtualizacao: new Date().toISOString()
        };
        
        // Validar campos obrigatórios
        if (!ocorrencia.tipoOcorrencia || !ocorrencia.dataOcorrencia || isNaN(ocorrencia.funcionarioId) || isNaN(ocorrencia.setorId) || !ocorrencia.descricaoOcorrencia) {
            this.exibirNotificacao('Preencha todos os campos obrigatórios (*).', 'error');
            return;
        }
        
        // Salvar
        const promise = id 
            ? STORAGE.update('acidentesIncidentes', { ...ocorrencia, id: parseInt(id) }) 
            : STORAGE.add('acidentesIncidentes', ocorrencia);
            
        promise.then(() => {
            const acao = id ? 'atualizada' : 'registrada';
            this.exibirNotificacao(`Ocorrência ${acao} com sucesso!`, 'success');
            DASHBOARD.adicionarHistorico({ 
                tipo: id ? 'edicao' : 'criacao', 
                titulo: `Ocorrência ${acao}`, 
                descricao: `Ocorrência (${ocorrencia.tipoOcorrencia}) foi ${acao}.` 
            });
            this.mostrarListagem();
        }).catch(error => {
            console.error('Erro ao salvar ocorrência:', error);
            this.exibirNotificacao('Erro ao salvar ocorrência.', 'error');
        });
    },
    
    /**
     * Visualiza detalhes de uma ocorrência em um modal
     */
    visualizarOcorrencia: function(id) {
        STORAGE.get('acidentesIncidentes', id).then(ocorrencia => {
            if (!ocorrencia) {
                this.exibirNotificacao('Ocorrência não encontrada.', 'error');
                return;
            }
            
            Promise.all([
                ocorrencia.funcionarioId ? STORAGE.get('funcionarios', ocorrencia.funcionarioId) : Promise.resolve(null),
                ocorrencia.setorId ? STORAGE.get('setores', ocorrencia.setorId) : Promise.resolve(null)
            ]).then(([funcionario, setor]) => {
                const nomeFuncionario = funcionario ? funcionario.nome : 'Não informado';
                const nomeSetor = setor ? setor.nome : 'Não informado';
                const dataOcorrencia = ocorrencia.dataOcorrencia ? new Date(ocorrencia.dataOcorrencia).toLocaleDateString('pt-BR') : '-';
                const dataRegistro = ocorrencia.dataRegistro ? new Date(ocorrencia.dataRegistro).toLocaleString('pt-BR') : '-';
                const dataAtualizacao = ocorrencia.dataAtualizacao ? new Date(ocorrencia.dataAtualizacao).toLocaleString('pt-BR') : '-';
                
                const modal = document.createElement('div');
                modal.className = 'modal fade show';
                modal.style.display = 'block';
                modal.innerHTML = `
                    <div class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title">Detalhes da Ocorrência</h5>
                                <button type="button" class="close" data-dismiss="modal">&times;</button>
                            </div>
                            <div class="modal-body">
                                <div class="row mb-3">
                                    <div class="col-md-6"><strong>Tipo:</strong> ${ocorrencia.tipoOcorrencia}</div>
                                    <div class="col-md-6"><strong>Data:</strong> ${dataOcorrencia} ${ocorrencia.horaOcorrencia || ''}</div>
                                </div>
                                <div class="row mb-3">
                                    <div class="col-md-6"><strong>Funcionário:</strong> ${nomeFuncionario}</div>
                                    <div class="col-md-6"><strong>Setor:</strong> ${nomeSetor}</div>
                                </div>
                                <p><strong>Local Específico:</strong> ${ocorrencia.localOcorrencia || '-'}</p>
                                <p><strong>Descrição:</strong> ${ocorrencia.descricaoOcorrencia}</p>
                                <hr>
                                <div class="row mb-3">
                                    <div class="col-md-6"><strong>Parte do Corpo Atingida:</strong> ${ocorrencia.parteCorpoAtingida || '-'}</div>
                                    <div class="col-md-6"><strong>Agente Causador:</strong> ${ocorrencia.agenteCausador || '-'}</div>
                                </div>
                                <p><strong>Tipo de Lesão:</strong> ${ocorrencia.tipoLesao || '-'}</p>
                                <hr>
                                <div class="row mb-3">
                                    <div class="col-md-6"><strong>Houve Afastamento:</strong> ${ocorrencia.houveAfastamento ? 'Sim' : 'Não'}</div>
                                    <div class="col-md-6"><strong>Dias Afastado:</strong> ${ocorrencia.houveAfastamento ? (ocorrencia.diasAfastamento || 0) : '-'}</div>
                                </div>
                                <div class="row mb-3">
                                    <div class="col-md-6"><strong>CAT Emitida:</strong> ${ocorrencia.catEmitida ? 'Sim' : 'Não'}</div>
                                    <div class="col-md-6"><strong>Número CAT:</strong> ${ocorrencia.catEmitida ? (ocorrencia.numeroCat || '-') : '-'}</div>
                                </div>
                                <p><strong>Testemunhas:</strong> ${ocorrencia.testemunhas || '-'}</p>
                                <hr>
                                <p><strong>Análise da Causa:</strong> ${ocorrencia.analiseCausa || '-'}</p>
                                <p><strong>Ações Corretivas/Preventivas:</strong> ${ocorrencia.acoesCorretivas || '-'}</p>
                                <hr>
                                <small>Registrado em: ${dataRegistro} | Atualizado em: ${dataAtualizacao}</small>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Fechar</button>
                                <button type="button" class="btn btn-primary" id="btnEditarModal">Editar</button>
                            </div>
                        </div>
                    </div>
                `;
                
                document.body.appendChild(modal);
                const backdrop = document.createElement('div');
                backdrop.className = 'modal-backdrop fade show';
                document.body.appendChild(backdrop);
                document.body.classList.add('modal-open');
                
                modal.querySelector('[data-dismiss="modal"]').addEventListener('click', () => {
                    document.body.removeChild(modal);
                    document.body.removeChild(backdrop);
                    document.body.classList.remove('modal-open');
                });
                modal.querySelector('#btnEditarModal').addEventListener('click', () => {
                    document.body.removeChild(modal);
                    document.body.removeChild(backdrop);
                    document.body.classList.remove('modal-open');
                    this.editarOcorrencia(id);
                });
                
            }).catch(err => {
                 console.error('Erro ao buscar dados auxiliares:', err);
                 this.exibirNotificacao('Erro ao carregar detalhes da ocorrência.', 'error');
            });
        }).catch(error => {
            console.error('Erro ao visualizar ocorrência:', error);
            this.exibirNotificacao('Erro ao carregar ocorrência.', 'error');
        });
    },
    
    /**
     * Prepara para editar uma ocorrência existente
     */
    editarOcorrencia: function(id) {
        STORAGE.get('acidentesIncidentes', id).then(ocorrencia => {
            if (!ocorrencia) {
                this.exibirNotificacao('Ocorrência não encontrada.', 'error');
                return;
            }
            this.mostrarFormulario(ocorrencia);
        }).catch(error => {
            console.error('Erro ao carregar ocorrência para edição:', error);
            this.exibirNotificacao('Erro ao carregar ocorrência para edição.', 'error');
        });
    },
    
    /**
     * Exclui uma ocorrência
     */
    excluirOcorrencia: function(id) {
        if (confirm('Tem certeza que deseja excluir esta ocorrência? Esta ação não pode ser desfeita.')) {
            STORAGE.get('acidentesIncidentes', id).then(ocorrencia => {
                if (!ocorrencia) {
                    this.exibirNotificacao('Ocorrência não encontrada.', 'error');
                    return;
                }
                STORAGE.remove('acidentesIncidentes', id).then(() => {
                    this.exibirNotificacao('Ocorrência excluída com sucesso!', 'success');
                    DASHBOARD.adicionarHistorico({ tipo: 'exclusao', titulo: 'Ocorrência Excluída', descricao: `Ocorrência (${ocorrencia.tipoOcorrencia}) foi excluída.` });
                    this.carregarDados(); // Recarregar lista e resumo
                }).catch(error => {
                    console.error('Erro ao excluir ocorrência:', error);
                    this.exibirNotificacao('Erro ao excluir ocorrência.', 'error');
                });
            }).catch(error => {
                 console.error('Erro ao buscar ocorrência para exclusão:', error);
                 this.exibirNotificacao('Erro ao buscar ocorrência para exclusão.', 'error');
            });
        }
    },
    
    /**
     * Filtra ocorrências com base nos critérios selecionados
     */
    filtrarOcorrencias: function() {
        const filtros = {
            tipoOcorrencia: document.getElementById('filtroTipoOcorrencia').value,
            funcionarioId: document.getElementById('filtroFuncionario').value,
            setorId: document.getElementById('filtroSetor').value,
            tipoLesao: document.getElementById('filtroTipoLesao').value,
            periodo: document.getElementById('filtroPeriodo').value
        };
        
        STORAGE.getAll('acidentesIncidentes').then(ocorrencias => {
            let ocorrenciasFiltradas = ocorrencias;
            
            if (filtros.tipoOcorrencia) {
                ocorrenciasFiltradas = ocorrenciasFiltradas.filter(o => o.tipoOcorrencia === filtros.tipoOcorrencia);
            }
            if (filtros.funcionarioId) {
                ocorrenciasFiltradas = ocorrenciasFiltradas.filter(o => o.funcionarioId === parseInt(filtros.funcionarioId));
            }
            if (filtros.setorId) {
                ocorrenciasFiltradas = ocorrenciasFiltradas.filter(o => o.setorId === parseInt(filtros.setorId));
            }
            if (filtros.tipoLesao) {
                ocorrenciasFiltradas = ocorrenciasFiltradas.filter(o => o.tipoLesao === filtros.tipoLesao);
            }
            if (filtros.periodo) {
                const diasAtras = parseInt(filtros.periodo);
                const dataLimite = new Date();
                dataLimite.setDate(dataLimite.getDate() - diasAtras);
                ocorrenciasFiltradas = ocorrenciasFiltradas.filter(o => o.dataOcorrencia && new Date(o.dataOcorrencia) >= dataLimite);
            }
            
            this.exibirOcorrencias(ocorrenciasFiltradas);
            // Não atualizar resumo com dados filtrados para manter visão geral
            // this.atualizarResumo(ocorrenciasFiltradas);
        }).catch(error => {
            console.error('Erro ao filtrar ocorrências:', error);
            this.exibirNotificacao('Erro ao filtrar ocorrências.', 'error');
        });
    },
    
    /**
     * Limpa filtros e exibe todas as ocorrências
     */
    limparFiltros: function() {
        document.getElementById('filtroTipoOcorrencia').value = '';
        document.getElementById('filtroFuncionario').value = '';
        document.getElementById('filtroSetor').value = '';
        document.getElementById('filtroTipoLesao').value = '';
        document.getElementById('filtroPeriodo').value = '';
        this.carregarDados(); // Recarrega todos os dados
    },
    
    /**
     * Exporta dados de ocorrências para CSV
     */
    exportarDados: function() {
        Promise.all([
            STORAGE.getAll('acidentesIncidentes'),
            STORAGE.getAll('funcionarios'),
            STORAGE.getAll('setores')
        ]).then(([ocorrencias, funcionarios, setores]) => {
            const funcionariosMap = {};
            funcionarios.forEach(f => funcionariosMap[f.id] = f.nome);
            const setoresMap = {};
            setores.forEach(s => setoresMap[s.id] = s.nome);
            
            let csv = 'ID,Tipo,Data,Hora,Funcionário,Setor,Local,Descrição,Parte Corpo,Agente Causador,Tipo Lesão,Houve Afastamento,Dias Afastado,CAT Emitida,Número CAT,Testemunhas,Análise Causa,Ações Corretivas,Data Registro,Data Atualização\n';
            
            const escapar = (campo) => {
                if (campo === null || typeof campo === 'undefined') return '';
                const str = String(campo);
                if (str.includes(',') || str.includes('"') || str.includes('\n')) {
                    return `"${str.replace(/"/g, '""')}"`;
                }
                return str;
            };
            
            ocorrencias.forEach(o => {
                const dataOcorrencia = o.dataOcorrencia ? new Date(o.dataOcorrencia).toLocaleDateString('pt-BR') : '';
                const dataRegistro = o.dataRegistro ? new Date(o.dataRegistro).toLocaleString('pt-BR') : '';
                const dataAtualizacao = o.dataAtualizacao ? new Date(o.dataAtualizacao).toLocaleString('pt-BR') : '';
                const nomeFuncionario = funcionariosMap[o.funcionarioId] || '';
                const nomeSetor = setoresMap[o.setorId] || '';
                
                csv += [
                    o.id,
                    escapar(o.tipoOcorrencia),
                    dataOcorrencia,
                    escapar(o.horaOcorrencia),
                    escapar(nomeFuncionario),
                    escapar(nomeSetor),
                    escapar(o.localOcorrencia),
                    escapar(o.descricaoOcorrencia),
                    escapar(o.parteCorpoAtingida),
                    escapar(o.agenteCausador),
                    escapar(o.tipoLesao),
                    o.houveAfastamento ? 'Sim' : 'Não',
                    o.diasAfastamento || '',
                    o.catEmitida ? 'Sim' : 'Não',
                    escapar(o.numeroCat),
                    escapar(o.testemunhas),
                    escapar(o.analiseCausa),
                    escapar(o.acoesCorretivas),
                    dataRegistro,
                    dataAtualizacao
                ].join(',') + '\n';
            });
            
            const blob = new Blob(["\uFEFF" + csv], { type: 'text/csv;charset=utf-8;' }); // Adiciona BOM para Excel
            const link = document.createElement('a');
            const url = URL.createObjectURL(blob);
            link.setAttribute('href', url);
            link.setAttribute('download', 'ocorrencias_sst.csv');
            link.style.visibility = 'hidden';
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            
            this.exibirNotificacao('Dados exportados com sucesso!', 'success');
        }).catch(error => {
            console.error('Erro ao exportar dados:', error);
            this.exibirNotificacao('Erro ao exportar dados.', 'error');
        });
    },
    
    /**
     * Formata data (YYYY-MM-DD) para input (DD/MM/AAAA)
     */
    formatarDataInput: function(dataISO) {
        if (!dataISO) return '';
        const partes = dataISO.split('-');
        return `${partes[2]}/${partes[1]}/${partes[0]}`;
    },
    
    /**
     * Formata data (DD/MM/AAAA) para ISO (YYYY-MM-DD)
     */
    formatarDataISO: function(dataInput) {
        if (!dataInput) return null;
        const partes = dataInput.split('/');
        if (partes.length !== 3) return null;
        return `${partes[2]}-${partes[1]}-${partes[0]}`;
    },

    /**
     * Exibe uma notificação para o usuário
     */
    exibirNotificacao: function(mensagem, tipo) {
        if (typeof DASHBOARD !== 'undefined' && DASHBOARD.exibirNotificacao) {
            DASHBOARD.exibirNotificacao(mensagem, tipo);
        } else {
            alert(`[${tipo.toUpperCase()}] ${mensagem}`);
        }
    }
};

// Inicializar módulo
document.addEventListener('DOMContentLoaded', function() {
    if (document.querySelector('.acidentes-container')) {
        ACIDENTE.init();
    }
});
