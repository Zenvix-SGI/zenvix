/**
 * ZENVIX SGI - Módulo de Dashboard e Funcionalidades Pós-Login
 * 
 * Este arquivo contém funções para gerenciar as funcionalidades pós-login,
 * incluindo saudação personalizada, exibição de data/hora, histórico de ações e notificações.
 */

// Namespace para evitar conflitos
const DASHBOARD = {
    // Configurações
    config: {
        refreshInterval: 60000, // Intervalo de atualização de data/hora (60 segundos)
        maxHistoryItems: 10,    // Número máximo de itens no histórico
        maxNotifications: 5     // Número máximo de notificações exibidas
    },
    
    // Dados
    data: {
        history: [],
        notifications: [],
        alerts: []
    },
    
    /**
     * Inicializa o módulo de dashboard
     */
    init: function() {
        console.log('Inicializando módulo de dashboard...');
        
        // Verificar se usuário está autenticado
        if (!STORAGE.isAuthenticated()) {
            console.warn('Usuário não autenticado. Redirecionando para login...');
            window.location.href = 'login.html';
            return;
        }
        
        // Carregar dados
        this.carregarDados();
        
        // Inicializar componentes
        this.initComponents();
        
        // Configurar eventos
        this.setupEvents();
        
        console.log('Módulo de dashboard inicializado.');
    },
    
    /**
     * Carrega dados do armazenamento
     */
    carregarDados: function() {
        // Carregar histórico
        const history = STORAGE.getLocalItem('dashboard_history', []);
        this.data.history = history;
        
        // Carregar notificações
        const notifications = STORAGE.getLocalItem('dashboard_notifications', []);
        this.data.notifications = notifications;
        
        // Carregar alertas
        this.carregarAlertas();
    },
    
    /**
     * Carrega alertas de vencimentos próximos
     */
    carregarAlertas: function() {
        const alertas = [];
        const hoje = new Date();
        const limiteDias = 30; // Alertas para os próximos 30 dias
        
        // Função para calcular dias até vencimento
        const calcularDiasAteVencimento = (dataVencimento) => {
            const vencimento = new Date(dataVencimento);
            const diffTime = vencimento - hoje;
            return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
        };
        
        // Verificar exames próximos do vencimento
        STORAGE.getAll('exames').then(exames => {
            const examesVencendo = exames.filter(exame => {
                if (!exame.dataValidade) return false;
                const diasAteVencimento = calcularDiasAteVencimento(exame.dataValidade);
                return diasAteVencimento >= 0 && diasAteVencimento <= limiteDias;
            });
            
            if (examesVencendo.length > 0) {
                alertas.push({
                    tipo: 'exames',
                    quantidade: examesVencendo.length,
                    mensagem: `${examesVencendo.length} exame(s) vencendo nos próximos ${limiteDias} dias`
                });
            }
            
            // Atualizar contador no dashboard
            const alertasExames = document.getElementById('alertasExames');
            if (alertasExames) {
                const countSpan = alertasExames.querySelector('.count');
                if (countSpan) {
                    countSpan.textContent = examesVencendo.length;
                    countSpan.classList.toggle('zero', examesVencendo.length === 0);
                }
            }
            
            // Verificar treinamentos próximos do vencimento
            return STORAGE.getAll('treinamentos');
        }).then(treinamentos => {
            const treinamentosVencendo = treinamentos.filter(treinamento => {
                if (!treinamento.dataValidade) return false;
                const diasAteVencimento = calcularDiasAteVencimento(treinamento.dataValidade);
                return diasAteVencimento >= 0 && diasAteVencimento <= limiteDias;
            });
            
            if (treinamentosVencendo.length > 0) {
                alertas.push({
                    tipo: 'treinamentos',
                    quantidade: treinamentosVencendo.length,
                    mensagem: `${treinamentosVencendo.length} treinamento(s) vencendo nos próximos ${limiteDias} dias`
                });
            }
            
            // Atualizar contador no dashboard
            const alertasTreinamentos = document.getElementById('alertasTreinamentos');
            if (alertasTreinamentos) {
                const countSpan = alertasTreinamentos.querySelector('.count');
                if (countSpan) {
                    countSpan.textContent = treinamentosVencendo.length;
                    countSpan.classList.toggle('zero', treinamentosVencendo.length === 0);
                }
            }
            
            // Verificar EPIs próximos do vencimento
            return STORAGE.getAll('epis');
        }).then(epis => {
            const episVencendo = epis.filter(epi => {
                if (!epi.dataValidade) return false;
                const diasAteVencimento = calcularDiasAteVencimento(epi.dataValidade);
                return diasAteVencimento >= 0 && diasAteVencimento <= limiteDias;
            });
            
            if (episVencendo.length > 0) {
                alertas.push({
                    tipo: 'epis',
                    quantidade: episVencendo.length,
                    mensagem: `${episVencendo.length} EPI(s) com CA vencendo nos próximos ${limiteDias} dias`
                });
            }
            
            // Atualizar contador no dashboard
            const alertasEpis = document.getElementById('alertasEpis');
            if (alertasEpis) {
                const countSpan = alertasEpis.querySelector('.count');
                if (countSpan) {
                    countSpan.textContent = episVencendo.length;
                    countSpan.classList.toggle('zero', episVencendo.length === 0);
                }
            }
            
            // Verificar documentos próximos do vencimento
            return STORAGE.getAll('documentos');
        }).then(documentos => {
            const documentosVencendo = documentos.filter(documento => {
                if (!documento.dataValidade) return false;
                const diasAteVencimento = calcularDiasAteVencimento(documento.dataValidade);
                return diasAteVencimento >= 0 && diasAteVencimento <= limiteDias;
            });
            
            if (documentosVencendo.length > 0) {
                alertas.push({
                    tipo: 'documentos',
                    quantidade: documentosVencendo.length,
                    mensagem: `${documentosVencendo.length} documento(s) vencendo nos próximos ${limiteDias} dias`
                });
            }
            
            // Atualizar contador no dashboard
            const alertasDocumentos = document.getElementById('alertasDocumentos');
            if (alertasDocumentos) {
                const countSpan = alertasDocumentos.querySelector('.count');
                if (countSpan) {
                    countSpan.textContent = documentosVencendo.length;
                    countSpan.classList.toggle('zero', documentosVencendo.length === 0);
                }
            }
            
            // Atualizar mensagem de "nenhum alerta"
            const noAlertsMessage = document.getElementById('noAlertsMessage');
            if (noAlertsMessage) {
                const totalAlertas = alertas.reduce((total, alerta) => total + alerta.quantidade, 0);
                noAlertsMessage.style.display = totalAlertas === 0 ? 'block' : 'none';
            }
            
            // Salvar alertas
            this.data.alerts = alertas;
            
            // Atualizar contadores gerais
            this.atualizarContadoresGerais();
        }).catch(error => {
            console.error('Erro ao carregar alertas:', error);
        });
    },
    
    /**
     * Atualiza contadores gerais do dashboard
     */
    atualizarContadoresGerais: function() {
        // Funcionários ativos
        STORAGE.getAll('funcionarios').then(funcionarios => {
            const ativos = funcionarios.filter(f => f.ativo).length;
            const funcionariosAtivos = document.getElementById('funcionariosAtivos');
            if (funcionariosAtivos) {
                funcionariosAtivos.textContent = ativos;
            }
        });
        
        // Empresas cadastradas
        STORAGE.getAll('empresas').then(empresas => {
            const empresasCadastradas = document.getElementById('empresasCadastradas');
            if (empresasCadastradas) {
                empresasCadastradas.textContent = empresas.length;
            }
        });
        
        // Tipos de EPIs
        STORAGE.getAll('epis').then(epis => {
            // Contar tipos únicos
            const tipos = new Set(epis.map(e => e.tipo));
            const tiposEPI = document.getElementById('tiposEPI');
            if (tiposEPI) {
                tiposEPI.textContent = tipos.size;
            }
        });
        
        // Tipos de Documentos
        STORAGE.getAll('documentos').then(documentos => {
            // Contar tipos únicos
            const tipos = new Set(documentos.map(d => d.tipo));
            const tiposDocumento = document.getElementById('tiposDocumento');
            if (tiposDocumento) {
                tiposDocumento.textContent = tipos.size;
            }
        });
    },
    
    /**
     * Inicializa componentes da interface
     */
    initComponents: function() {
        // Exibir nome do usuário
        this.exibirNomeUsuario();
        
        // Inicializar data e hora
        this.inicializarDataHora();
        
        // Exibir histórico de atividades
        this.exibirHistoricoAtividades();
        
        // Exibir notificações
        this.exibirNotificacoes();
    },
    
    /**
     * Configura eventos da interface
     */
    setupEvents: function() {
        // Evento de logout
        const logoutButton = document.getElementById('logoutButton');
        if (logoutButton) {
            logoutButton.addEventListener('click', (e) => {
                e.preventDefault();
                this.logout();
            });
        }
        
        const logoutButtonHeader = document.getElementById('logoutButtonHeader');
        if (logoutButtonHeader) {
            logoutButtonHeader.addEventListener('click', (e) => {
                e.preventDefault();
                this.logout();
            });
        }
        
        // Dropdown do usuário
        const userButton = document.querySelector('.user-button');
        if (userButton) {
            userButton.addEventListener('click', () => {
                const dropdown = userButton.nextElementSibling;
                if (dropdown) {
                    dropdown.classList.toggle('show');
                }
            });
            
            // Fechar dropdown ao clicar fora
            document.addEventListener('click', (e) => {
                if (!userButton.contains(e.target)) {
                    const dropdown = userButton.nextElementSibling;
                    if (dropdown && dropdown.classList.contains('show')) {
                        dropdown.classList.remove('show');
                    }
                }
            });
        }
    },
    
    /**
     * Exibe o nome do usuário na interface
     */
    exibirNomeUsuario: function() {
        const user = STORAGE.getCurrentUser();
        if (!user) return;
        
        // Exibir nome no header
        const usernameDisplay = document.getElementById('usernameDisplay');
        if (usernameDisplay) {
            usernameDisplay.textContent = user.nome || user.username;
        }
        
        // Exibir cargo/função
        const userRoleDisplay = document.getElementById('userRoleDisplay');
        if (userRoleDisplay) {
            let roleText = '';
            switch (user.role) {
                case 'admin':
                    roleText = 'Administrador';
                    break;
                case 'tecnico':
                    roleText = 'Técnico SST';
                    break;
                case 'usuario':
                    roleText = 'Usuário';
                    break;
                default:
                    roleText = user.role;
            }
            userRoleDisplay.textContent = roleText;
        }
    },
    
    /**
     * Inicializa e atualiza a exibição de data e hora
     */
    inicializarDataHora: function() {
        const updateDateTime = () => {
            const now = new Date();
            const options = { 
                weekday: 'long', 
                year: 'numeric', 
                month: 'long', 
                day: 'numeric',
                hour: '2-digit',
                minute: '2-digit'
            };
            
            const currentDateTime = document.getElementById('currentDateTime');
            if (currentDateTime) {
                currentDateTime.textContent = now.toLocaleDateString('pt-BR', options);
            }
        };
        
        // Atualizar imediatamente
        updateDateTime();
        
        // Configurar atualização periódica
        setInterval(updateDateTime, this.config.refreshInterval);
    },
    
    /**
     * Exibe o histórico de atividades recentes
     */
    exibirHistoricoAtividades: function() {
        const timeline = document.getElementById('activitiesTimeline');
        if (!timeline) return;
        
        // Limpar timeline
        timeline.innerHTML = '';
        
        // Se não houver histórico, exibir mensagem
        if (this.data.history.length === 0) {
            timeline.innerHTML = '<p class="empty-message">Nenhuma atividade recente.</p>';
            return;
        }
        
        // Adicionar itens do histórico
        this.data.history.forEach(item => {
            const timelineItem = document.createElement('div');
            timelineItem.className = 'timeline-item';
            
            // Determinar ícone com base no tipo de atividade
            let icon = 'fa-history';
            switch (item.tipo) {
                case 'login':
                    icon = 'fa-sign-in-alt';
                    break;
                case 'cadastro':
                    icon = 'fa-user-plus';
                    break;
                case 'edicao':
                    icon = 'fa-edit';
                    break;
                case 'exclusao':
                    icon = 'fa-trash';
                    break;
                case 'exame':
                    icon = 'fa-file-medical';
                    break;
                case 'treinamento':
                    icon = 'fa-chalkboard-teacher';
                    break;
                case 'epi':
                    icon = 'fa-hard-hat';
                    break;
                case 'documento':
                    icon = 'fa-file-alt';
                    break;
                case 'esocial':
                    icon = 'fa-file-invoice';
                    break;
            }
            
            // Formatar data
            const data = new Date(item.data);
            const hoje = new Date();
            let dataFormatada = '';
            
            if (data.toDateString() === hoje.toDateString()) {
                dataFormatada = `Hoje, ${data.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}`;
            } else {
                const ontem = new Date(hoje);
                ontem.setDate(hoje.getDate() - 1);
                
                if (data.toDateString() === ontem.toDateString()) {
                    dataFormatada = `Ontem, ${data.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}`;
                } else {
                    dataFormatada = data.toLocaleDateString('pt-BR') + ', ' + 
                                   data.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
                }
            }
            
            timelineItem.innerHTML = `
                <div class="timeline-icon"><i class="fas ${icon}"></i></div>
                <div class="timeline-content">
                    <h4>${item.titulo}</h4>
                    <p>${item.descricao}</p>
                    <span class="timeline-date">${dataFormatada}</span>
                </div>
            `;
            
            timeline.appendChild(timelineItem);
        });
    },
    
    /**
     * Exibe notificações do sistema
     */
    exibirNotificacoes: function() {
        // Implementação futura para exibir notificações
        // Esta função será expandida quando o sistema de notificações for implementado
    },
    
    /**
     * Adiciona um item ao histórico de atividades
     * @param {Object} item - Item a ser adicionado
     * @param {string} item.tipo - Tipo de atividade
     * @param {string} item.titulo - Título da atividade
     * @param {string} item.descricao - Descrição da atividade
     */
    adicionarHistorico: function(item) {
        // Adicionar data atual
        item.data = new Date().toISOString();
        
        // Adicionar ao início do array
        this.data.history.unshift(item);
        
        // Limitar tamanho do histórico
        if (this.data.history.length > this.config.maxHistoryItems) {
            this.data.history = this.data.history.slice(0, this.config.maxHistoryItems);
        }
        
        // Salvar no localStorage
        STORAGE.setLocalItem('dashboard_history', this.data.history);
        
        // Atualizar exibição
        this.exibirHistoricoAtividades();
    },
    
    /**
     * Adiciona uma notificação ao sistema
     * @param {Object} notificacao - Notificação a ser adicionada
     * @param {string} notificacao.tipo - Tipo de notificação (info, success, warning, error)
     * @param {string} notificacao.titulo - Título da notificação
     * @param {string} notificacao.mensagem - Mensagem da notificação
     * @param {boolean} notificacao.lida - Se a notificação foi lida
     */
    adicionarNotificacao: function(notificacao) {
        // Adicionar data atual
        notificacao.data = new Date().toISOString();
        
        // Definir como não lida por padrão
        if (notificacao.lida === undefined) {
            notificacao.lida = false;
        }
        
        // Adicionar ao início do array
        this.data.notifications.unshift(notificacao);
        
        // Limitar tamanho das notificações
        if (this.data.notifications.length > this.config.maxNotifications) {
            this.data.notifications = this.data.notifications.slice(0, this.config.maxNotifications);
        }
        
        // Salvar no localStorage
        STORAGE.setLocalItem('dashboard_notifications', this.data.notifications);
        
        // Atualizar exibição
        this.exibirNotificacoes();
    },
    
    /**
     * Realiza logout do usuário
     */
    logout: function() {
        // Adicionar ao histórico
        this.adicionarHistorico({
            tipo: 'logout',
            titulo: 'Logout realizado',
            descricao: 'Sessão encerrada com sucesso'
        });
        
        // Realizar logout no storage
        STORAGE.logout();
        
        // Redirecionar para login
        window.location.href = 'login.html';
    }
};

// Inicializar módulo quando o DOM estiver carregado
document.addEventListener('DOMContentLoaded', function() {
    // Verificar se estamos em uma página de dashboard
    if (document.querySelector('.main-content')) {
        DASHBOARD.init();
    }
});
