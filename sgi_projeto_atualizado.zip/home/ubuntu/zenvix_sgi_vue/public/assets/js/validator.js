/**
 * ZENVIX SGI - Módulo de Validação e Segurança
 * 
 * Este módulo implementa validações de formulários e reforço de segurança
 * para o sistema ZENVIX SGI.
 */

const VALIDATOR = {
    // Configurações
    config: {
        passwordMinLength: 8,
        passwordRequireSpecial: true,
        passwordRequireNumber: true,
        passwordRequireUppercase: true,
        csrfEnabled: true,
        inputSanitizationEnabled: true
    },
    
    /**
     * Inicializa o módulo de validação
     */
    init: function() {
        console.log("Inicializando módulo de validação e segurança...");
        
        // Gerar token CSRF para formulários
        if (this.config.csrfEnabled) {
            this.generateCSRFToken();
        }
        
        // Adicionar validadores aos formulários
        this.setupFormValidators();
        
        // Configurar sanitização de inputs
        if (this.config.inputSanitizationEnabled) {
            this.setupInputSanitization();
        }
        
        console.log("Módulo de validação e segurança inicializado.");
    },
    
    /**
     * Gera token CSRF para proteção de formulários
     */
    generateCSRFToken: function() {
        const token = this.generateRandomToken(32);
        localStorage.setItem('csrf_token', token);
        
        // Adicionar token a todos os formulários
        document.querySelectorAll('form').forEach(form => {
            let tokenInput = form.querySelector('input[name="csrf_token"]');
            if (!tokenInput) {
                tokenInput = document.createElement('input');
                tokenInput.type = 'hidden';
                tokenInput.name = 'csrf_token';
                form.appendChild(tokenInput);
            }
            tokenInput.value = token;
        });
    },
    
    /**
     * Configura validadores para formulários
     */
    setupFormValidators: function() {
        // Formulário de login
        const loginForm = document.getElementById('loginForm');
        if (loginForm) {
            loginForm.addEventListener('submit', (e) => {
                if (!this.validateLoginForm(loginForm)) {
                    e.preventDefault();
                }
            });
        }
        
        // Formulários com campos de senha
        document.querySelectorAll('form:has(input[type="password"])').forEach(form => {
            form.addEventListener('submit', (e) => {
                if (!this.validatePasswordStrength(form)) {
                    e.preventDefault();
                }
            });
        });
        
        // Formulários com campos de e-mail
        document.querySelectorAll('form:has(input[type="email"])').forEach(form => {
            const emailInputs = form.querySelectorAll('input[type="email"]');
            emailInputs.forEach(input => {
                input.addEventListener('blur', () => {
                    this.validateEmail(input);
                });
            });
        });
        
        // Formulários com campos numéricos
        document.querySelectorAll('input[type="number"]').forEach(input => {
            input.addEventListener('blur', () => {
                this.validateNumber(input);
            });
        });
        
        // Formulários com campos de data
        document.querySelectorAll('input[type="date"]').forEach(input => {
            input.addEventListener('blur', () => {
                this.validateDate(input);
            });
        });
    },
    
    /**
     * Configura sanitização de inputs para prevenir XSS
     */
    setupInputSanitization: function() {
        document.querySelectorAll('input[type="text"], textarea').forEach(input => {
            input.addEventListener('blur', () => {
                input.value = this.sanitizeInput(input.value);
            });
        });
    },
    
    /**
     * Valida formulário de login
     * @param {HTMLFormElement} form - Formulário de login
     * @returns {boolean} - Resultado da validação
     */
    validateLoginForm: function(form) {
        const username = form.querySelector('input[name="username"]');
        const password = form.querySelector('input[name="password"]');
        let isValid = true;
        
        if (!username.value.trim()) {
            this.showError(username, 'Nome de usuário é obrigatório');
            isValid = false;
        } else {
            this.clearError(username);
        }
        
        if (!password.value) {
            this.showError(password, 'Senha é obrigatória');
            isValid = false;
        } else {
            this.clearError(password);
        }
        
        return isValid;
    },
    
    /**
     * Valida força da senha
     * @param {HTMLFormElement} form - Formulário com campo de senha
     * @returns {boolean} - Resultado da validação
     */
    validatePasswordStrength: function(form) {
        const passwordInput = form.querySelector('input[type="password"]');
        if (!passwordInput || passwordInput.hasAttribute('data-skip-validation')) {
            return true;
        }
        
        const password = passwordInput.value;
        let isValid = true;
        let errorMessage = '';
        
        // Verificar comprimento mínimo
        if (password.length < this.config.passwordMinLength) {
            errorMessage = `A senha deve ter pelo menos ${this.config.passwordMinLength} caracteres`;
            isValid = false;
        }
        
        // Verificar caractere especial
        if (isValid && this.config.passwordRequireSpecial && !/[!@#$%^&*(),.?":{}|<>]/.test(password)) {
            errorMessage = 'A senha deve conter pelo menos um caractere especial';
            isValid = false;
        }
        
        // Verificar número
        if (isValid && this.config.passwordRequireNumber && !/\d/.test(password)) {
            errorMessage = 'A senha deve conter pelo menos um número';
            isValid = false;
        }
        
        // Verificar letra maiúscula
        if (isValid && this.config.passwordRequireUppercase && !/[A-Z]/.test(password)) {
            errorMessage = 'A senha deve conter pelo menos uma letra maiúscula';
            isValid = false;
        }
        
        if (!isValid) {
            this.showError(passwordInput, errorMessage);
        } else {
            this.clearError(passwordInput);
        }
        
        return isValid;
    },
    
    /**
     * Valida campo de e-mail
     * @param {HTMLInputElement} input - Campo de e-mail
     * @returns {boolean} - Resultado da validação
     */
    validateEmail: function(input) {
        const email = input.value.trim();
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        
        if (email && !emailRegex.test(email)) {
            this.showError(input, 'E-mail inválido');
            return false;
        } else {
            this.clearError(input);
            return true;
        }
    },
    
    /**
     * Valida campo numérico
     * @param {HTMLInputElement} input - Campo numérico
     * @returns {boolean} - Resultado da validação
     */
    validateNumber: function(input) {
        const value = input.value.trim();
        const min = parseFloat(input.getAttribute('min'));
        const max = parseFloat(input.getAttribute('max'));
        
        if (value === '') {
            if (input.hasAttribute('required')) {
                this.showError(input, 'Este campo é obrigatório');
                return false;
            }
            return true;
        }
        
        const num = parseFloat(value);
        
        if (isNaN(num)) {
            this.showError(input, 'Valor não é um número válido');
            return false;
        }
        
        if (!isNaN(min) && num < min) {
            this.showError(input, `Valor mínimo é ${min}`);
            return false;
        }
        
        if (!isNaN(max) && num > max) {
            this.showError(input, `Valor máximo é ${max}`);
            return false;
        }
        
        this.clearError(input);
        return true;
    },
    
    /**
     * Valida campo de data
     * @param {HTMLInputElement} input - Campo de data
     * @returns {boolean} - Resultado da validação
     */
    validateDate: function(input) {
        const value = input.value.trim();
        const min = input.getAttribute('min');
        const max = input.getAttribute('max');
        
        if (value === '') {
            if (input.hasAttribute('required')) {
                this.showError(input, 'Este campo é obrigatório');
                return false;
            }
            return true;
        }
        
        const date = new Date(value);
        
        if (isNaN(date.getTime())) {
            this.showError(input, 'Data inválida');
            return false;
        }
        
        if (min && new Date(min) > date) {
            this.showError(input, `Data mínima é ${new Date(min).toLocaleDateString()}`);
            return false;
        }
        
        if (max && new Date(max) < date) {
            this.showError(input, `Data máxima é ${new Date(max).toLocaleDateString()}`);
            return false;
        }
        
        this.clearError(input);
        return true;
    },
    
    /**
     * Sanitiza input para prevenir XSS
     * @param {string} input - Texto a ser sanitizado
     * @returns {string} - Texto sanitizado
     */
    sanitizeInput: function(input) {
        if (!input) return input;
        
        // Converter caracteres especiais para entidades HTML
        const map = {
            '&': '&amp;',
            '<': '&lt;',
            '>': '&gt;',
            '"': '&quot;',
            "'": '&#039;'
        };
        
        return input.replace(/[&<>"']/g, m => map[m]);
    },
    
    /**
     * Criptografa senha (simulação)
     * @param {string} password - Senha em texto plano
     * @returns {string} - Hash da senha
     */
    hashPassword: function(password) {
        // Em um sistema real, usaria bcrypt ou similar
        // Aqui apenas simulamos um hash simples
        let hash = 0;
        for (let i = 0; i < password.length; i++) {
            const char = password.charCodeAt(i);
            hash = ((hash << 5) - hash) + char;
            hash = hash & hash; // Converter para inteiro de 32 bits
        }
        return "hash_" + Math.abs(hash).toString(16);
    },
    
    /**
     * Gera token aleatório
     * @param {number} length - Comprimento do token
     * @returns {string} - Token gerado
     */
    generateRandomToken: function(length = 32) {
        const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
        let token = '';
        for (let i = 0; i < length; i++) {
            token += chars.charAt(Math.floor(Math.random() * chars.length));
        }
        return token;
    },
    
    /**
     * Exibe mensagem de erro para um campo
     * @param {HTMLElement} input - Campo com erro
     * @param {string} message - Mensagem de erro
     */
    showError: function(input, message) {
        input.classList.add('is-invalid');
        
        let errorElement = input.nextElementSibling;
        if (!errorElement || !errorElement.classList.contains('error-message')) {
            errorElement = document.createElement('div');
            errorElement.className = 'error-message invalid-feedback';
            input.parentNode.insertBefore(errorElement, input.nextSibling);
        }
        
        errorElement.textContent = message;
    },
    
    /**
     * Remove mensagem de erro de um campo
     * @param {HTMLElement} input - Campo a limpar erro
     */
    clearError: function(input) {
        input.classList.remove('is-invalid');
        
        const errorElement = input.nextElementSibling;
        if (errorElement && errorElement.classList.contains('error-message')) {
            errorElement.textContent = '';
        }
    },
    
    /**
     * Verifica permissão de usuário para acessar módulo
     * @param {string} moduloId - ID do módulo
     * @returns {boolean} - Se usuário tem permissão
     */
    verificarPermissao: function(moduloId) {
        const usuarioAtual = STORAGE.getUsuarioAtual();
        if (!usuarioAtual) return false;
        
        // Administradores têm acesso a tudo
        if (usuarioAtual.nivel >= 3) return true;
        
        // Verificar permissões específicas do módulo
        const modulos = {
            dashboard: 1, // Nível mínimo para acessar
            esocial: 2,
            cipa: 2,
            auditoria: 2,
            epis: 2,
            treinamentos: 2,
            exames: 2,
            riscos: 2,
            acidentes: 2,
            brigada: 2,
            admin: 3
        };
        
        const nivelNecessario = modulos[moduloId] || 1;
        return usuarioAtual.nivel >= nivelNecessario;
    }
};

// Inicializar quando o DOM estiver pronto
document.addEventListener('DOMContentLoaded', () => {
    VALIDATOR.init();
});
