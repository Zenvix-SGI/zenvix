/**
 * ZENVIX SGI - Módulo de Treinamentos
 * 
 * Este arquivo contém funções para gerenciar o cadastro, controle e vencimentos de treinamentos.
 */

// Namespace para evitar conflitos
const TREINAMENTO = {
    // Configurações
    config: {
        diasAlertaVencimento: 30, // Dias para alertar antes do vencimento
        limitePorPagina: 10       // Número de itens por página na listagem
    },
    
    // Dados
    data: {
        tipos: [
            'NR-01 - Disposições Gerais',
            'NR-05 - CIPA',
            'NR-06 - EPI',
            'NR-10 - Segurança em Instalações Elétricas',
            'NR-11 - Transporte e Movimentação de Materiais',
            'NR-12 - Segurança em Máquinas e Equipamentos',
            'NR-13 - Caldeiras e Vasos de Pressão',
            'NR-17 - Ergonomia',
            'NR-18 - Condições de Trabalho na Indústria da Construção',
            'NR-20 - Líquidos Combustíveis e Inflamáveis',
            'NR-23 - Proteção Contra Incêndios',
            'NR-33 - Espaço Confinado',
            'NR-35 - Trabalho em Altura',
            'Brigada de Incêndio',
            'Primeiros Socorros',
            'Direção Defensiva',
            'Outro'
        ],
        modalidades: [
            'Presencial',
            'EAD',
            'Híbrido'
        ]
    },
    
    /**
     * Inicializa o módulo de treinamentos
     */
    init: function() {
        console.log('Inicializando módulo de treinamentos...');
        
        // Verificar se usuário está autenticado
        if (!STORAGE.isAuthenticated()) {
            console.warn('Usuário não autenticado. Redirecionando para login...');
            window.location.href = 'login.html';
            return;
        }
        
        // Inicializar componentes
        this.initComponents();
        
        // Configurar eventos
        this.setupEvents();
        
        // Carregar dados iniciais
        this.carregarDados();
        
        console.log('Módulo de treinamentos inicializado.');
    },
    
    /**
     * Inicializa componentes da interface
     */
    initComponents: function() {
        // Preencher selects de tipos de treinamento
        const tipoSelect = document.getElementById('tipoTreinamento');
        if (tipoSelect) {
            tipoSelect.innerHTML = '<option value="">Selecione...</option>';
            this.data.tipos.forEach(tipo => {
                const option = document.createElement('option');
                option.value = tipo;
                option.textContent = tipo;
                tipoSelect.appendChild(option);
            });
        }
        
        // Preencher selects de modalidades
        const modalidadeSelect = document.getElementById('modalidadeTreinamento');
        if (modalidadeSelect) {
            modalidadeSelect.innerHTML = '<option value="">Selecione...</option>';
            this.data.modalidades.forEach(modalidade => {
                const option = document.createElement('option');
                option.value = modalidade;
                option.textContent = modalidade;
                modalidadeSelect.appendChild(option);
            });
        }
        
        // Inicializar datepickers
        const datepickers = document.querySelectorAll('.datepicker');
        if (datepickers.length > 0) {
            datepickers.forEach(datepicker => {
                // Aqui seria implementado o datepicker real
                // Como é uma simulação, apenas adicionamos o evento change
                datepicker.addEventListener('change', function() {
                    // Validar formato da data (DD/MM/AAAA)
                    const regex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
                    if (!regex.test(this.value)) {
                        this.value = '';
                        alert('Formato de data inválido. Use DD/MM/AAAA.');
                    }
                });
            });
        }
        
        // Carregar funcionários para o select
        STORAGE.getAll('funcionarios').then(funcionarios => {
            const funcionarioSelect = document.getElementById('funcionarioTreinamento');
            if (funcionarioSelect) {
                funcionarioSelect.innerHTML = '<option value="">Selecione...</option>';
                
                // Ordenar funcionários por nome
                funcionarios.sort((a, b) => a.nome.localeCompare(b.nome));
                
                funcionarios.forEach(funcionario => {
                    if (funcionario.ativo) {
                        const option = document.createElement('option');
                        option.value = funcionario.id;
                        option.textContent = funcionario.nome;
                        funcionarioSelect.appendChild(option);
                    }
                });
            }
        }).catch(error => {
            console.error('Erro ao carregar funcionários:', error);
        });
    },
    
    /**
     * Configura eventos da interface
     */
    setupEvents: function() {
        // Formulário de cadastro de treinamento
        const formTreinamento = document.getElementById('formTreinamento');
        if (formTreinamento) {
            formTreinamento.addEventListener('submit', (e) => {
                e.preventDefault();
                this.salvarTreinamento();
            });
        }
        
        // Botão de novo treinamento
        const btnNovoTreinamento = document.getElementById('btnNovoTreinamento');
        if (btnNovoTreinamento) {
            btnNovoTreinamento.addEventListener('click', () => {
                this.limparFormulario();
                
                // Mostrar formulário
                const formContainer = document.getElementById('formContainer');
                if (formContainer) {
                    formContainer.style.display = 'block';
                }
                
                // Esconder listagem
                const listContainer = document.getElementById('listContainer');
                if (listContainer) {
                    listContainer.style.display = 'none';
                }
            });
        }
        
        // Botão de cancelar
        const btnCancelar = document.getElementById('btnCancelar');
        if (btnCancelar) {
            btnCancelar.addEventListener('click', (e) => {
                e.preventDefault();
                this.cancelarEdicao();
            });
        }
        
        // Botão de filtrar
        const btnFiltrar = document.getElementById('btnFiltrar');
        if (btnFiltrar) {
            btnFiltrar.addEventListener('click', () => {
                this.filtrarTreinamentos();
            });
        }
        
        // Botão de limpar filtros
        const btnLimparFiltros = document.getElementById('btnLimparFiltros');
        if (btnLimparFiltros) {
            btnLimparFiltros.addEventListener('click', () => {
                this.limparFiltros();
            });
        }
        
        // Botão de exportar
        const btnExportar = document.getElementById('btnExportar');
        if (btnExportar) {
            btnExportar.addEventListener('click', () => {
                this.exportarDados();
            });
        }
        
        // Evento para calcular data de validade automaticamente
        const dataRealizacao = document.getElementById('dataRealizacaoTreinamento');
        const validadeMeses = document.getElementById('validadeMesesTreinamento');
        const dataValidade = document.getElementById('dataValidadeTreinamento');
        
        if (dataRealizacao && validadeMeses && dataValidade) {
            const calcularValidade = () => {
                const dataStr = dataRealizacao.value;
                const meses = parseInt(validadeMeses.value);
                
                if (dataStr && !isNaN(meses) && meses > 0) {
                    // Converter data DD/MM/AAAA para objeto Date
                    const partes = dataStr.split('/');
                    if (partes.length === 3) {
                        const data = new Date(partes[2], partes[1] - 1, partes[0]);
                        
                        // Adicionar meses
                        data.setMonth(data.getMonth() + meses);
                        
                        // Formatar data de volta para DD/MM/AAAA
                        const dia = String(data.getDate()).padStart(2, '0');
                        const mes = String(data.getMonth() + 1).padStart(2, '0');
                        const ano = data.getFullYear();
                        
                        dataValidade.value = `${dia}/${mes}/${ano}`;
                    }
                }
            };
            
            dataRealizacao.addEventListener('change', calcularValidade);
            validadeMeses.addEventListener('change', calcularValidade);
        }
    },
    
    /**
     * Carrega dados iniciais
     */
    carregarDados: function() {
        // Carregar treinamentos do banco de dados
        STORAGE.getAll('treinamentos').then(treinamentos => {
            // Exibir treinamentos na tabela
            this.exibirTreinamentos(treinamentos);
            
            // Verificar vencimentos
            this.verificarVencimentos(treinamentos);
        }).catch(error => {
            console.error('Erro ao carregar treinamentos:', error);
            this.exibirNotificacao('Erro ao carregar dados de treinamentos', 'error');
        });
    },
    
    /**
     * Exibe treinamentos na tabela
     * @param {Array} treinamentos - Lista de treinamentos
     */
    exibirTreinamentos: function(treinamentos) {
        const tabela = document.getElementById('tabelaTreinamentos');
        if (!tabela) return;
        
        const tbody = tabela.querySelector('tbody');
        if (!tbody) return;
        
        // Limpar tabela
        tbody.innerHTML = '';
        
        // Se não houver treinamentos, exibir mensagem
        if (treinamentos.length === 0) {
            const tr = document.createElement('tr');
            tr.innerHTML = '<td colspan="7" class="text-center">Nenhum treinamento cadastrado.</td>';
            tbody.appendChild(tr);
            return;
        }
        
        // Obter funcionários para exibir nomes
        STORAGE.getAll('funcionarios').then(funcionarios => {
            const funcionariosMap = {};
            funcionarios.forEach(f => {
                funcionariosMap[f.id] = f.nome;
            });
            
            // Adicionar treinamentos à tabela
            treinamentos.forEach(treinamento => {
                const tr = document.createElement('tr');
                
                // Formatar datas
                const dataRealizacao = treinamento.dataRealizacao ? new Date(treinamento.dataRealizacao).toLocaleDateString('pt-BR') : '-';
                const dataValidade = treinamento.dataValidade ? new Date(treinamento.dataValidade).toLocaleDateString('pt-BR') : '-';
                
                // Obter nome do funcionário
                const nomeFuncionario = funcionariosMap[treinamento.funcionarioId] || 'Não informado';
                
                // Verificar status de validade
                let statusClass = '';
                let statusText = '';
                
                if (treinamento.dataValidade) {
                    const hoje = new Date();
                    const validade = new Date(treinamento.dataValidade);
                    const diasRestantes = Math.ceil((validade - hoje) / (1000 * 60 * 60 * 24));
                    
                    if (validade < hoje) {
                        statusClass = 'status-expired';
                        statusText = 'Vencido';
                    } else if (diasRestantes <= this.config.diasAlertaVencimento) {
                        statusClass = 'status-warning';
                        statusText = `Vence em ${diasRestantes} dias`;
                    } else {
                        statusClass = 'status-valid';
                        statusText = 'Válido';
                    }
                } else {
                    statusClass = 'status-info';
                    statusText = 'Sem validade';
                }
                
                tr.innerHTML = `
                    <td>${treinamento.tipo}</td>
                    <td>${nomeFuncionario}</td>
                    <td>${dataRealizacao}</td>
                    <td>${dataValidade}</td>
                    <td>${treinamento.cargaHoraria || '-'} horas</td>
                    <td><span class="status-badge ${statusClass}">${statusText}</span></td>
                    <td>
                        <button class="btn-sm view-btn" data-id="${treinamento.id}"><i class="fas fa-eye"></i></button>
                        <button class="btn-sm edit-btn" data-id="${treinamento.id}"><i class="fas fa-edit"></i></button>
                        <button class="btn-sm delete-btn" data-id="${treinamento.id}"><i class="fas fa-trash"></i></button>
                    </td>
                `;
                
                tbody.appendChild(tr);
            });
            
            // Adicionar eventos aos botões
            tbody.querySelectorAll('.view-btn').forEach(btn => {
                btn.addEventListener('click', () => {
                    const id = parseInt(btn.getAttribute('data-id'));
                    this.visualizarTreinamento(id);
                });
            });
            
            tbody.querySelectorAll('.edit-btn').forEach(btn => {
                btn.addEventListener('click', () => {
                    const id = parseInt(btn.getAttribute('data-id'));
                    this.editarTreinamento(id);
                });
            });
            
            tbody.querySelectorAll('.delete-btn').forEach(btn => {
                btn.addEventListener('click', () => {
                    const id = parseInt(btn.getAttribute('data-id'));
                    this.excluirTreinamento(id);
                });
            });
        }).catch(error => {
            console.error('Erro ao carregar funcionários:', error);
            tbody.innerHTML = '<tr><td colspan="7" class="text-center">Erro ao carregar dados.</td></tr>';
        });
    },
    
    /**
     * Verifica vencimentos de treinamentos
     * @param {Array} treinamentos - Lista de treinamentos
     */
    verificarVencimentos: function(treinamentos) {
        const hoje = new Date();
        const vencidos = [];
        const aVencer = [];
        
        treinamentos.forEach(treinamento => {
            if (!treinamento.dataValidade) return;
            
            const validade = new Date(treinamento.dataValidade);
            const diasRestantes = Math.ceil((validade - hoje) / (1000 * 60 * 60 * 24));
            
            if (validade < hoje) {
                vencidos.push(treinamento);
            } else if (diasRestantes <= this.config.diasAlertaVencimento) {
                aVencer.push({
                    treinamento: treinamento,
                    diasRestantes: diasRestantes
                });
            }
        });
        
        // Atualizar contadores
        const contadorVencidos = document.getElementById('treinamentosVencidos');
        const contadorAVencer = document.getElementById('treinamentosAVencer');
        const contadorValidos = document.getElementById('treinamentosValidos');
        const contadorTotal = document.getElementById('totalTreinamentos');
        
        if (contadorVencidos) contadorVencidos.textContent = vencidos.length;
        if (contadorAVencer) contadorAVencer.textContent = aVencer.length;
        
        if (contadorValidos) {
            const validos = treinamentos.filter(t => {
                if (!t.dataValidade) return false;
                const validade = new Date(t.dataValidade);
                return validade > hoje && Math.ceil((validade - hoje) / (1000 * 60 * 60 * 24)) > this.config.diasAlertaVencimento;
            }).length;
            contadorValidos.textContent = validos;
        }
        
        if (contadorTotal) contadorTotal.textContent = treinamentos.length;
        
        // Exibir alertas
        if (vencidos.length > 0 || aVencer.length > 0) {
            // Obter funcionários para exibir nomes
            STORAGE.getAll('funcionarios').then(funcionarios => {
                const funcionariosMap = {};
                funcionarios.forEach(f => {
                    funcionariosMap[f.id] = f.nome;
                });
                
                let mensagem = '';
                
                if (vencidos.length > 0) {
                    mensagem += `<strong>${vencidos.length} treinamento(s) vencido(s):</strong><br>`;
                    vencidos.forEach(treinamento => {
                        const nomeFuncionario = funcionariosMap[treinamento.funcionarioId] || 'Não informado';
                        mensagem += `- ${treinamento.tipo} - ${nomeFuncionario}<br>`;
                    });
                }
                
                if (aVencer.length > 0) {
                    if (mensagem) mensagem += '<br>';
                    mensagem += `<strong>${aVencer.length} treinamento(s) próximo(s) do vencimento:</strong><br>`;
                    aVencer.forEach(item => {
                        const nomeFuncionario = funcionariosMap[item.treinamento.funcionarioId] || 'Não informado';
                        mensagem += `- ${item.treinamento.tipo} - ${nomeFuncionario} - Vence em ${item.diasRestantes} dias<br>`;
                    });
                }
                
                this.exibirNotificacao(mensagem, 'warning');
            }).catch(error => {
                console.error('Erro ao carregar funcionários:', error);
            });
        }
    },
    
    /**
     * Salva um treinamento (novo ou edição)
     */
    salvarTreinamento: function() {
        // Obter dados do formulário
        const formTreinamento = document.getElementById('formTreinamento');
        if (!formTreinamento) return;
        
        const id = formTreinamento.getAttribute('data-id');
        const tipo = document.getElementById('tipoTreinamento').value;
        const funcionarioId = parseInt(document.getElementById('funcionarioTreinamento').value);
        const dataRealizacao = document.getElementById('dataRealizacaoTreinamento').value;
        const dataValidade = document.getElementById('dataValidadeTreinamento').value;
        const cargaHoraria = document.getElementById('cargaHorariaTreinamento').value;
        const modalidade = document.getElementById('modalidadeTreinamento').value;
        const instrutor = document.getElementById('instrutorTreinamento').value.trim();
        const instituicao = document.getElementById('instituicaoTreinamento').value.trim();
        const certificado = document.getElementById('certificadoTreinamento').value.trim();
        const observacoes = document.getElementById('observacoesTreinamento').value.trim();
        
        // Validar campos obrigatórios
        if (!tipo || isNaN(funcionarioId) || !dataRealizacao) {
            this.exibirNotificacao('Preencha os campos obrigatórios', 'error');
            return;
        }
        
        // Converter datas
        let dataRealizacaoISO = null;
        let dataValidadeISO = null;
        
        if (dataRealizacao) {
            const partes = dataRealizacao.split('/');
            if (partes.length === 3) {
                dataRealizacaoISO = `${partes[2]}-${partes[1]}-${partes[0]}`;
            }
        }
        
        if (dataValidade) {
            const partes = dataValidade.split('/');
            if (partes.length === 3) {
                dataValidadeISO = `${partes[2]}-${partes[1]}-${partes[0]}`;
            }
        }
        
        // Criar objeto treinamento
        const treinamento = {
            tipo: tipo,
            funcionarioId: funcionarioId,
            dataRealizacao: dataRealizacaoISO,
            dataValidade: dataValidadeISO,
            cargaHoraria: cargaHoraria ? parseInt(cargaHoraria) : null,
            modalidade: modalidade,
            instrutor: instrutor,
            instituicao: instituicao,
            certificado: certificado,
            observacoes: observacoes
        };
        
        // Se for edição, incluir ID
        if (id) {
            treinamento.id = parseInt(id);
            
            // Atualizar treinamento
            STORAGE.update('treinamentos', treinamento).then(() => {
                this.exibirNotificacao('Treinamento atualizado com sucesso', 'success');
                
                // Registrar no histórico
                DASHBOARD.adicionarHistorico({
                    tipo: 'edicao',
                    titulo: 'Treinamento atualizado',
                    descricao: `Treinamento "${tipo}" foi atualizado`
                });
                
                // Voltar para listagem
                this.cancelarEdicao();
                
                // Recarregar dados
                this.carregarDados();
            }).catch(error => {
                console.error('Erro ao atualizar treinamento:', error);
                this.exibirNotificacao('Erro ao atualizar treinamento', 'error');
            });
        } else {
            // Adicionar novo treinamento
            STORAGE.add('treinamentos', treinamento).then(() => {
                this.exibirNotificacao('Treinamento cadastrado com sucesso', 'success');
                
                // Registrar no histórico
                DASHBOARD.adicionarHistorico({
                    tipo: 'treinamento',
                    titulo: 'Novo treinamento cadastrado',
                    descricao: `Treinamento "${tipo}" foi cadastrado`
                });
                
                // Voltar para listagem
                this.cancelarEdicao();
                
                // Recarregar dados
                this.carregarDados();
            }).catch(error => {
                console.error('Erro ao cadastrar treinamento:', error);
                this.exibirNotificacao('Erro ao cadastrar treinamento', 'error');
            });
        }
    },
    
    /**
     * Visualiza detalhes de um treinamento
     * @param {number} id - ID do treinamento
     */
    visualizarTreinamento: function(id) {
        STORAGE.get('treinamentos', id).then(treinamento => {
            if (!treinamento) {
                this.exibirNotificacao('Treinamento não encontrado', 'error');
                return;
            }
            
            // Obter nome do funcionário
            STORAGE.get('funcionarios', treinamento.funcionarioId).then(funcionario => {
                const nomeFuncionario = funcionario ? funcionario.nome : 'Não informado';
                
                // Criar modal de visualização
                const modal = document.createElement('div');
                modal.className = 'modal fade show';
                modal.style.display = 'block';
                
                // Formatar datas
                const dataRealizacao = treinamento.dataRealizacao ? new Date(treinamento.dataRealizacao).toLocaleDateString('pt-BR') : '-';
                const dataValidade = treinamento.dataValidade ? new Date(treinamento.dataValidade).toLocaleDateString('pt-BR') : '-';
                
                modal.innerHTML = `
                    <div class="modal-dialog modal-dialog-centered">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title">Detalhes do Treinamento</h5>
                                <button type="button" class="close" data-dismiss="modal">&times;</button>
                            </div>
                            <div class="modal-body">
                                <div class="row">
                                    <div class="col-md-6">
                                        <p><strong>Tipo:</strong> ${treinamento.tipo}</p>
                                        <p><strong>Funcionário:</strong> ${nomeFuncionario}</p>
                                        <p><strong>Data de Realização:</strong> ${dataRealizacao}</p>
                                        <p><strong>Data de Validade:</strong> ${dataValidade}</p>
                                        <p><strong>Carga Horária:</strong> ${treinamento.cargaHoraria || '-'} horas</p>
                                    </div>
                                    <div class="col-md-6">
                                        <p><strong>Modalidade:</strong> ${treinamento.modalidade || '-'}</p>
                                        <p><strong>Instrutor:</strong> ${treinamento.instrutor || '-'}</p>
                                        <p><strong>Instituição:</strong> ${treinamento.instituicao || '-'}</p>
                                        <p><strong>Certificado:</strong> ${treinamento.certificado || '-'}</p>
                                        <p><strong>Observações:</strong> ${treinamento.observacoes || '-'}</p>
                                    </div>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Fechar</button>
                                <button type="button" class="btn btn-primary" id="btnEditarModal">Editar</button>
                            </div>
                        </div>
                    </div>
                `;
                
                // Adicionar modal ao body
                document.body.appendChild(modal);
                
                // Adicionar backdrop
                const backdrop = document.createElement('div');
                backdrop.className = 'modal-backdrop fade show';
                document.body.appendChild(backdrop);
                
                // Adicionar evento para fechar modal
                modal.querySelector('[data-dismiss="modal"]').addEventListener('click', () => {
                    document.body.removeChild(modal);
                    document.body.removeChild(backdrop);
                    document.body.classList.remove('modal-open');
                });
                
                // Adicionar evento para editar
                modal.querySelector('#btnEditarModal').addEventListener('click', () => {
                    document.body.removeChild(modal);
                    document.body.removeChild(backdrop);
                    document.body.classList.remove('modal-open');
                    
                    this.editarTreinamento(id);
                });
                
                // Adicionar classe ao body
                document.body.classList.add('modal-open');
            }).catch(error => {
                console.error('Erro ao carregar funcionário:', error);
                this.exibirNotificacao('Erro ao carregar dados do funcionário', 'error');
            });
        }).catch(error => {
            console.error('Erro ao visualizar treinamento:', error);
            this.exibirNotificacao('Erro ao visualizar treinamento', 'error');
        });
    },
    
    /**
     * Edita um treinamento
     * @param {number} id - ID do treinamento
     */
    editarTreinamento: function(id) {
        STORAGE.get('treinamentos', id).then(treinamento => {
            if (!treinamento) {
                this.exibirNotificacao('Treinamento não encontrado', 'error');
                return;
            }
            
            // Preencher formulário
            const formTreinamento = document.getElementById('formTreinamento');
            if (!formTreinamento) return;
            
            formTreinamento.setAttribute('data-id', treinamento.id);
            document.getElementById('tipoTreinamento').value = treinamento.tipo || '';
            document.getElementById('funcionarioTreinamento').value = treinamento.funcionarioId || '';
            document.getElementById('cargaHorariaTreinamento').value = treinamento.cargaHoraria || '';
            document.getElementById('modalidadeTreinamento').value = treinamento.modalidade || '';
            document.getElementById('instrutorTreinamento').value = treinamento.instrutor || '';
            document.getElementById('instituicaoTreinamento').value = treinamento.instituicao || '';
            document.getElementById('certificadoTreinamento').value = treinamento.certificado || '';
            document.getElementById('observacoesTreinamento').value = treinamento.observacoes || '';
            
            // Calcular validade em meses
            if (treinamento.dataRealizacao && treinamento.dataValidade) {
                const dataRealizacao = new Date(treinamento.dataRealizacao);
                const dataValidade = new Date(treinamento.dataValidade);
                const meses = (dataValidade.getFullYear() - dataRealizacao.getFullYear()) * 12 + 
                              (dataValidade.getMonth() - dataRealizacao.getMonth());
                document.getElementById('validadeMesesTreinamento').value = meses;
            } else {
                document.getElementById('validadeMesesTreinamento').value = '';
            }
            
            // Formatar datas
            if (treinamento.dataRealizacao) {
                const data = new Date(treinamento.dataRealizacao);
                const dia = String(data.getDate()).padStart(2, '0');
                const mes = String(data.getMonth() + 1).padStart(2, '0');
                const ano = data.getFullYear();
                document.getElementById('dataRealizacaoTreinamento').value = `${dia}/${mes}/${ano}`;
            } else {
                document.getElementById('dataRealizacaoTreinamento').value = '';
            }
            
            if (treinamento.dataValidade) {
                const data = new Date(treinamento.dataValidade);
                const dia = String(data.getDate()).padStart(2, '0');
                const mes = String(data.getMonth() + 1).padStart(2, '0');
                const ano = data.getFullYear();
                document.getElementById('dataValidadeTreinamento').value = `${dia}/${mes}/${ano}`;
            } else {
                document.getElementById('dataValidadeTreinamento').value = '';
            }
            
            // Mostrar formulário
            const formContainer = document.getElementById('formContainer');
            if (formContainer) {
                formContainer.style.display = 'block';
            }
            
            // Esconder listagem
            const listContainer = document.getElementById('listContainer');
            if (listContainer) {
                listContainer.style.display = 'none';
            }
            
            // Atualizar título do formulário
            const formTitle = document.getElementById('formTitle');
            if (formTitle) {
                formTitle.textContent = 'Editar Treinamento';
            }
            
            // Focar no primeiro campo
            document.getElementById('tipoTreinamento').focus();
        }).catch(error => {
            console.error('Erro ao editar treinamento:', error);
            this.exibirNotificacao('Erro ao editar treinamento', 'error');
        });
    },
    
    /**
     * Exclui um treinamento
     * @param {number} id - ID do treinamento
     */
    excluirTreinamento: function(id) {
        if (confirm('Tem certeza que deseja excluir este treinamento?')) {
            STORAGE.get('treinamentos', id).then(treinamento => {
                if (!treinamento) {
                    this.exibirNotificacao('Treinamento não encontrado', 'error');
                    return;
                }
                
                // Excluir treinamento
                STORAGE.remove('treinamentos', id).then(() => {
                    this.exibirNotificacao('Treinamento excluído com sucesso', 'success');
                    
                    // Registrar no histórico
                    DASHBOARD.adicionarHistorico({
                        tipo: 'exclusao',
                        titulo: 'Treinamento excluído',
                        descricao: `Treinamento "${treinamento.tipo}" foi excluído`
                    });
                    
                    // Recarregar dados
                    this.carregarDados();
                }).catch(error => {
                    console.error('Erro ao excluir treinamento:', error);
                    this.exibirNotificacao('Erro ao excluir treinamento', 'error');
                });
            }).catch(error => {
                console.error('Erro ao buscar treinamento:', error);
                this.exibirNotificacao('Erro ao buscar treinamento', 'error');
            });
        }
    },
    
    /**
     * Cancela edição/cadastro e volta para listagem
     */
    cancelarEdicao: function() {
        // Limpar formulário
        this.limparFormulario();
        
        // Esconder formulário
        const formContainer = document.getElementById('formContainer');
        if (formContainer) {
            formContainer.style.display = 'none';
        }
        
        // Mostrar listagem
        const listContainer = document.getElementById('listContainer');
        if (listContainer) {
            listContainer.style.display = 'block';
        }
    },
    
    /**
     * Limpa o formulário de treinamento
     */
    limparFormulario: function() {
        const formTreinamento = document.getElementById('formTreinamento');
        if (!formTreinamento) return;
        
        formTreinamento.removeAttribute('data-id');
        formTreinamento.reset();
        
        // Atualizar título do formulário
        const formTitle = document.getElementById('formTitle');
        if (formTitle) {
            formTitle.textContent = 'Novo Treinamento';
        }
    },
    
    /**
     * Filtra treinamentos com base nos critérios selecionados
     */
    filtrarTreinamentos: function() {
        const filtroTipo = document.getElementById('filtroTipo').value;
        const filtroFuncionario = document.getElementById('filtroFuncionario').value;
        const filtroStatus = document.getElementById('filtroStatus').value;
        const filtroPeriodo = document.getElementById('filtroPeriodo').value;
        
        STORAGE.getAll('treinamentos').then(treinamentos => {
            let treinamentosFiltrados = treinamentos;
            
            // Filtrar por tipo
            if (filtroTipo) {
                treinamentosFiltrados = treinamentosFiltrados.filter(t => t.tipo === filtroTipo);
            }
            
            // Filtrar por funcionário
            if (filtroFuncionario) {
                const funcionarioId = parseInt(filtroFuncionario);
                treinamentosFiltrados = treinamentosFiltrados.filter(t => t.funcionarioId === funcionarioId);
            }
            
            // Filtrar por status
            if (filtroStatus) {
                const hoje = new Date();
                
                switch (filtroStatus) {
                    case 'valido':
                        treinamentosFiltrados = treinamentosFiltrados.filter(t => {
                            if (!t.dataValidade) return false;
                            const validade = new Date(t.dataValidade);
                            return validade > hoje;
                        });
                        break;
                    case 'vencido':
                        treinamentosFiltrados = treinamentosFiltrados.filter(t => {
                            if (!t.dataValidade) return false;
                            const validade = new Date(t.dataValidade);
                            return validade <= hoje;
                        });
                        break;
                    case 'proximo':
                        treinamentosFiltrados = treinamentosFiltrados.filter(t => {
                            if (!t.dataValidade) return false;
                            const validade = new Date(t.dataValidade);
                            const diasRestantes = Math.ceil((validade - hoje) / (1000 * 60 * 60 * 24));
                            return validade > hoje && diasRestantes <= this.config.diasAlertaVencimento;
                        });
                        break;
                }
            }
            
            // Filtrar por período
            if (filtroPeriodo) {
                const diasAtras = parseInt(filtroPeriodo);
                const dataLimite = new Date();
                dataLimite.setDate(dataLimite.getDate() - diasAtras);
                
                treinamentosFiltrados = treinamentosFiltrados.filter(t => {
                    if (!t.dataRealizacao) return false;
                    const realizacao = new Date(t.dataRealizacao);
                    return realizacao >= dataLimite;
                });
            }
            
            // Exibir treinamentos filtrados
            this.exibirTreinamentos(treinamentosFiltrados);
        }).catch(error => {
            console.error('Erro ao filtrar treinamentos:', error);
            this.exibirNotificacao('Erro ao filtrar treinamentos', 'error');
        });
    },
    
    /**
     * Limpa filtros e exibe todos os treinamentos
     */
    limparFiltros: function() {
        document.getElementById('filtroTipo').value = '';
        document.getElementById('filtroFuncionario').value = '';
        document.getElementById('filtroStatus').value = '';
        document.getElementById('filtroPeriodo').value = '';
        
        this.carregarDados();
    },
    
    /**
     * Exporta dados de treinamentos para CSV
     */
    exportarDados: function() {
        Promise.all([
            STORAGE.getAll('treinamentos'),
            STORAGE.getAll('funcionarios')
        ]).then(([treinamentos, funcionarios]) => {
            // Criar mapa de funcionários
            const funcionariosMap = {};
            funcionarios.forEach(f => {
                funcionariosMap[f.id] = f.nome;
            });
            
            // Criar cabeçalho CSV
            let csv = 'Tipo,Funcionário,Data de Realização,Data de Validade,Carga Horária,Modalidade,Instrutor,Instituição,Certificado,Observações\n';
            
            // Adicionar linhas
            treinamentos.forEach(treinamento => {
                const dataRealizacao = treinamento.dataRealizacao ? new Date(treinamento.dataRealizacao).toLocaleDateString('pt-BR') : '';
                const dataValidade = treinamento.dataValidade ? new Date(treinamento.dataValidade).toLocaleDateString('pt-BR') : '';
                const nomeFuncionario = funcionariosMap[treinamento.funcionarioId] || 'Não informado';
                
                // Escapar campos com vírgula
                const escapar = (campo) => {
                    if (!campo) return '';
                    if (campo.includes(',') || campo.includes('"') || campo.includes('\n')) {
                        return `"${campo.replace(/"/g, '""')}"`;
                    }
                    return campo;
                };
                
                csv += `${escapar(treinamento.tipo)},${escapar(nomeFuncionario)},${dataRealizacao},${dataValidade},${treinamento.cargaHoraria || ''},${escapar(treinamento.modalidade)},${escapar(treinamento.instrutor)},${escapar(treinamento.instituicao)},${escapar(treinamento.certificado)},${escapar(treinamento.observacoes)}\n`;
            });
            
            // Criar blob e link para download
            const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
            const link = document.createElement('a');
            const url = URL.createObjectURL(blob);
            
            link.setAttribute('href', url);
            link.setAttribute('download', 'treinamentos.csv');
            link.style.visibility = 'hidden';
            
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            
            this.exibirNotificacao('Dados exportados com sucesso', 'success');
        }).catch(error => {
            console.error('Erro ao exportar dados:', error);
            this.exibirNotificacao('Erro ao exportar dados', 'error');
        });
    },
    
    /**
     * Exibe uma notificação para o usuário
     * @param {string} mensagem - Mensagem a ser exibida
     * @param {string} tipo - Tipo de notificação (success, error, warning, info)
     */
    exibirNotificacao: function(mensagem, tipo) {
        // Verificar se o container de notificações existe
        let container = document.getElementById('notification-container');
        if (!container) {
            container = document.createElement('div');
            container.id = 'notification-container';
            document.body.appendChild(container);
        }
        
        // Criar notificação
        const notification = document.createElement('div');
        notification.className = `alert-notification alert-${tipo} show`;
        notification.innerHTML = `<p>${mensagem}</p><button class="alert-close-btn">&times;</button>`;
        
        // Adicionar ao container
        container.appendChild(notification);
        
        // Adicionar evento para fechar notificação
        notification.querySelector('.alert-close-btn').addEventListener('click', () => {
            notification.classList.replace('show', 'hide');
            setTimeout(() => {
                if (notification.parentNode) {
                    notification.parentNode.removeChild(notification);
                }
            }, 500);
        });
        
        // Auto-fechar após 5 segundos
        setTimeout(() => {
            if (notification.classList.contains('show')) {
                notification.classList.replace('show', 'hide');
                setTimeout(() => {
                    if (notification.parentNode) {
                        notification.parentNode.removeChild(notification);
                    }
                }, 500);
            }
        }, 5000);
    }
};

// Inicializar módulo quando o DOM estiver carregado
document.addEventListener('DOMContentLoaded', function() {
    // Verificar se estamos na página de treinamentos
    if (document.querySelector('.treinamento-container')) {
        TREINAMENTO.init();
    }
});
