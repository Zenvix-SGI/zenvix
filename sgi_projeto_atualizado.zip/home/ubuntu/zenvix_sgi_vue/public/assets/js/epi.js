/**
 * ZENVIX SGI - Módulo de Gestão de EPIs
 * 
 * Este arquivo contém funções para gerenciar o cadastro, controle e vencimentos de EPIs.
 */

// Namespace para evitar conflitos
const EPI = {
    // Configurações
    config: {
        diasAlertaVencimento: 30, // Dias para alertar antes do vencimento do CA
        limitePorPagina: 10       // Número de itens por página na listagem
    },
    
    // Dados
    data: {
        tipos: [
            'Capacete de Segurança',
            'Óculos de Proteção',
            'Protetor Auricular',
            'Máscara Respiratória',
            'Luvas de Proteção',
            'Calçado de Segurança',
            'Cinto de Segurança',
            'Vestimenta de Proteção',
            'Protetor Facial',
            'Creme Protetor'
        ],
        riscos: [
            'Impactos de objetos',
            'Respingos químicos',
            'Ruído',
            'Poeira',
            'Gases e vapores',
            'Queda',
            'Corte e perfuração',
            'Choque elétrico',
            'Calor/fogo',
            'Radiação'
        ]
    },
    
    /**
     * Inicializa o módulo de gestão de EPIs
     */
    init: function() {
        console.log('Inicializando módulo de gestão de EPIs...');
        
        // Verificar se usuário está autenticado
        if (!STORAGE.isAuthenticated()) {
            console.warn('Usuário não autenticado. Redirecionando para login...');
            window.location.href = 'login.html';
            return;
        }
        
        // Inicializar componentes
        this.initComponents();
        
        // Configurar eventos
        this.setupEvents();
        
        // Carregar dados iniciais
        this.carregarDados();
        
        console.log('Módulo de gestão de EPIs inicializado.');
    },
    
    /**
     * Inicializa componentes da interface
     */
    initComponents: function() {
        // Preencher selects de tipos de EPI
        const tipoSelect = document.getElementById('tipoEPI');
        if (tipoSelect) {
            tipoSelect.innerHTML = '<option value="">Selecione...</option>';
            this.data.tipos.forEach(tipo => {
                const option = document.createElement('option');
                option.value = tipo;
                option.textContent = tipo;
                tipoSelect.appendChild(option);
            });
        }
        
        // Preencher selects de riscos
        const riscoSelect = document.getElementById('riscoEPI');
        if (riscoSelect) {
            riscoSelect.innerHTML = '<option value="">Selecione...</option>';
            this.data.riscos.forEach(risco => {
                const option = document.createElement('option');
                option.value = risco;
                option.textContent = risco;
                riscoSelect.appendChild(option);
            });
        }
        
        // Inicializar datepickers
        const datepickers = document.querySelectorAll('.datepicker');
        if (datepickers.length > 0) {
            datepickers.forEach(datepicker => {
                // Aqui seria implementado o datepicker real
                // Como é uma simulação, apenas adicionamos o evento change
                datepicker.addEventListener('change', function() {
                    // Validar formato da data (DD/MM/AAAA)
                    const regex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
                    if (!regex.test(this.value)) {
                        this.value = '';
                        alert('Formato de data inválido. Use DD/MM/AAAA.');
                    }
                });
            });
        }
    },
    
    /**
     * Configura eventos da interface
     */
    setupEvents: function() {
        // Formulário de cadastro de EPI
        const formEPI = document.getElementById('formEPI');
        if (formEPI) {
            formEPI.addEventListener('submit', (e) => {
                e.preventDefault();
                this.salvarEPI();
            });
        }
        
        // Botão de novo EPI
        const btnNovoEPI = document.getElementById('btnNovoEPI');
        if (btnNovoEPI) {
            btnNovoEPI.addEventListener('click', () => {
                this.limparFormulario();
                
                // Mostrar formulário
                const formContainer = document.getElementById('formContainer');
                if (formContainer) {
                    formContainer.style.display = 'block';
                }
                
                // Esconder listagem
                const listContainer = document.getElementById('listContainer');
                if (listContainer) {
                    listContainer.style.display = 'none';
                }
            });
        }
        
        // Botão de cancelar
        const btnCancelar = document.getElementById('btnCancelar');
        if (btnCancelar) {
            btnCancelar.addEventListener('click', (e) => {
                e.preventDefault();
                this.cancelarEdicao();
            });
        }
        
        // Botão de filtrar
        const btnFiltrar = document.getElementById('btnFiltrar');
        if (btnFiltrar) {
            btnFiltrar.addEventListener('click', () => {
                this.filtrarEPIs();
            });
        }
        
        // Botão de limpar filtros
        const btnLimparFiltros = document.getElementById('btnLimparFiltros');
        if (btnLimparFiltros) {
            btnLimparFiltros.addEventListener('click', () => {
                this.limparFiltros();
            });
        }
        
        // Botão de exportar
        const btnExportar = document.getElementById('btnExportar');
        if (btnExportar) {
            btnExportar.addEventListener('click', () => {
                this.exportarDados();
            });
        }
    },
    
    /**
     * Carrega dados iniciais
     */
    carregarDados: function() {
        // Carregar EPIs do banco de dados
        STORAGE.getAll('epis').then(epis => {
            // Exibir EPIs na tabela
            this.exibirEPIs(epis);
            
            // Verificar vencimentos
            this.verificarVencimentos(epis);
        }).catch(error => {
            console.error('Erro ao carregar EPIs:', error);
            this.exibirNotificacao('Erro ao carregar dados de EPIs', 'error');
        });
    },
    
    /**
     * Exibe EPIs na tabela
     * @param {Array} epis - Lista de EPIs
     */
    exibirEPIs: function(epis) {
        const tabela = document.getElementById('tabelaEPIs');
        if (!tabela) return;
        
        const tbody = tabela.querySelector('tbody');
        if (!tbody) return;
        
        // Limpar tabela
        tbody.innerHTML = '';
        
        // Se não houver EPIs, exibir mensagem
        if (epis.length === 0) {
            const tr = document.createElement('tr');
            tr.innerHTML = '<td colspan="7" class="text-center">Nenhum EPI cadastrado.</td>';
            tbody.appendChild(tr);
            return;
        }
        
        // Adicionar EPIs à tabela
        epis.forEach(epi => {
            const tr = document.createElement('tr');
            
            // Formatar datas
            const dataAquisicao = epi.dataAquisicao ? new Date(epi.dataAquisicao).toLocaleDateString('pt-BR') : '-';
            const dataValidade = epi.dataValidade ? new Date(epi.dataValidade).toLocaleDateString('pt-BR') : '-';
            
            // Verificar status de validade
            let statusClass = '';
            let statusText = '';
            
            if (epi.dataValidade) {
                const hoje = new Date();
                const validade = new Date(epi.dataValidade);
                const diasRestantes = Math.ceil((validade - hoje) / (1000 * 60 * 60 * 24));
                
                if (validade < hoje) {
                    statusClass = 'status-expired';
                    statusText = 'Vencido';
                } else if (diasRestantes <= this.config.diasAlertaVencimento) {
                    statusClass = 'status-warning';
                    statusText = `Vence em ${diasRestantes} dias`;
                } else {
                    statusClass = 'status-valid';
                    statusText = 'Válido';
                }
            } else {
                statusClass = 'status-info';
                statusText = 'Sem validade';
            }
            
            tr.innerHTML = `
                <td>${epi.descricao}</td>
                <td>${epi.tipo}</td>
                <td>${epi.ca || '-'}</td>
                <td>${dataAquisicao}</td>
                <td>${dataValidade}</td>
                <td><span class="status-badge ${statusClass}">${statusText}</span></td>
                <td>
                    <button class="btn-sm view-btn" data-id="${epi.id}"><i class="fas fa-eye"></i></button>
                    <button class="btn-sm edit-btn" data-id="${epi.id}"><i class="fas fa-edit"></i></button>
                    <button class="btn-sm delete-btn" data-id="${epi.id}"><i class="fas fa-trash"></i></button>
                </td>
            `;
            
            tbody.appendChild(tr);
        });
        
        // Adicionar eventos aos botões
        tbody.querySelectorAll('.view-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                const id = parseInt(btn.getAttribute('data-id'));
                this.visualizarEPI(id);
            });
        });
        
        tbody.querySelectorAll('.edit-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                const id = parseInt(btn.getAttribute('data-id'));
                this.editarEPI(id);
            });
        });
        
        tbody.querySelectorAll('.delete-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                const id = parseInt(btn.getAttribute('data-id'));
                this.excluirEPI(id);
            });
        });
    },
    
    /**
     * Verifica vencimentos de EPIs
     * @param {Array} epis - Lista de EPIs
     */
    verificarVencimentos: function(epis) {
        const hoje = new Date();
        const vencidos = [];
        const aVencer = [];
        
        epis.forEach(epi => {
            if (!epi.dataValidade) return;
            
            const validade = new Date(epi.dataValidade);
            const diasRestantes = Math.ceil((validade - hoje) / (1000 * 60 * 60 * 24));
            
            if (validade < hoje) {
                vencidos.push(epi);
            } else if (diasRestantes <= this.config.diasAlertaVencimento) {
                aVencer.push({
                    epi: epi,
                    diasRestantes: diasRestantes
                });
            }
        });
        
        // Exibir alertas
        if (vencidos.length > 0 || aVencer.length > 0) {
            let mensagem = '';
            
            if (vencidos.length > 0) {
                mensagem += `<strong>${vencidos.length} EPI(s) com CA vencido:</strong><br>`;
                vencidos.forEach(epi => {
                    mensagem += `- ${epi.descricao} (CA: ${epi.ca || 'N/A'})<br>`;
                });
            }
            
            if (aVencer.length > 0) {
                if (mensagem) mensagem += '<br>';
                mensagem += `<strong>${aVencer.length} EPI(s) com CA próximo do vencimento:</strong><br>`;
                aVencer.forEach(item => {
                    mensagem += `- ${item.epi.descricao} (CA: ${item.epi.ca || 'N/A'}) - Vence em ${item.diasRestantes} dias<br>`;
                });
            }
            
            this.exibirNotificacao(mensagem, 'warning');
        }
    },
    
    /**
     * Salva um EPI (novo ou edição)
     */
    salvarEPI: function() {
        // Obter dados do formulário
        const formEPI = document.getElementById('formEPI');
        if (!formEPI) return;
        
        const id = formEPI.getAttribute('data-id');
        const descricao = document.getElementById('descricaoEPI').value.trim();
        const tipo = document.getElementById('tipoEPI').value;
        const ca = document.getElementById('caEPI').value.trim();
        const fabricante = document.getElementById('fabricanteEPI').value.trim();
        const fornecedor = document.getElementById('fornecedorEPI').value.trim();
        const dataAquisicao = document.getElementById('dataAquisicaoEPI').value;
        const dataValidade = document.getElementById('dataValidadeEPI').value;
        const risco = document.getElementById('riscoEPI').value;
        const observacoes = document.getElementById('observacoesEPI').value.trim();
        
        // Validar campos obrigatórios
        if (!descricao || !tipo) {
            this.exibirNotificacao('Preencha os campos obrigatórios', 'error');
            return;
        }
        
        // Converter datas
        let dataAquisicaoISO = null;
        let dataValidadeISO = null;
        
        if (dataAquisicao) {
            const partes = dataAquisicao.split('/');
            if (partes.length === 3) {
                dataAquisicaoISO = `${partes[2]}-${partes[1]}-${partes[0]}`;
            }
        }
        
        if (dataValidade) {
            const partes = dataValidade.split('/');
            if (partes.length === 3) {
                dataValidadeISO = `${partes[2]}-${partes[1]}-${partes[0]}`;
            }
        }
        
        // Criar objeto EPI
        const epi = {
            descricao: descricao,
            tipo: tipo,
            ca: ca,
            fabricante: fabricante,
            fornecedor: fornecedor,
            dataAquisicao: dataAquisicaoISO,
            dataValidade: dataValidadeISO,
            risco: risco,
            observacoes: observacoes
        };
        
        // Se for edição, incluir ID
        if (id) {
            epi.id = parseInt(id);
            
            // Atualizar EPI
            STORAGE.update('epis', epi).then(() => {
                this.exibirNotificacao('EPI atualizado com sucesso', 'success');
                
                // Registrar no histórico
                DASHBOARD.adicionarHistorico({
                    tipo: 'edicao',
                    titulo: 'EPI atualizado',
                    descricao: `EPI "${descricao}" foi atualizado`
                });
                
                // Voltar para listagem
                this.cancelarEdicao();
                
                // Recarregar dados
                this.carregarDados();
            }).catch(error => {
                console.error('Erro ao atualizar EPI:', error);
                this.exibirNotificacao('Erro ao atualizar EPI', 'error');
            });
        } else {
            // Adicionar novo EPI
            STORAGE.add('epis', epi).then(() => {
                this.exibirNotificacao('EPI cadastrado com sucesso', 'success');
                
                // Registrar no histórico
                DASHBOARD.adicionarHistorico({
                    tipo: 'cadastro',
                    titulo: 'Novo EPI cadastrado',
                    descricao: `EPI "${descricao}" foi cadastrado`
                });
                
                // Voltar para listagem
                this.cancelarEdicao();
                
                // Recarregar dados
                this.carregarDados();
            }).catch(error => {
                console.error('Erro ao cadastrar EPI:', error);
                this.exibirNotificacao('Erro ao cadastrar EPI', 'error');
            });
        }
    },
    
    /**
     * Visualiza detalhes de um EPI
     * @param {number} id - ID do EPI
     */
    visualizarEPI: function(id) {
        STORAGE.get('epis', id).then(epi => {
            if (!epi) {
                this.exibirNotificacao('EPI não encontrado', 'error');
                return;
            }
            
            // Criar modal de visualização
            const modal = document.createElement('div');
            modal.className = 'modal fade show';
            modal.style.display = 'block';
            
            // Formatar datas
            const dataAquisicao = epi.dataAquisicao ? new Date(epi.dataAquisicao).toLocaleDateString('pt-BR') : '-';
            const dataValidade = epi.dataValidade ? new Date(epi.dataValidade).toLocaleDateString('pt-BR') : '-';
            
            modal.innerHTML = `
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">Detalhes do EPI</h5>
                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                        </div>
                        <div class="modal-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <p><strong>Descrição:</strong> ${epi.descricao}</p>
                                    <p><strong>Tipo:</strong> ${epi.tipo}</p>
                                    <p><strong>CA:</strong> ${epi.ca || '-'}</p>
                                    <p><strong>Fabricante:</strong> ${epi.fabricante || '-'}</p>
                                    <p><strong>Fornecedor:</strong> ${epi.fornecedor || '-'}</p>
                                </div>
                                <div class="col-md-6">
                                    <p><strong>Data de Aquisição:</strong> ${dataAquisicao}</p>
                                    <p><strong>Data de Validade:</strong> ${dataValidade}</p>
                                    <p><strong>Risco:</strong> ${epi.risco || '-'}</p>
                                    <p><strong>Observações:</strong> ${epi.observacoes || '-'}</p>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Fechar</button>
                            <button type="button" class="btn btn-primary" id="btnEditarModal">Editar</button>
                        </div>
                    </div>
                </div>
            `;
            
            // Adicionar modal ao body
            document.body.appendChild(modal);
            
            // Adicionar backdrop
            const backdrop = document.createElement('div');
            backdrop.className = 'modal-backdrop fade show';
            document.body.appendChild(backdrop);
            
            // Adicionar evento para fechar modal
            modal.querySelector('[data-dismiss="modal"]').addEventListener('click', () => {
                document.body.removeChild(modal);
                document.body.removeChild(backdrop);
                document.body.classList.remove('modal-open');
            });
            
            // Adicionar evento para editar
            modal.querySelector('#btnEditarModal').addEventListener('click', () => {
                document.body.removeChild(modal);
                document.body.removeChild(backdrop);
                document.body.classList.remove('modal-open');
                
                this.editarEPI(id);
            });
            
            // Adicionar classe ao body
            document.body.classList.add('modal-open');
        }).catch(error => {
            console.error('Erro ao visualizar EPI:', error);
            this.exibirNotificacao('Erro ao visualizar EPI', 'error');
        });
    },
    
    /**
     * Edita um EPI
     * @param {number} id - ID do EPI
     */
    editarEPI: function(id) {
        STORAGE.get('epis', id).then(epi => {
            if (!epi) {
                this.exibirNotificacao('EPI não encontrado', 'error');
                return;
            }
            
            // Preencher formulário
            const formEPI = document.getElementById('formEPI');
            if (!formEPI) return;
            
            formEPI.setAttribute('data-id', epi.id);
            document.getElementById('descricaoEPI').value = epi.descricao || '';
            document.getElementById('tipoEPI').value = epi.tipo || '';
            document.getElementById('caEPI').value = epi.ca || '';
            document.getElementById('fabricanteEPI').value = epi.fabricante || '';
            document.getElementById('fornecedorEPI').value = epi.fornecedor || '';
            document.getElementById('riscoEPI').value = epi.risco || '';
            document.getElementById('observacoesEPI').value = epi.observacoes || '';
            
            // Formatar datas
            if (epi.dataAquisicao) {
                const data = new Date(epi.dataAquisicao);
                const dia = String(data.getDate()).padStart(2, '0');
                const mes = String(data.getMonth() + 1).padStart(2, '0');
                const ano = data.getFullYear();
                document.getElementById('dataAquisicaoEPI').value = `${dia}/${mes}/${ano}`;
            } else {
                document.getElementById('dataAquisicaoEPI').value = '';
            }
            
            if (epi.dataValidade) {
                const data = new Date(epi.dataValidade);
                const dia = String(data.getDate()).padStart(2, '0');
                const mes = String(data.getMonth() + 1).padStart(2, '0');
                const ano = data.getFullYear();
                document.getElementById('dataValidadeEPI').value = `${dia}/${mes}/${ano}`;
            } else {
                document.getElementById('dataValidadeEPI').value = '';
            }
            
            // Mostrar formulário
            const formContainer = document.getElementById('formContainer');
            if (formContainer) {
                formContainer.style.display = 'block';
            }
            
            // Esconder listagem
            const listContainer = document.getElementById('listContainer');
            if (listContainer) {
                listContainer.style.display = 'none';
            }
            
            // Atualizar título do formulário
            const formTitle = document.getElementById('formTitle');
            if (formTitle) {
                formTitle.textContent = 'Editar EPI';
            }
            
            // Focar no primeiro campo
            document.getElementById('descricaoEPI').focus();
        }).catch(error => {
            console.error('Erro ao editar EPI:', error);
            this.exibirNotificacao('Erro ao editar EPI', 'error');
        });
    },
    
    /**
     * Exclui um EPI
     * @param {number} id - ID do EPI
     */
    excluirEPI: function(id) {
        if (confirm('Tem certeza que deseja excluir este EPI?')) {
            STORAGE.get('epis', id).then(epi => {
                if (!epi) {
                    this.exibirNotificacao('EPI não encontrado', 'error');
                    return;
                }
                
                // Excluir EPI
                STORAGE.remove('epis', id).then(() => {
                    this.exibirNotificacao('EPI excluído com sucesso', 'success');
                    
                    // Registrar no histórico
                    DASHBOARD.adicionarHistorico({
                        tipo: 'exclusao',
                        titulo: 'EPI excluído',
                        descricao: `EPI "${epi.descricao}" foi excluído`
                    });
                    
                    // Recarregar dados
                    this.carregarDados();
                }).catch(error => {
                    console.error('Erro ao excluir EPI:', error);
                    this.exibirNotificacao('Erro ao excluir EPI', 'error');
                });
            }).catch(error => {
                console.error('Erro ao buscar EPI:', error);
                this.exibirNotificacao('Erro ao buscar EPI', 'error');
            });
        }
    },
    
    /**
     * Cancela edição/cadastro e volta para listagem
     */
    cancelarEdicao: function() {
        // Limpar formulário
        this.limparFormulario();
        
        // Esconder formulário
        const formContainer = document.getElementById('formContainer');
        if (formContainer) {
            formContainer.style.display = 'none';
        }
        
        // Mostrar listagem
        const listContainer = document.getElementById('listContainer');
        if (listContainer) {
            listContainer.style.display = 'block';
        }
    },
    
    /**
     * Limpa o formulário de EPI
     */
    limparFormulario: function() {
        const formEPI = document.getElementById('formEPI');
        if (!formEPI) return;
        
        formEPI.removeAttribute('data-id');
        formEPI.reset();
        
        // Atualizar título do formulário
        const formTitle = document.getElementById('formTitle');
        if (formTitle) {
            formTitle.textContent = 'Novo EPI';
        }
    },
    
    /**
     * Filtra EPIs com base nos critérios selecionados
     */
    filtrarEPIs: function() {
        const filtroTipo = document.getElementById('filtroTipo').value;
        const filtroStatus = document.getElementById('filtroStatus').value;
        const filtroPeriodo = document.getElementById('filtroPeriodo').value;
        
        STORAGE.getAll('epis').then(epis => {
            let episFiltrados = epis;
            
            // Filtrar por tipo
            if (filtroTipo) {
                episFiltrados = episFiltrados.filter(epi => epi.tipo === filtroTipo);
            }
            
            // Filtrar por status
            if (filtroStatus) {
                const hoje = new Date();
                
                switch (filtroStatus) {
                    case 'valido':
                        episFiltrados = episFiltrados.filter(epi => {
                            if (!epi.dataValidade) return false;
                            const validade = new Date(epi.dataValidade);
                            return validade > hoje;
                        });
                        break;
                    case 'vencido':
                        episFiltrados = episFiltrados.filter(epi => {
                            if (!epi.dataValidade) return false;
                            const validade = new Date(epi.dataValidade);
                            return validade <= hoje;
                        });
                        break;
                    case 'proximo':
                        episFiltrados = episFiltrados.filter(epi => {
                            if (!epi.dataValidade) return false;
                            const validade = new Date(epi.dataValidade);
                            const diasRestantes = Math.ceil((validade - hoje) / (1000 * 60 * 60 * 24));
                            return validade > hoje && diasRestantes <= this.config.diasAlertaVencimento;
                        });
                        break;
                }
            }
            
            // Filtrar por período
            if (filtroPeriodo) {
                const diasAtras = parseInt(filtroPeriodo);
                const dataLimite = new Date();
                dataLimite.setDate(dataLimite.getDate() - diasAtras);
                
                episFiltrados = episFiltrados.filter(epi => {
                    if (!epi.dataAquisicao) return false;
                    const aquisicao = new Date(epi.dataAquisicao);
                    return aquisicao >= dataLimite;
                });
            }
            
            // Exibir EPIs filtrados
            this.exibirEPIs(episFiltrados);
        }).catch(error => {
            console.error('Erro ao filtrar EPIs:', error);
            this.exibirNotificacao('Erro ao filtrar EPIs', 'error');
        });
    },
    
    /**
     * Limpa filtros e exibe todos os EPIs
     */
    limparFiltros: function() {
        document.getElementById('filtroTipo').value = '';
        document.getElementById('filtroStatus').value = '';
        document.getElementById('filtroPeriodo').value = '';
        
        this.carregarDados();
    },
    
    /**
     * Exporta dados de EPIs para CSV
     */
    exportarDados: function() {
        STORAGE.getAll('epis').then(epis => {
            // Criar cabeçalho CSV
            let csv = 'Descrição,Tipo,CA,Fabricante,Fornecedor,Data de Aquisição,Data de Validade,Risco,Observações\n';
            
            // Adicionar linhas
            epis.forEach(epi => {
                const dataAquisicao = epi.dataAquisicao ? new Date(epi.dataAquisicao).toLocaleDateString('pt-BR') : '';
                const dataValidade = epi.dataValidade ? new Date(epi.dataValidade).toLocaleDateString('pt-BR') : '';
                
                // Escapar campos com vírgula
                const escapar = (campo) => {
                    if (!campo) return '';
                    if (campo.includes(',') || campo.includes('"') || campo.includes('\n')) {
                        return `"${campo.replace(/"/g, '""')}"`;
                    }
                    return campo;
                };
                
                csv += `${escapar(epi.descricao)},${escapar(epi.tipo)},${escapar(epi.ca)},${escapar(epi.fabricante)},${escapar(epi.fornecedor)},${dataAquisicao},${dataValidade},${escapar(epi.risco)},${escapar(epi.observacoes)}\n`;
            });
            
            // Criar blob e link para download
            const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
            const link = document.createElement('a');
            const url = URL.createObjectURL(blob);
            
            link.setAttribute('href', url);
            link.setAttribute('download', 'epis.csv');
            link.style.visibility = 'hidden';
            
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            
            this.exibirNotificacao('Dados exportados com sucesso', 'success');
        }).catch(error => {
            console.error('Erro ao exportar dados:', error);
            this.exibirNotificacao('Erro ao exportar dados', 'error');
        });
    },
    
    /**
     * Exibe uma notificação para o usuário
     * @param {string} mensagem - Mensagem a ser exibida
     * @param {string} tipo - Tipo de notificação (success, error, warning, info)
     */
    exibirNotificacao: function(mensagem, tipo) {
        // Verificar se o container de notificações existe
        let container = document.getElementById('notification-container');
        if (!container) {
            container = document.createElement('div');
            container.id = 'notification-container';
            document.body.appendChild(container);
        }
        
        // Criar notificação
        const notification = document.createElement('div');
        notification.className = `alert-notification alert-${tipo} show`;
        notification.innerHTML = `<p>${mensagem}</p><button class="alert-close-btn">&times;</button>`;
        
        // Adicionar ao container
        container.appendChild(notification);
        
        // Adicionar evento para fechar notificação
        notification.querySelector('.alert-close-btn').addEventListener('click', () => {
            notification.classList.replace('show', 'hide');
            setTimeout(() => {
                if (notification.parentNode) {
                    notification.parentNode.removeChild(notification);
                }
            }, 500);
        });
        
        // Auto-fechar após 5 segundos
        setTimeout(() => {
            if (notification.classList.contains('show')) {
                notification.classList.replace('show', 'hide');
                setTimeout(() => {
                    if (notification.parentNode) {
                        notification.parentNode.removeChild(notification);
                    }
                }, 500);
            }
        }, 5000);
    }
};

// Inicializar módulo quando o DOM estiver carregado
document.addEventListener('DOMContentLoaded', function() {
    // Verificar se estamos na página de EPIs
    if (document.querySelector('.epi-container')) {
        EPI.init();
    }
});
