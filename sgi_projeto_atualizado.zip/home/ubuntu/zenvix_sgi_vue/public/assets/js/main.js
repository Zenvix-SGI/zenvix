// js/main.js

document.addEventListener("DOMContentLoaded", () => {
    // --- Global Variables & DOM Elements ---
    const currentPage = window.location.pathname.split("/").pop() || "index.html";
    const isLoggedIn = localStorage.getItem("loggedIn") === "true";

    const themeToggleButton = document.getElementById("themeToggleButton");
    const logoutButton = document.getElementById("logoutButton");
    const loader = document.getElementById("loader");
    const copyrightYear = document.getElementById("copyrightYear");

    // --- Utility Functions ---
    /**
     * Retrieves data from localStorage.
     * @param {string} key - The key to retrieve.
     * @param {Array|Object} defaultType - The default value if key doesn't exist.
     * @returns {Array|Object} - The parsed data or the default value.
     */
    const getData = (key, defaultType = []) => {
        try {
            const data = localStorage.getItem(key);
            return data ? JSON.parse(data) : defaultType;
        } catch (error) {
            console.error(`Error reading localStorage key "${key}":`, error);
            return defaultType;
        }
    };

    /**
     * Applies the selected theme (light/dark) to the HTML element.
     * @param {string} theme - The theme to apply ('light' or 'dark').
     */
    const applyTheme = (theme) => {
        document.documentElement.setAttribute("data-theme", theme);
        if (themeToggleButton) {
            // Update icon based on the applied theme
            themeToggleButton.innerHTML = theme === "dark"
                ? '<i class="fas fa-sun"></i>' // Show sun icon in dark mode
                : '<i class="fas fa-moon"></i>'; // Show moon icon in light mode
        }
    };

    /**
     * Toggles the theme between light and dark.
     */
    const toggleTheme = () => {
        const currentTheme = document.documentElement.getAttribute("data-theme") || "light";
        const newTheme = currentTheme === "dark" ? "light" : "dark";
        localStorage.setItem("theme", newTheme);
        applyTheme(newTheme);
    };

    /**
     * Handles the logout process.
     * @param {Event} e - The click event.
     */
    const handleLogout = (e) => {
        e.preventDefault();
        
        // Use the global logout function if available
        if (typeof window.logoutUser === 'function') {
            window.logoutUser(true); // true = redirect to login
        } else {
            // Fallback logout implementation
            localStorage.removeItem("loggedIn");
            localStorage.removeItem("username");
            localStorage.removeItem("userRole");
            localStorage.removeItem("userName");
            localStorage.removeItem("sessionExpiry");
            window.location.href = "login.html";
        }
    };

    /**
     * Hides the loader element.
     */
    const hideLoader = () => {
        if (loader) {
            loader.classList.add('hidden');
            // Optional: Remove loader from DOM after transition
            setTimeout(() => {
                if (loader && loader.parentNode) {
                    loader.parentNode.removeChild(loader);
                }
            }, 500); // Match CSS transition duration
        }
    };

    /**
     * Updates copyright year in footer
     */
    const updateCopyrightYear = () => {
        if (copyrightYear) {
            copyrightYear.textContent = new Date().getFullYear();
        }
    };

    /**
     * Checks if user session is expired and handles accordingly
     * @returns {boolean} True if session is valid, false if expired
     */
    const checkSessionValidity = () => {
        const sessionExpiry = parseInt(localStorage.getItem("sessionExpiry") || "0");
        
        if (sessionExpiry && sessionExpiry < Date.now()) {
            // Session expired
            if (typeof window.logoutUser === 'function') {
                window.logoutUser(true);
            } else {
                localStorage.removeItem("loggedIn");
                localStorage.removeItem("username");
                localStorage.removeItem("userRole");
                localStorage.removeItem("userName");
                localStorage.removeItem("sessionExpiry");
                
                // Only redirect if not already on login page
                if (!["index.html", "login.html"].includes(currentPage)) {
                    window.location.href = "login.html?expired=true";
                }
            }
            return false;
        }
        return true;
    };

    // --- Initialization and Event Listeners ---

    // Update copyright year
    updateCopyrightYear();

    // Check session validity if logged in
    if (isLoggedIn && !checkSessionValidity()) {
        return; // Stop execution if session expired
    }

    // Authentication Check:
    // Redirect to login if not logged in and not on login page.
    // Redirect to dashboard if logged in and on login page.
    if (!isLoggedIn && !["index.html", "login.html"].includes(currentPage)) {
        window.location.href = "login.html";
        return; // Stop script execution
    } else if (isLoggedIn && ["index.html", "login.html"].includes(currentPage)) {
        window.location.href = "dashboard.html";
        return; // Stop script execution
    }

    // Theme Initialization:
    const savedTheme = localStorage.getItem("theme") || "light"; // Default to light
    applyTheme(savedTheme);
    if (themeToggleButton) {
        themeToggleButton.addEventListener("click", toggleTheme);
    }

    // Logout Button:
    if (logoutButton) {
        logoutButton.addEventListener("click", handleLogout);
    }

    // Display Username and Role (if elements exist):
    const usernameDisplay = document.getElementById("usernameDisplay");
    const userRoleDisplay = document.getElementById("userRoleDisplay");
    
    if (usernameDisplay) {
        const userName = localStorage.getItem("userName") || localStorage.getItem("username");
        usernameDisplay.textContent = userName ? userName : "Usuário";
    }
    
    if (userRoleDisplay) {
        const userRole = localStorage.getItem("userRole");
        let roleText = "Usuário";
        
        // Map role values to display text
        if (userRole === "admin") roleText = "Administrador";
        else if (userRole === "tecnico") roleText = "Técnico SST";
        else if (userRole === "medico") roleText = "Médico do Trabalho";
        
        userRoleDisplay.textContent = roleText;
    }

    // --- Dashboard Specific Logic ---
    /**
     * Loads and displays data specific to the dashboard page.
     */
    const loadDashboardData = () => {
        // Ensure this runs only on dashboard.html
        if (currentPage !== "dashboard.html") return;

        // Get dashboard elements
        const funcionariosAtivosSpan = document.getElementById("funcionariosAtivos");
        const empresasCadastradasSpan = document.getElementById("empresasCadastradas");
        const tiposEPISpan = document.getElementById("tiposEPI");
        const tiposDocumentoSpan = document.getElementById("tiposDocumento");
        const alertasList = document.getElementById("alertasList");
        const noAlertsMessage = document.getElementById("noAlertsMessage");
        const alertasExamesSpan = document.getElementById("alertasExames")?.querySelector(".count");
        const alertasTreinamentosSpan = document.getElementById("alertasTreinamentos")?.querySelector(".count");
        const alertasEpisSpan = document.getElementById("alertasEpis")?.querySelector(".count");
        const alertasDocumentosSpan = document.getElementById("alertasDocumentos")?.querySelector(".count");

        // Fetch data from storage
        const funcionarios = getData("funcionarios", []);
        const empresas = getData("empresas", []);
        const tiposEPI = getData("tiposEPI", []); // Assuming this stores EPI types
        const tiposDocumento = getData("tiposDocumento", []); // Assuming this stores document types
        const exames = getData("exames", []);
        const treinamentos = getData("treinamentos", []);
        const documentos = getData("documentos", []); // Changed from registrosDocumento

        // Update Status Card
        if (funcionariosAtivosSpan) funcionariosAtivosSpan.textContent = funcionarios.length;
        if (empresasCadastradasSpan) empresasCadastradasSpan.textContent = empresas.length;
        if (tiposEPISpan) tiposEPISpan.textContent = tiposEPI.length;
        if (tiposDocumentoSpan) tiposDocumentoSpan.textContent = tiposDocumento.length;

        // Calculate Alerts (Next 30 days)
        const hoje = new Date();
        const trintaDiasFrente = new Date();
        trintaDiasFrente.setDate(hoje.getDate() + 30);
        hoje.setHours(0, 0, 0, 0); // Normalize start of today
        trintaDiasFrente.setHours(23, 59, 59, 999); // End of target day for inclusive comparison

        let totalAlerts = 0;

        // Exames Vencendo (Based on 'dataVencimentoExame')
        const examesVencendo = exames.filter(ex => {
            if (!ex.dataVencimentoExame) return false;
            const dataVencimento = new Date(ex.dataVencimentoExame + 'T00:00:00'); // Ensure correct date parsing
            return dataVencimento >= hoje && dataVencimento <= trintaDiasFrente;
        }).length;
        if (alertasExamesSpan) {
            alertasExamesSpan.textContent = examesVencendo;
            alertasExamesSpan.classList.toggle('zero', examesVencendo === 0);
        }
        totalAlerts += examesVencendo;

        // Treinamentos Vencendo (Based on 'dataVencimentoTreinamento')
        const treinamentosVencendo = treinamentos.filter(tr => {
            if (!tr.dataVencimentoTreinamento) return false;
            const dataVencimento = new Date(tr.dataVencimentoTreinamento + 'T00:00:00');
            return dataVencimento >= hoje && dataVencimento <= trintaDiasFrente;
        }).length;
        if (alertasTreinamentosSpan) {
             alertasTreinamentosSpan.textContent = treinamentosVencendo;
             alertasTreinamentosSpan.classList.toggle('zero', treinamentosVencendo === 0);
        }
        totalAlerts += treinamentosVencendo;

        // Validade CA EPIs Vencendo (Based on 'validadeCA' in tiposEPI)
        const episVencendo = tiposEPI.filter(tipo => {
            if (!tipo.validadeCA) return false;
            const dataValidade = new Date(tipo.validadeCA + 'T00:00:00');
            return dataValidade >= hoje && dataValidade <= trintaDiasFrente;
        }).length;
        if (alertasEpisSpan) {
            alertasEpisSpan.textContent = episVencendo;
            alertasEpisSpan.classList.toggle('zero', episVencendo === 0);
        }
        totalAlerts += episVencendo;

        // Documentos Vencendo (Based on 'dataValidade' in documentos)
        const documentosVencendo = documentos.filter(doc => {
            if (!doc.dataValidade) return false;
            const dataValidade = new Date(doc.dataValidade + 'T00:00:00');
            return dataValidade >= hoje && dataValidade <= trintaDiasFrente;
        }).length;
        if (alertasDocumentosSpan) {
            alertasDocumentosSpan.textContent = documentosVencendo;
            alertasDocumentosSpan.classList.toggle('zero', documentosVencendo === 0);
        }
        totalAlerts += documentosVencendo;

        // Show/Hide Alerts Section
        if (alertasList && noAlertsMessage) {
            if (totalAlerts > 0) {
                alertasList.style.display = ''; // Show list
                noAlertsMessage.style.display = 'none'; // Hide message
            } else {
                alertasList.style.display = 'none'; // Hide list
                noAlertsMessage.style.display = 'block'; // Show message
            }
        }
    };

    // Execute dashboard logic if on the correct page
    if (currentPage === "dashboard.html") {
        loadDashboardData();
    }

    // Add global event listeners for common UI elements
    document.addEventListener('click', (e) => {
        // Handle mobile menu toggle
        if (e.target.matches('.mobile-menu-toggle, .mobile-menu-toggle *')) {
            const mobileMenu = document.querySelector('.mobile-menu');
            if (mobileMenu) {
                mobileMenu.classList.toggle('active');
                e.preventDefault();
            }
        }
        
        // Handle dropdown toggles
        if (e.target.matches('.dropdown-toggle, .dropdown-toggle *')) {
            const dropdown = e.target.closest('.dropdown');
            if (dropdown) {
                dropdown.classList.toggle('active');
                e.preventDefault();
                
                // Close other open dropdowns
                document.querySelectorAll('.dropdown.active').forEach(openDropdown => {
                    if (openDropdown !== dropdown) {
                        openDropdown.classList.remove('active');
                    }
                });
            }
        }
    });
    
    // Close dropdowns when clicking outside
    document.addEventListener('click', (e) => {
        if (!e.target.closest('.dropdown')) {
            document.querySelectorAll('.dropdown.active').forEach(dropdown => {
                dropdown.classList.remove('active');
            });
        }
    });

    // Hide loader once everything is set up
    // Use window.onload for images and other resources, or keep DOMContentLoaded if sufficient
    window.addEventListener('load', hideLoader);
    // Initial hide after DOM setup
    hideLoader();
});
