/**
 * ZENVIX SGI - Módulo de Exames Ocupacionais
 * 
 * Este arquivo contém funções para gerenciar o cadastro, controle e vencimentos de exames ocupacionais.
 */

// Namespace para evitar conflitos
const EXAME = {
    // Configurações
    config: {
        diasAlertaVencimento: 30, // Dias para alertar antes do vencimento
        limitePorPagina: 10       // Número de itens por página na listagem
    },
    
    // Dados
    data: {
        tipos: [
            'Admissional',
            'Periódico',
            'Retorno ao Trabalho',
            'Mudança de Função',
            'Demissional',
            'Complementar'
        ],
        exames: [
            'Hemograma Completo',
            'Glicemia em Jejum',
            'Audiometria',
            'Acuidade Visual',
            'Eletrocardiograma',
            'Eletroencefalograma',
            'Espirometria',
            'Raio-X Tórax',
            'Avaliação Psicológica',
            'Avaliação Psicossocial',
            'Exame Clínico'
        ]
    },
    
    /**
     * Inicializa o módulo de exames ocupacionais
     */
    init: function() {
        console.log('Inicializando módulo de exames ocupacionais...');
        
        // Verificar se usuário está autenticado
        if (!STORAGE.isAuthenticated()) {
            console.warn('Usuário não autenticado. Redirecionando para login...');
            window.location.href = 'login.html';
            return;
        }
        
        // Inicializar componentes
        this.initComponents();
        
        // Configurar eventos
        this.setupEvents();
        
        // Carregar dados iniciais
        this.carregarDados();
        
        console.log('Módulo de exames ocupacionais inicializado.');
    },
    
    /**
     * Inicializa componentes da interface
     */
    initComponents: function() {
        // Preencher selects de tipos de exame
        const tipoSelect = document.getElementById('tipoExame');
        if (tipoSelect) {
            tipoSelect.innerHTML = '<option value="">Selecione...</option>';
            this.data.tipos.forEach(tipo => {
                const option = document.createElement('option');
                option.value = tipo;
                option.textContent = tipo;
                tipoSelect.appendChild(option);
            });
        }
        
        // Preencher selects de exames realizados
        const examesSelect = document.getElementById('examesRealizados');
        if (examesSelect) {
            this.data.exames.forEach(exame => {
                const option = document.createElement('option');
                option.value = exame;
                option.textContent = exame;
                examesSelect.appendChild(option);
            });
            
            // Inicializar select múltiplo
            // Em uma implementação real, usaríamos uma biblioteca como Select2
            examesSelect.setAttribute('multiple', 'multiple');
            examesSelect.setAttribute('size', '5');
        }
        
        // Inicializar datepickers
        const datepickers = document.querySelectorAll('.datepicker');
        if (datepickers.length > 0) {
            datepickers.forEach(datepicker => {
                // Aqui seria implementado o datepicker real
                // Como é uma simulação, apenas adicionamos o evento change
                datepicker.addEventListener('change', function() {
                    // Validar formato da data (DD/MM/AAAA)
                    const regex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
                    if (!regex.test(this.value)) {
                        this.value = '';
                        alert('Formato de data inválido. Use DD/MM/AAAA.');
                    }
                });
            });
        }
        
        // Carregar funcionários para o select
        STORAGE.getAll('funcionarios').then(funcionarios => {
            const funcionarioSelect = document.getElementById('funcionarioExame');
            if (funcionarioSelect) {
                funcionarioSelect.innerHTML = '<option value="">Selecione...</option>';
                
                // Ordenar funcionários por nome
                funcionarios.sort((a, b) => a.nome.localeCompare(b.nome));
                
                funcionarios.forEach(funcionario => {
                    if (funcionario.ativo) {
                        const option = document.createElement('option');
                        option.value = funcionario.id;
                        option.textContent = funcionario.nome;
                        funcionarioSelect.appendChild(option);
                    }
                });
            }
            
            // Também preencher o select de filtro
            const filtroFuncionario = document.getElementById('filtroFuncionario');
            if (filtroFuncionario) {
                filtroFuncionario.innerHTML = '<option value="">Todos</option>';
                
                funcionarios.forEach(funcionario => {
                    if (funcionario.ativo) {
                        const option = document.createElement('option');
                        option.value = funcionario.id;
                        option.textContent = funcionario.nome;
                        filtroFuncionario.appendChild(option);
                    }
                });
            }
        }).catch(error => {
            console.error('Erro ao carregar funcionários:', error);
        });
    },
    
    /**
     * Configura eventos da interface
     */
    setupEvents: function() {
        // Formulário de cadastro de exame
        const formExame = document.getElementById('formExame');
        if (formExame) {
            formExame.addEventListener('submit', (e) => {
                e.preventDefault();
                this.salvarExame();
            });
        }
        
        // Botão de novo exame
        const btnNovoExame = document.getElementById('btnNovoExame');
        if (btnNovoExame) {
            btnNovoExame.addEventListener('click', () => {
                this.limparFormulario();
                
                // Mostrar formulário
                const formContainer = document.getElementById('formContainer');
                if (formContainer) {
                    formContainer.style.display = 'block';
                }
                
                // Esconder listagem
                const listContainer = document.getElementById('listContainer');
                if (listContainer) {
                    listContainer.style.display = 'none';
                }
            });
        }
        
        // Botão de cancelar
        const btnCancelar = document.getElementById('btnCancelar');
        if (btnCancelar) {
            btnCancelar.addEventListener('click', (e) => {
                e.preventDefault();
                this.cancelarEdicao();
            });
        }
        
        // Botão de filtrar
        const btnFiltrar = document.getElementById('btnFiltrar');
        if (btnFiltrar) {
            btnFiltrar.addEventListener('click', () => {
                this.filtrarExames();
            });
        }
        
        // Botão de limpar filtros
        const btnLimparFiltros = document.getElementById('btnLimparFiltros');
        if (btnLimparFiltros) {
            btnLimparFiltros.addEventListener('click', () => {
                this.limparFiltros();
            });
        }
        
        // Botão de exportar
        const btnExportar = document.getElementById('btnExportar');
        if (btnExportar) {
            btnExportar.addEventListener('click', () => {
                this.exportarDados();
            });
        }
        
        // Evento para calcular data de validade automaticamente
        const dataRealizacao = document.getElementById('dataRealizacaoExame');
        const validadeMeses = document.getElementById('validadeMesesExame');
        const dataValidade = document.getElementById('dataValidadeExame');
        
        if (dataRealizacao && validadeMeses && dataValidade) {
            const calcularValidade = () => {
                const dataStr = dataRealizacao.value;
                const meses = parseInt(validadeMeses.value);
                
                if (dataStr && !isNaN(meses) && meses > 0) {
                    // Converter data DD/MM/AAAA para objeto Date
                    const partes = dataStr.split('/');
                    if (partes.length === 3) {
                        const data = new Date(partes[2], partes[1] - 1, partes[0]);
                        
                        // Adicionar meses
                        data.setMonth(data.getMonth() + meses);
                        
                        // Formatar data de volta para DD/MM/AAAA
                        const dia = String(data.getDate()).padStart(2, '0');
                        const mes = String(data.getMonth() + 1).padStart(2, '0');
                        const ano = data.getFullYear();
                        
                        dataValidade.value = `${dia}/${mes}/${ano}`;
                    }
                }
            };
            
            dataRealizacao.addEventListener('change', calcularValidade);
            validadeMeses.addEventListener('change', calcularValidade);
        }
        
        // Evento para preencher tipo de exame com base no funcionário selecionado
        const funcionarioSelect = document.getElementById('funcionarioExame');
        if (funcionarioSelect) {
            funcionarioSelect.addEventListener('change', () => {
                const funcionarioId = parseInt(funcionarioSelect.value);
                if (!isNaN(funcionarioId)) {
                    // Verificar se funcionário já tem exames
                    STORAGE.getAll('exames').then(exames => {
                        const examesFuncionario = exames.filter(e => e.funcionarioId === funcionarioId);
                        
                        // Se não tem exames, sugerir Admissional
                        if (examesFuncionario.length === 0) {
                            const tipoSelect = document.getElementById('tipoExame');
                            if (tipoSelect) {
                                tipoSelect.value = 'Admissional';
                            }
                        }
                    }).catch(error => {
                        console.error('Erro ao verificar exames do funcionário:', error);
                    });
                }
            });
        }
    },
    
    /**
     * Carrega dados iniciais
     */
    carregarDados: function() {
        // Carregar exames do banco de dados
        STORAGE.getAll('exames').then(exames => {
            // Exibir exames na tabela
            this.exibirExames(exames);
            
            // Verificar vencimentos
            this.verificarVencimentos(exames);
        }).catch(error => {
            console.error('Erro ao carregar exames:', error);
            this.exibirNotificacao('Erro ao carregar dados de exames', 'error');
        });
    },
    
    /**
     * Exibe exames na tabela
     * @param {Array} exames - Lista de exames
     */
    exibirExames: function(exames) {
        const tabela = document.getElementById('tabelaExames');
        if (!tabela) return;
        
        const tbody = tabela.querySelector('tbody');
        if (!tbody) return;
        
        // Limpar tabela
        tbody.innerHTML = '';
        
        // Se não houver exames, exibir mensagem
        if (exames.length === 0) {
            const tr = document.createElement('tr');
            tr.innerHTML = '<td colspan="7" class="text-center">Nenhum exame cadastrado.</td>';
            tbody.appendChild(tr);
            return;
        }
        
        // Obter funcionários para exibir nomes
        STORAGE.getAll('funcionarios').then(funcionarios => {
            const funcionariosMap = {};
            funcionarios.forEach(f => {
                funcionariosMap[f.id] = f.nome;
            });
            
            // Adicionar exames à tabela
            exames.forEach(exame => {
                const tr = document.createElement('tr');
                
                // Formatar datas
                const dataRealizacao = exame.dataRealizacao ? new Date(exame.dataRealizacao).toLocaleDateString('pt-BR') : '-';
                const dataValidade = exame.dataValidade ? new Date(exame.dataValidade).toLocaleDateString('pt-BR') : '-';
                
                // Obter nome do funcionário
                const nomeFuncionario = funcionariosMap[exame.funcionarioId] || 'Não informado';
                
                // Verificar status de validade
                let statusClass = '';
                let statusText = '';
                
                if (exame.dataValidade) {
                    const hoje = new Date();
                    const validade = new Date(exame.dataValidade);
                    const diasRestantes = Math.ceil((validade - hoje) / (1000 * 60 * 60 * 24));
                    
                    if (validade < hoje) {
                        statusClass = 'status-expired';
                        statusText = 'Vencido';
                    } else if (diasRestantes <= this.config.diasAlertaVencimento) {
                        statusClass = 'status-warning';
                        statusText = `Vence em ${diasRestantes} dias`;
                    } else {
                        statusClass = 'status-valid';
                        statusText = 'Válido';
                    }
                } else {
                    statusClass = 'status-info';
                    statusText = 'Sem validade';
                }
                
                // Formatar resultado
                let resultadoClass = '';
                let resultadoText = exame.resultado || 'Não informado';
                
                if (exame.resultado === 'Apto') {
                    resultadoClass = 'status-valid';
                } else if (exame.resultado === 'Apto com Restrições') {
                    resultadoClass = 'status-warning';
                } else if (exame.resultado === 'Inapto') {
                    resultadoClass = 'status-expired';
                }
                
                tr.innerHTML = `
                    <td>${exame.tipo}</td>
                    <td>${nomeFuncionario}</td>
                    <td>${dataRealizacao}</td>
                    <td>${dataValidade}</td>
                    <td><span class="status-badge ${resultadoClass}">${resultadoText}</span></td>
                    <td><span class="status-badge ${statusClass}">${statusText}</span></td>
                    <td>
                        <button class="btn-sm view-btn" data-id="${exame.id}"><i class="fas fa-eye"></i></button>
                        <button class="btn-sm edit-btn" data-id="${exame.id}"><i class="fas fa-edit"></i></button>
                        <button class="btn-sm delete-btn" data-id="${exame.id}"><i class="fas fa-trash"></i></button>
                    </td>
                `;
                
                tbody.appendChild(tr);
            });
            
            // Adicionar eventos aos botões
            tbody.querySelectorAll('.view-btn').forEach(btn => {
                btn.addEventListener('click', () => {
                    const id = parseInt(btn.getAttribute('data-id'));
                    this.visualizarExame(id);
                });
            });
            
            tbody.querySelectorAll('.edit-btn').forEach(btn => {
                btn.addEventListener('click', () => {
                    const id = parseInt(btn.getAttribute('data-id'));
                    this.editarExame(id);
                });
            });
            
            tbody.querySelectorAll('.delete-btn').forEach(btn => {
                btn.addEventListener('click', () => {
                    const id = parseInt(btn.getAttribute('data-id'));
                    this.excluirExame(id);
                });
            });
        }).catch(error => {
            console.error('Erro ao carregar funcionários:', error);
            tbody.innerHTML = '<tr><td colspan="7" class="text-center">Erro ao carregar dados.</td></tr>';
        });
    },
    
    /**
     * Verifica vencimentos de exames
     * @param {Array} exames - Lista de exames
     */
    verificarVencimentos: function(exames) {
        const hoje = new Date();
        const vencidos = [];
        const aVencer = [];
        
        exames.forEach(exame => {
            if (!exame.dataValidade) return;
            
            const validade = new Date(exame.dataValidade);
            const diasRestantes = Math.ceil((validade - hoje) / (1000 * 60 * 60 * 24));
            
            if (validade < hoje) {
                vencidos.push(exame);
            } else if (diasRestantes <= this.config.diasAlertaVencimento) {
                aVencer.push({
                    exame: exame,
                    diasRestantes: diasRestantes
                });
            }
        });
        
        // Atualizar contadores
        const contadorVencidos = document.getElementById('examesVencidos');
        const contadorAVencer = document.getElementById('examesAVencer');
        const contadorValidos = document.getElementById('examesValidos');
        const contadorTotal = document.getElementById('totalExames');
        
        if (contadorVencidos) contadorVencidos.textContent = vencidos.length;
        if (contadorAVencer) contadorAVencer.textContent = aVencer.length;
        
        if (contadorValidos) {
            const validos = exames.filter(e => {
                if (!e.dataValidade) return false;
                const validade = new Date(e.dataValidade);
                return validade > hoje && Math.ceil((validade - hoje) / (1000 * 60 * 60 * 24)) > this.config.diasAlertaVencimento;
            }).length;
            contadorValidos.textContent = validos;
        }
        
        if (contadorTotal) contadorTotal.textContent = exames.length;
        
        // Exibir alertas
        if (vencidos.length > 0 || aVencer.length > 0) {
            // Obter funcionários para exibir nomes
            STORAGE.getAll('funcionarios').then(funcionarios => {
                const funcionariosMap = {};
                funcionarios.forEach(f => {
                    funcionariosMap[f.id] = f.nome;
                });
                
                let mensagem = '';
                
                if (vencidos.length > 0) {
                    mensagem += `<strong>${vencidos.length} exame(s) vencido(s):</strong><br>`;
                    vencidos.forEach(exame => {
                        const nomeFuncionario = funcionariosMap[exame.funcionarioId] || 'Não informado';
                        mensagem += `- ${exame.tipo} - ${nomeFuncionario}<br>`;
                    });
                }
                
                if (aVencer.length > 0) {
                    if (mensagem) mensagem += '<br>';
                    mensagem += `<strong>${aVencer.length} exame(s) próximo(s) do vencimento:</strong><br>`;
                    aVencer.forEach(item => {
                        const nomeFuncionario = funcionariosMap[item.exame.funcionarioId] || 'Não informado';
                        mensagem += `- ${item.exame.tipo} - ${nomeFuncionario} - Vence em ${item.diasRestantes} dias<br>`;
                    });
                }
                
                this.exibirNotificacao(mensagem, 'warning');
            }).catch(error => {
                console.error('Erro ao carregar funcionários:', error);
            });
        }
    },
    
    /**
     * Salva um exame (novo ou edição)
     */
    salvarExame: function() {
        // Obter dados do formulário
        const formExame = document.getElementById('formExame');
        if (!formExame) return;
        
        const id = formExame.getAttribute('data-id');
        const tipo = document.getElementById('tipoExame').value;
        const funcionarioId = parseInt(document.getElementById('funcionarioExame').value);
        const dataRealizacao = document.getElementById('dataRealizacaoExame').value;
        const dataValidade = document.getElementById('dataValidadeExame').value;
        const resultado = document.getElementById('resultadoExame').value;
        const medico = document.getElementById('medicoExame').value.trim();
        const crm = document.getElementById('crmExame').value.trim();
        
        // Obter exames realizados (select múltiplo)
        const examesSelect = document.getElementById('examesRealizados');
        const examesRealizados = [];
        if (examesSelect) {
            for (let i = 0; i < examesSelect.options.length; i++) {
                if (examesSelect.options[i].selected) {
                    examesRealizados.push(examesSelect.options[i].value);
                }
            }
        }
        
        const observacoes = document.getElementById('observacoesExame').value.trim();
        
        // Validar campos obrigatórios
        if (!tipo || isNaN(funcionarioId) || !dataRealizacao) {
            this.exibirNotificacao('Preencha os campos obrigatórios', 'error');
            return;
        }
        
        // Converter datas
        let dataRealizacaoISO = null;
        let dataValidadeISO = null;
        
        if (dataRealizacao) {
            const partes = dataRealizacao.split('/');
            if (partes.length === 3) {
                dataRealizacaoISO = `${partes[2]}-${partes[1]}-${partes[0]}`;
            }
        }
        
        if (dataValidade) {
            const partes = dataValidade.split('/');
            if (partes.length === 3) {
                dataValidadeISO = `${partes[2]}-${partes[1]}-${partes[0]}`;
            }
        }
        
        // Criar objeto exame
        const exame = {
            tipo: tipo,
            funcionarioId: funcionarioId,
            dataRealizacao: dataRealizacaoISO,
            dataValidade: dataValidadeISO,
            resultado: resultado,
            medico: medico,
            crm: crm,
            examesRealizados: examesRealizados,
            observacoes: observacoes
        };
        
        // Se for edição, incluir ID
        if (id) {
            exame.id = parseInt(id);
            
            // Atualizar exame
            STORAGE.update('exames', exame).then(() => {
                this.exibirNotificacao('Exame atualizado com sucesso', 'success');
                
                // Registrar no histórico
                DASHBOARD.adicionarHistorico({
                    tipo: 'edicao',
                    titulo: 'Exame atualizado',
                    descricao: `Exame "${tipo}" foi atualizado`
                });
                
                // Voltar para listagem
                this.cancelarEdicao();
                
                // Recarregar dados
                this.carregarDados();
            }).catch(error => {
                console.error('Erro ao atualizar exame:', error);
                this.exibirNotificacao('Erro ao atualizar exame', 'error');
            });
        } else {
            // Adicionar novo exame
            STORAGE.add('exames', exame).then(() => {
                this.exibirNotificacao('Exame cadastrado com sucesso', 'success');
                
                // Registrar no histórico
                DASHBOARD.adicionarHistorico({
                    tipo: 'exame',
                    titulo: 'Novo exame cadastrado',
                    descricao: `Exame "${tipo}" foi cadastrado`
                });
                
                // Voltar para listagem
                this.cancelarEdicao();
                
                // Recarregar dados
                this.carregarDados();
            }).catch(error => {
                console.error('Erro ao cadastrar exame:', error);
                this.exibirNotificacao('Erro ao cadastrar exame', 'error');
            });
        }
    },
    
    /**
     * Visualiza detalhes de um exame
     * @param {number} id - ID do exame
     */
    visualizarExame: function(id) {
        STORAGE.get('exames', id).then(exame => {
            if (!exame) {
                this.exibirNotificacao('Exame não encontrado', 'error');
                return;
            }
            
            // Obter nome do funcionário
            STORAGE.get('funcionarios', exame.funcionarioId).then(funcionario => {
                const nomeFuncionario = funcionario ? funcionario.nome : 'Não informado';
                
                // Criar modal de visualização
                const modal = document.createElement('div');
                modal.className = 'modal fade show';
                modal.style.display = 'block';
                
                // Formatar datas
                const dataRealizacao = exame.dataRealizacao ? new Date(exame.dataRealizacao).toLocaleDateString('pt-BR') : '-';
                const dataValidade = exame.dataValidade ? new Date(exame.dataValidade).toLocaleDateString('pt-BR') : '-';
                
                // Formatar exames realizados
                const examesRealizados = exame.examesRealizados && exame.examesRealizados.length > 0 
                    ? exame.examesRealizados.join(', ') 
                    : 'Não informado';
                
                modal.innerHTML = `
                    <div class="modal-dialog modal-dialog-centered">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title">Detalhes do Exame</h5>
                                <button type="button" class="close" data-dismiss="modal">&times;</button>
                            </div>
                            <div class="modal-body">
                                <div class="row">
                                    <div class="col-md-6">
                                        <p><strong>Tipo:</strong> ${exame.tipo}</p>
                                        <p><strong>Funcionário:</strong> ${nomeFuncionario}</p>
                                        <p><strong>Data de Realização:</strong> ${dataRealizacao}</p>
                                        <p><strong>Data de Validade:</strong> ${dataValidade}</p>
                                        <p><strong>Resultado:</strong> ${exame.resultado || 'Não informado'}</p>
                                    </div>
                                    <div class="col-md-6">
                                        <p><strong>Médico:</strong> ${exame.medico || 'Não informado'}</p>
                                        <p><strong>CRM:</strong> ${exame.crm || 'Não informado'}</p>
                                        <p><strong>Exames Realizados:</strong> ${examesRealizados}</p>
                                        <p><strong>Observações:</strong> ${exame.observacoes || 'Não informado'}</p>
                                    </div>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Fechar</button>
                                <button type="button" class="btn btn-primary" id="btnEditarModal">Editar</button>
                            </div>
                        </div>
                    </div>
                `;
                
                // Adicionar modal ao body
                document.body.appendChild(modal);
                
                // Adicionar backdrop
                const backdrop = document.createElement('div');
                backdrop.className = 'modal-backdrop fade show';
                document.body.appendChild(backdrop);
                
                // Adicionar evento para fechar modal
                modal.querySelector('[data-dismiss="modal"]').addEventListener('click', () => {
                    document.body.removeChild(modal);
                    document.body.removeChild(backdrop);
                    document.body.classList.remove('modal-open');
                });
                
                // Adicionar evento para editar
                modal.querySelector('#btnEditarModal').addEventListener('click', () => {
                    document.body.removeChild(modal);
                    document.body.removeChild(backdrop);
                    document.body.classList.remove('modal-open');
                    
                    this.editarExame(id);
                });
                
                // Adicionar classe ao body
                document.body.classList.add('modal-open');
            }).catch(error => {
                console.error('Erro ao carregar funcionário:', error);
                this.exibirNotificacao('Erro ao carregar dados do funcionário', 'error');
            });
        }).catch(error => {
            console.error('Erro ao visualizar exame:', error);
            this.exibirNotificacao('Erro ao visualizar exame', 'error');
        });
    },
    
    /**
     * Edita um exame
     * @param {number} id - ID do exame
     */
    editarExame: function(id) {
        STORAGE.get('exames', id).then(exame => {
            if (!exame) {
                this.exibirNotificacao('Exame não encontrado', 'error');
                return;
            }
            
            // Preencher formulário
            const formExame = document.getElementById('formExame');
            if (!formExame) return;
            
            formExame.setAttribute('data-id', exame.id);
            document.getElementById('tipoExame').value = exame.tipo || '';
            document.getElementById('funcionarioExame').value = exame.funcionarioId || '';
            document.getElementById('resultadoExame').value = exame.resultado || '';
            document.getElementById('medicoExame').value = exame.medico || '';
            document.getElementById('crmExame').value = exame.crm || '';
            document.getElementById('observacoesExame').value = exame.observacoes || '';
            
            // Selecionar exames realizados
            const examesSelect = document.getElementById('examesRealizados');
            if (examesSelect && exame.examesRealizados) {
                for (let i = 0; i < examesSelect.options.length; i++) {
                    examesSelect.options[i].selected = exame.examesRealizados.includes(examesSelect.options[i].value);
                }
            }
            
            // Calcular validade em meses
            if (exame.dataRealizacao && exame.dataValidade) {
                const dataRealizacao = new Date(exame.dataRealizacao);
                const dataValidade = new Date(exame.dataValidade);
                const meses = (dataValidade.getFullYear() - dataRealizacao.getFullYear()) * 12 + 
                              (dataValidade.getMonth() - dataRealizacao.getMonth());
                document.getElementById('validadeMesesExame').value = meses;
            } else {
                document.getElementById('validadeMesesExame').value = '';
            }
            
            // Formatar datas
            if (exame.dataRealizacao) {
                const data = new Date(exame.dataRealizacao);
                const dia = String(data.getDate()).padStart(2, '0');
                const mes = String(data.getMonth() + 1).padStart(2, '0');
                const ano = data.getFullYear();
                document.getElementById('dataRealizacaoExame').value = `${dia}/${mes}/${ano}`;
            } else {
                document.getElementById('dataRealizacaoExame').value = '';
            }
            
            if (exame.dataValidade) {
                const data = new Date(exame.dataValidade);
                const dia = String(data.getDate()).padStart(2, '0');
                const mes = String(data.getMonth() + 1).padStart(2, '0');
                const ano = data.getFullYear();
                document.getElementById('dataValidadeExame').value = `${dia}/${mes}/${ano}`;
            } else {
                document.getElementById('dataValidadeExame').value = '';
            }
            
            // Mostrar formulário
            const formContainer = document.getElementById('formContainer');
            if (formContainer) {
                formContainer.style.display = 'block';
            }
            
            // Esconder listagem
            const listContainer = document.getElementById('listContainer');
            if (listContainer) {
                listContainer.style.display = 'none';
            }
            
            // Atualizar título do formulário
            const formTitle = document.getElementById('formTitle');
            if (formTitle) {
                formTitle.textContent = 'Editar Exame';
            }
            
            // Focar no primeiro campo
            document.getElementById('tipoExame').focus();
        }).catch(error => {
            console.error('Erro ao editar exame:', error);
            this.exibirNotificacao('Erro ao editar exame', 'error');
        });
    },
    
    /**
     * Exclui um exame
     * @param {number} id - ID do exame
     */
    excluirExame: function(id) {
        if (confirm('Tem certeza que deseja excluir este exame?')) {
            STORAGE.get('exames', id).then(exame => {
                if (!exame) {
                    this.exibirNotificacao('Exame não encontrado', 'error');
                    return;
                }
                
                // Excluir exame
                STORAGE.remove('exames', id).then(() => {
                    this.exibirNotificacao('Exame excluído com sucesso', 'success');
                    
                    // Registrar no histórico
                    DASHBOARD.adicionarHistorico({
                        tipo: 'exclusao',
                        titulo: 'Exame excluído',
                        descricao: `Exame "${exame.tipo}" foi excluído`
                    });
                    
                    // Recarregar dados
                    this.carregarDados();
                }).catch(error => {
                    console.error('Erro ao excluir exame:', error);
                    this.exibirNotificacao('Erro ao excluir exame', 'error');
                });
            }).catch(error => {
                console.error('Erro ao buscar exame:', error);
                this.exibirNotificacao('Erro ao buscar exame', 'error');
            });
        }
    },
    
    /**
     * Cancela edição/cadastro e volta para listagem
     */
    cancelarEdicao: function() {
        // Limpar formulário
        this.limparFormulario();
        
        // Esconder formulário
        const formContainer = document.getElementById('formContainer');
        if (formContainer) {
            formContainer.style.display = 'none';
        }
        
        // Mostrar listagem
        const listContainer = document.getElementById('listContainer');
        if (listContainer) {
            listContainer.style.display = 'block';
        }
    },
    
    /**
     * Limpa o formulário de exame
     */
    limparFormulario: function() {
        const formExame = document.getElementById('formExame');
        if (!formExame) return;
        
        formExame.removeAttribute('data-id');
        formExame.reset();
        
        // Limpar select múltiplo
        const examesSelect = document.getElementById('examesRealizados');
        if (examesSelect) {
            for (let i = 0; i < examesSelect.options.length; i++) {
                examesSelect.options[i].selected = false;
            }
        }
        
        // Atualizar título do formulário
        const formTitle = document.getElementById('formTitle');
        if (formTitle) {
            formTitle.textContent = 'Novo Exame';
        }
    },
    
    /**
     * Filtra exames com base nos critérios selecionados
     */
    filtrarExames: function() {
        const filtroTipo = document.getElementById('filtroTipo').value;
        const filtroFuncionario = document.getElementById('filtroFuncionario').value;
        const filtroStatus = document.getElementById('filtroStatus').value;
        const filtroResultado = document.getElementById('filtroResultado').value;
        
        STORAGE.getAll('exames').then(exames => {
            let examesFiltrados = exames;
            
            // Filtrar por tipo
            if (filtroTipo) {
                examesFiltrados = examesFiltrados.filter(e => e.tipo === filtroTipo);
            }
            
            // Filtrar por funcionário
            if (filtroFuncionario) {
                const funcionarioId = parseInt(filtroFuncionario);
                examesFiltrados = examesFiltrados.filter(e => e.funcionarioId === funcionarioId);
            }
            
            // Filtrar por status
            if (filtroStatus) {
                const hoje = new Date();
                
                switch (filtroStatus) {
                    case 'valido':
                        examesFiltrados = examesFiltrados.filter(e => {
                            if (!e.dataValidade) return false;
                            const validade = new Date(e.dataValidade);
                            return validade > hoje;
                        });
                        break;
                    case 'vencido':
                        examesFiltrados = examesFiltrados.filter(e => {
                            if (!e.dataValidade) return false;
                            const validade = new Date(e.dataValidade);
                            return validade <= hoje;
                        });
                        break;
                    case 'proximo':
                        examesFiltrados = examesFiltrados.filter(e => {
                            if (!e.dataValidade) return false;
                            const validade = new Date(e.dataValidade);
                            const diasRestantes = Math.ceil((validade - hoje) / (1000 * 60 * 60 * 24));
                            return validade > hoje && diasRestantes <= this.config.diasAlertaVencimento;
                        });
                        break;
                }
            }
            
            // Filtrar por resultado
            if (filtroResultado) {
                examesFiltrados = examesFiltrados.filter(e => e.resultado === filtroResultado);
            }
            
            // Exibir exames filtrados
            this.exibirExames(examesFiltrados);
        }).catch(error => {
            console.error('Erro ao filtrar exames:', error);
            this.exibirNotificacao('Erro ao filtrar exames', 'error');
        });
    },
    
    /**
     * Limpa filtros e exibe todos os exames
     */
    limparFiltros: function() {
        document.getElementById('filtroTipo').value = '';
        document.getElementById('filtroFuncionario').value = '';
        document.getElementById('filtroStatus').value = '';
        document.getElementById('filtroResultado').value = '';
        
        this.carregarDados();
    },
    
    /**
     * Exporta dados de exames para CSV
     */
    exportarDados: function() {
        Promise.all([
            STORAGE.getAll('exames'),
            STORAGE.getAll('funcionarios')
        ]).then(([exames, funcionarios]) => {
            // Criar mapa de funcionários
            const funcionariosMap = {};
            funcionarios.forEach(f => {
                funcionariosMap[f.id] = f.nome;
            });
            
            // Criar cabeçalho CSV
            let csv = 'Tipo,Funcionário,Data de Realização,Data de Validade,Resultado,Médico,CRM,Exames Realizados,Observações\n';
            
            // Adicionar linhas
            exames.forEach(exame => {
                const dataRealizacao = exame.dataRealizacao ? new Date(exame.dataRealizacao).toLocaleDateString('pt-BR') : '';
                const dataValidade = exame.dataValidade ? new Date(exame.dataValidade).toLocaleDateString('pt-BR') : '';
                const nomeFuncionario = funcionariosMap[exame.funcionarioId] || 'Não informado';
                const examesRealizados = exame.examesRealizados && exame.examesRealizados.length > 0 
                    ? exame.examesRealizados.join('; ') 
                    : '';
                
                // Escapar campos com vírgula
                const escapar = (campo) => {
                    if (!campo) return '';
                    if (campo.includes(',') || campo.includes('"') || campo.includes('\n')) {
                        return `"${campo.replace(/"/g, '""')}"`;
                    }
                    return campo;
                };
                
                csv += `${escapar(exame.tipo)},${escapar(nomeFuncionario)},${dataRealizacao},${dataValidade},${escapar(exame.resultado)},${escapar(exame.medico)},${escapar(exame.crm)},${escapar(examesRealizados)},${escapar(exame.observacoes)}\n`;
            });
            
            // Criar blob e link para download
            const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
            const link = document.createElement('a');
            const url = URL.createObjectURL(blob);
            
            link.setAttribute('href', url);
            link.setAttribute('download', 'exames.csv');
            link.style.visibility = 'hidden';
            
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            
            this.exibirNotificacao('Dados exportados com sucesso', 'success');
        }).catch(error => {
            console.error('Erro ao exportar dados:', error);
            this.exibirNotificacao('Erro ao exportar dados', 'error');
        });
    },
    
    /**
     * Exibe uma notificação para o usuário
     * @param {string} mensagem - Mensagem a ser exibida
     * @param {string} tipo - Tipo de notificação (success, error, warning, info)
     */
    exibirNotificacao: function(mensagem, tipo) {
        // Verificar se o container de notificações existe
        let container = document.getElementById('notification-container');
        if (!container) {
            container = document.createElement('div');
            container.id = 'notification-container';
            document.body.appendChild(container);
        }
        
        // Criar notificação
        const notification = document.createElement('div');
        notification.className = `alert-notification alert-${tipo} show`;
        notification.innerHTML = `<p>${mensagem}</p><button class="alert-close-btn">&times;</button>`;
        
        // Adicionar ao container
        container.appendChild(notification);
        
        // Adicionar evento para fechar notificação
        notification.querySelector('.alert-close-btn').addEventListener('click', () => {
            notification.classList.replace('show', 'hide');
            setTimeout(() => {
                if (notification.parentNode) {
                    notification.parentNode.removeChild(notification);
                }
            }, 500);
        });
        
        // Auto-fechar após 5 segundos
        setTimeout(() => {
            if (notification.classList.contains('show')) {
                notification.classList.replace('show', 'hide');
                setTimeout(() => {
                    if (notification.parentNode) {
                        notification.parentNode.removeChild(notification);
                    }
                }, 500);
            }
        }, 5000);
    }
};

// Inicializar módulo quando o DOM estiver carregado
document.addEventListener('DOMContentLoaded', function() {
    // Verificar se estamos na página de exames
    if (document.querySelector('.exame-container')) {
        EXAME.init();
    }
});
