/**
 * ZENVIX SGI - Módulo de Administração
 * 
 * Este arquivo contém funções para gerenciar a área administrativa exclusiva
 * para usuários com permissão superior (admin/master).
 */

// Namespace para evitar conflitos
const ADMIN = {
    // Configurações
    config: {
        permissoesNiveis: [
            { id: 1, nome: "Usuário Comum", descricao: "Acesso básico de visualização" },
            { id: 2, nome: "Técnico", descricao: "Acesso para edição de dados operacionais" },
            { id: 3, nome: "Administrador", descricao: "Acesso total ao sistema" }
        ],
        modulosPermissoes: [
            { id: "dashboard", nome: "Dashboard", nivelMinimo: 1 },
            { id: "esocial", nome: "e-Social", nivelMinimo: 2 },
            { id: "cipa", nome: "CIPA", nivelMinimo: 2 },
            { id: "auditoria", nome: "Auditoria", nivelMinimo: 2 },
            { id: "epis", nome: "Gestão de EPIs", nivelMinimo: 2 },
            { id: "treinamentos", nome: "Treinamentos", nivelMinimo: 2 },
            { id: "exames", nome: "Exames Ocupacionais", nivelMinimo: 2 },
            { id: "riscos", nome: "Mapa de Riscos", nivelMinimo: 2 },
            { id: "acidentes", nome: "Acidentes/Incidentes", nivelMinimo: 2 },
            { id: "brigada", nome: "Brigada de Incêndio", nivelMinimo: 2 },
            { id: "admin", nome: "Administração", nivelMinimo: 3 }
        ]
    },
    
    // Estado
    state: {
        secaoAtual: "usuarios", // usuarios, permissoes, configuracoes, logs
        editandoUsuarioId: null,
        editandoSetorId: null,
        editandoFuncionarioId: null
    },
    
    /**
     * Inicializa o módulo de Administração
     */
    init: function() {
        console.log("Inicializando módulo de Administração...");
        
        // Verificar se usuário está autenticado e tem permissão de administrador
        if (!STORAGE.isAuthenticated()) {
            console.warn("Usuário não autenticado. Redirecionando para login...");
            window.location.href = "login.html";
            return;
        }
        
        const usuarioAtual = STORAGE.getUsuarioAtual();
        if (!usuarioAtual || usuarioAtual.nivel < 3) {
            console.warn("Usuário sem permissão de administrador. Redirecionando para dashboard...");
            window.location.href = "dashboard.html";
            return;
        }
        
        this.initComponents();
        this.setupEvents();
        this.carregarSecao(this.state.secaoAtual);
        
        console.log("Módulo de Administração inicializado.");
    },
    
    /**
     * Inicializa componentes da interface
     */
    initComponents: function() {
        // Preencher selects de níveis de permissão
        const selects = document.querySelectorAll(".select-nivel-permissao");
        selects.forEach(select => {
            select.innerHTML = "";
            this.config.permissoesNiveis.forEach(nivel => {
                const option = document.createElement("option");
                option.value = nivel.id;
                option.textContent = nivel.nome;
                select.appendChild(option);
            });
        });
    },
    
    /**
     * Configura eventos da interface
     */
    setupEvents: function() {
        // Navegação entre seções
        document.querySelectorAll(".admin-nav-link").forEach(link => {
            link.addEventListener("click", (e) => {
                e.preventDefault();
                const secao = e.currentTarget.getAttribute("data-secao");
                this.carregarSecao(secao);
            });
        });
        
        // Botões "Novo"
        document.getElementById("btnNovoUsuario")?.addEventListener("click", () => this.mostrarFormulario("formUsuario"));
        document.getElementById("btnNovoSetor")?.addEventListener("click", () => this.mostrarFormulario("formSetor"));
        document.getElementById("btnNovoFuncionario")?.addEventListener("click", () => this.mostrarFormulario("formFuncionario"));
        
        // Botões "Cancelar" dos formulários
        document.querySelectorAll(".btn-cancelar").forEach(button => {
            button.addEventListener("click", (e) => {
                const formId = e.target.closest("form").id;
                this.ocultarFormulario(formId);
            });
        });
        
        // Submissão dos formulários
        document.getElementById("formUsuario")?.addEventListener("submit", (e) => { 
            e.preventDefault(); 
            this.salvarUsuario(); 
        });
        document.getElementById("formSetor")?.addEventListener("submit", (e) => { 
            e.preventDefault(); 
            this.salvarSetor(); 
        });
        document.getElementById("formFuncionario")?.addEventListener("submit", (e) => { 
            e.preventDefault(); 
            this.salvarFuncionario(); 
        });
        document.getElementById("formConfiguracoes")?.addEventListener("submit", (e) => { 
            e.preventDefault(); 
            this.salvarConfiguracoes(); 
        });
        
        // Botão para limpar logs
        document.getElementById("btnLimparLogs")?.addEventListener("click", () => {
            if (confirm("Tem certeza que deseja limpar todos os logs? Esta ação não pode ser desfeita.")) {
                this.limparLogs();
            }
        });
        
        // Botão para exportar logs
        document.getElementById("btnExportarLogs")?.addEventListener("click", () => {
            this.exportarLogs();
        });
        
        // Botão para backup do sistema
        document.getElementById("btnBackupSistema")?.addEventListener("click", () => {
            this.backupSistema();
        });
        
        // Botão para restaurar backup
        document.getElementById("btnRestaurarBackup")?.addEventListener("click", () => {
            this.restaurarBackup();
        });
    },
    
    /**
     * Carrega uma seção específica da área administrativa
     * @param {string} secao - Nome da seção a ser carregada
     */
    carregarSecao: function(secao) {
        console.log(`Carregando seção: ${secao}`);
        this.state.secaoAtual = secao;
        
        // Atualizar navegação
        document.querySelectorAll(".admin-nav-link").forEach(link => {
            link.classList.toggle("active", link.getAttribute("data-secao") === secao);
        });
        
        // Mostrar/ocultar seções
        document.querySelectorAll(".admin-section").forEach(section => {
            section.style.display = section.id === `secao${secao.charAt(0).toUpperCase() + secao.slice(1)}` ? "block" : "none";
        });
        
        // Carregar dados específicos da seção
        switch (secao) {
            case "usuarios":
                this.carregarUsuarios();
                break;
            case "permissoes":
                this.carregarPermissoes();
                break;
            case "configuracoes":
                this.carregarConfiguracoes();
                break;
            case "logs":
                this.carregarLogs();
                break;
            case "empresa":
                this.carregarDadosEmpresa();
                break;
        }
    },
    
    // --- Funções de Carregamento de Dados --- //
    
    /**
     * Carrega lista de usuários
     */
    carregarUsuarios: function() {
        STORAGE.getAll("usuarios").then(usuarios => {
            this.exibirUsuarios(usuarios);
        }).catch(err => {
            console.error("Erro ao carregar usuários:", err);
            this.exibirNotificacao("Erro ao carregar lista de usuários.", "error");
        });
    },
    
    /**
     * Carrega configurações de permissões
     */
    carregarPermissoes: function() {
        // Exibir tabela de permissões por módulo
        const tbody = document.getElementById("tabelaPermissoes")?.querySelector("tbody");
        if (!tbody) return;
        
        tbody.innerHTML = "";
        this.config.modulosPermissoes.forEach(modulo => {
            const tr = document.createElement("tr");
            tr.innerHTML = `
                <td>${modulo.nome}</td>
                <td>
                    <select class="form-control select-permissao" data-modulo="${modulo.id}">
                        ${this.config.permissoesNiveis.map(nivel => 
                            `<option value="${nivel.id}" ${nivel.id === modulo.nivelMinimo ? 'selected' : ''}>${nivel.nome}</option>`
                        ).join('')}
                    </select>
                </td>
            `;
            tbody.appendChild(tr);
        });
        
        // Adicionar evento para salvar alterações de permissões
        tbody.querySelectorAll(".select-permissao").forEach(select => {
            select.addEventListener("change", (e) => {
                const moduloId = e.target.getAttribute("data-modulo");
                const nivelMinimo = parseInt(e.target.value);
                this.salvarPermissaoModulo(moduloId, nivelMinimo);
            });
        });
    },
    
    /**
     * Carrega configurações do sistema
     */
    carregarConfiguracoes: function() {
        STORAGE.getConfig().then(config => {
            // Preencher formulário de configurações
            const form = document.getElementById("formConfiguracoes");
            if (!form) return;
            
            // Configurações gerais
            form.elements["nomeEmpresa"].value = config.nomeEmpresa || "";
            form.elements["cnpjEmpresa"].value = config.cnpjEmpresa || "";
            form.elements["logoEmpresa"].value = config.logoEmpresa || "";
            
            // Configurações de e-Social
            form.elements["ambienteEsocial"].value = config.ambienteEsocial || "2";
            form.elements["certificadoDigital"].value = config.certificadoDigital || "";
            
            // Configurações de notificações
            form.elements["notificacoesVencimentos"].checked = config.notificacoesVencimentos !== false;
            form.elements["diasAntecedenciaNotificacao"].value = config.diasAntecedenciaNotificacao || 30;
            
            // Configurações de backup
            form.elements["backupAutomatico"].checked = config.backupAutomatico !== false;
            form.elements["intervaloBackup"].value = config.intervaloBackup || 7;
            
        }).catch(err => {
            console.error("Erro ao carregar configurações:", err);
            this.exibirNotificacao("Erro ao carregar configurações do sistema.", "error");
        });
    },
    
    /**
     * Carrega logs do sistema
     */
    carregarLogs: function() {
        STORAGE.getAll("logs").then(logs => {
            this.exibirLogs(logs);
        }).catch(err => {
            console.error("Erro ao carregar logs:", err);
            this.exibirNotificacao("Erro ao carregar logs do sistema.", "error");
        });
    },
    
    /**
     * Carrega dados da empresa e setores
     */
    carregarDadosEmpresa: function() {
        Promise.all([
            STORAGE.getAll("setores"),
            STORAGE.getAll("funcionarios")
        ]).then(([setores, funcionarios]) => {
            this.exibirSetores(setores);
            this.exibirFuncionarios(funcionarios);
        }).catch(err => {
            console.error("Erro ao carregar dados da empresa:", err);
            this.exibirNotificacao("Erro ao carregar dados da empresa.", "error");
        });
    },
    
    // --- Funções de Exibição --- //
    
    /**
     * Exibe lista de usuários
     * @param {Array} usuarios - Lista de usuários
     */
    exibirUsuarios: function(usuarios) {
        const tbody = document.getElementById("tabelaUsuarios")?.querySelector("tbody");
        if (!tbody) return;
        
        tbody.innerHTML = "";
        
        if (usuarios.length === 0) {
            tbody.innerHTML = '<tr><td colspan="5" class="text-center">Nenhum usuário cadastrado.</td></tr>';
            return;
        }
        
        usuarios.forEach(usuario => {
            const tr = document.createElement("tr");
            const nivelPermissao = this.config.permissoesNiveis.find(n => n.id === usuario.nivel)?.nome || "Desconhecido";
            const ultimoAcesso = usuario.ultimoAcesso ? new Date(usuario.ultimoAcesso).toLocaleString("pt-BR") : "Nunca";
            
            tr.innerHTML = `
                <td>${usuario.username}</td>
                <td>${usuario.nome || "-"}</td>
                <td>${nivelPermissao}</td>
                <td>${ultimoAcesso}</td>
                <td>
                    <button class="btn-sm edit-btn" data-id="${usuario.id}" data-type="usuario"><i class="fas fa-edit"></i></button>
                    <button class="btn-sm delete-btn" data-id="${usuario.id}" data-type="usuario"><i class="fas fa-trash"></i></button>
                    <button class="btn-sm reset-pwd-btn" data-id="${usuario.id}" title="Resetar senha"><i class="fas fa-key"></i></button>
                </td>
            `;
            tbody.appendChild(tr);
        });
        
        // Adicionar eventos aos botões
        tbody.querySelectorAll(".edit-btn").forEach(btn => {
            btn.addEventListener("click", (e) => {
                const id = parseInt(e.currentTarget.getAttribute("data-id"));
                this.editarUsuario(id);
            });
        });
        tbody.querySelectorAll(".delete-btn").forEach(btn => {
            btn.addEventListener("click", (e) => {
                const id = parseInt(e.currentTarget.getAttribute("data-id"));
                this.excluirUsuario(id);
            });
        });
        tbody.querySelectorAll(".reset-pwd-btn").forEach(btn => {
            btn.addEventListener("click", (e) => {
                const id = parseInt(e.currentTarget.getAttribute("data-id"));
                this.resetarSenhaUsuario(id);
            });
        });
    },
    
    /**
     * Exibe logs do sistema
     * @param {Array} logs - Lista de logs
     */
    exibirLogs: function(logs) {
        const tbody = document.getElementById("tabelaLogs")?.querySelector("tbody");
        if (!tbody) return;
        
        tbody.innerHTML = "";
        
        if (logs.length === 0) {
            tbody.innerHTML = '<tr><td colspan="5" class="text-center">Nenhum log registrado.</td></tr>';
            return;
        }
        
        // Ordenar logs por data (mais recentes primeiro)
        logs.sort((a, b) => new Date(b.data) - new Date(a.data));
        
        logs.forEach(log => {
            const tr = document.createElement("tr");
            const data = new Date(log.data).toLocaleString("pt-BR");
            
            tr.innerHTML = `
                <td>${data}</td>
                <td>${log.usuario || "Sistema"}</td>
                <td>${log.tipo}</td>
                <td>${log.acao}</td>
                <td>${log.detalhes || "-"}</td>
            `;
            tbody.appendChild(tr);
        });
    },
    
    /**
     * Exibe setores da empresa
     * @param {Array} setores - Lista de setores
     */
    exibirSetores: function(setores) {
        const tbody = document.getElementById("tabelaSetores")?.querySelector("tbody");
        if (!tbody) return;
        
        tbody.innerHTML = "";
        
        if (setores.length === 0) {
            tbody.innerHTML = '<tr><td colspan="3" class="text-center">Nenhum setor cadastrado.</td></tr>';
            return;
        }
        
        setores.forEach(setor => {
            const tr = document.createElement("tr");
            tr.innerHTML = `
                <td>${setor.nome}</td>
                <td>${setor.descricao || "-"}</td>
                <td>
                    <button class="btn-sm edit-btn" data-id="${setor.id}" data-type="setor"><i class="fas fa-edit"></i></button>
                    <button class="btn-sm delete-btn" data-id="${setor.id}" data-type="setor"><i class="fas fa-trash"></i></button>
                </td>
            `;
            tbody.appendChild(tr);
        });
        
        // Adicionar eventos aos botões
        tbody.querySelectorAll(".edit-btn").forEach(btn => {
            btn.addEventListener("click", (e) => {
                const id = parseInt(e.currentTarget.getAttribute("data-id"));
                this.editarSetor(id);
            });
        });
        tbody.querySelectorAll(".delete-btn").forEach(btn => {
            btn.addEventListener("click", (e) => {
                const id = parseInt(e.currentTarget.getAttribute("data-id"));
                this.excluirSetor(id);
            });
        });
    },
    
    /**
     * Exibe funcionários da empresa
     * @param {Array} funcionarios - Lista de funcionários
     */
    exibirFuncionarios: function(funcionarios) {
        const tbody = document.getElementById("tabelaFuncionarios")?.querySelector("tbody");
        if (!tbody) return;
        
        tbody.innerHTML = "";
        
        if (funcionarios.length === 0) {
            tbody.innerHTML = '<tr><td colspan="5" class="text-center">Nenhum funcionário cadastrado.</td></tr>';
            return;
        }
        
        // Carregar setores para exibir nome do setor
        STORAGE.getAll("setores").then(setores => {
            const setoresMap = {};
            setores.forEach(s => setoresMap[s.id] = s.nome);
            
            funcionarios.forEach(funcionario => {
                const tr = document.createElement("tr");
                const nomeSetor = setoresMap[funcionario.setorId] || "Não definido";
                const status = funcionario.ativo ? '<span class="badge badge-success">Ativo</span>' : '<span class="badge badge-secondary">Inativo</span>';
                
                tr.innerHTML = `
                    <td>${funcionario.nome}</td>
                    <td>${funcionario.cargo || "-"}</td>
                    <td>${nomeSetor}</td>
                    <td>${status}</td>
                    <td>
                        <button class="btn-sm edit-btn" data-id="${funcionario.id}" data-type="funcionario"><i class="fas fa-edit"></i></button>
                        <button class="btn-sm delete-btn" data-id="${funcionario.id}" data-type="funcionario"><i class="fas fa-trash"></i></button>
                    </td>
                `;
                tbody.appendChild(tr);
            });
            
            // Adicionar eventos aos botões
            tbody.querySelectorAll(".edit-btn").forEach(btn => {
                btn.addEventListener("click", (e) => {
                    const id = parseInt(e.currentTarget.getAttribute("data-id"));
                    this.editarFuncionario(id);
                });
            });
            tbody.querySelectorAll(".delete-btn").forEach(btn => {
                btn.addEventListener("click", (e) => {
                    const id = parseInt(e.currentTarget.getAttribute("data-id"));
                    this.excluirFuncionario(id);
                });
            });
            
        }).catch(err => {
            console.error("Erro ao carregar setores para exibir funcionários:", err);
            tbody.innerHTML = '<tr><td colspan="5" class="text-center text-danger">Erro ao carregar dados dos setores.</td></tr>';
        });
    },
    
    // --- Funções de Formulário --- //
    
    /**
     * Mostra formulário para cadastro/edição
     * @param {string} formId - ID do formulário
     * @param {number} id - ID do item a ser editado (opcional)
     */
    mostrarFormulario: function(formId, id = null) {
        const formElement = document.getElementById(formId);
        if (!formElement) return;
        
        const listContainer = formElement.closest(".card").querySelector(".table-responsive, .list-container");
        const formContainer = formElement.closest(".form-container");
        
        this.limparFormulario(formId);
        
        if (id) {
            // Modo Edição
            const tipo = formId.replace("form", "").toLowerCase();
            const storeName = tipo === "usuario" ? "usuarios" : (tipo === "setor" ? "setores" : "funcionarios");
            
            STORAGE.get(storeName, id).then(item => {
                if (!item) {
                    this.exibirNotificacao(`${tipo.charAt(0).toUpperCase() + tipo.slice(1)} não encontrado.`, "error");
                    return;
                }
                
                this.preencherFormulario(formId, item);
                formElement.setAttribute("data-id", id);
                formContainer.querySelector(".form-title").textContent = `Editar ${tipo.charAt(0).toUpperCase() + tipo.slice(1)}`;
                
                if (listContainer) listContainer.style.display = "none";
                formContainer.style.display = "block";
                
            }).catch(err => {
                console.error(`Erro ao carregar ${tipo} para edição:`, err);
                this.exibirNotificacao(`Erro ao carregar ${tipo} para edição.`, "error");
            });
        } else {
            // Modo Novo
            const tipo = formId.replace("form", "").toLowerCase();
            formContainer.querySelector(".form-title").textContent = `Novo ${tipo.charAt(0).toUpperCase() + tipo.slice(1)}`;
            
            // Caso especial para formulário de usuário
            if (formId === "formUsuario") {
                const senhaGroup = formElement.querySelector(".senha-group");
                if (senhaGroup) senhaGroup.style.display = "block";
            }
            
            if (listContainer) listContainer.style.display = "none";
            formContainer.style.display = "block";
        }
    },
    
    /**
     * Oculta formulário e volta para listagem
     * @param {string} formId - ID do formulário
     */
    ocultarFormulario: function(formId) {
        const formElement = document.getElementById(formId);
        if (!formElement) return;
        
        const listContainer = formElement.closest(".card").querySelector(".table-responsive, .list-container");
        const formContainer = formElement.closest(".form-container");
        
        formContainer.style.display = "none";
        if (listContainer) listContainer.style.display = "block";
        this.limparFormulario(formId);
    },
    
    /**
     * Limpa formulário
     * @param {string} formId - ID do formulário
     */
    limparFormulario: function(formId) {
        const form = document.getElementById(formId);
        if (form) {
            form.reset();
            form.removeAttribute("data-id");
            
            // Caso especial para formulário de usuário
            if (formId === "formUsuario") {
                const senhaGroup = form.querySelector(".senha-group");
                if (senhaGroup) senhaGroup.style.display = "block";
            }
        }
    },
    
    /**
     * Preenche formulário com dados existentes
     * @param {string} formId - ID do formulário
     * @param {object} data - Dados para preencher o formulário
     */
    preencherFormulario: function(formId, data) {
        const form = document.getElementById(formId);
        if (!form) return;
        
        for (const key in data) {
            const input = form.elements[key];
            if (input) {
                if (input.type === "checkbox") {
                    input.checked = data[key];
                } else {
                    input.value = data[key];
                }
            }
        }
        
        // Caso especial para formulário de usuário
        if (formId === "formUsuario") {
            const senhaGroup = form.querySelector(".senha-group");
            if (senhaGroup) senhaGroup.style.display = "none"; // Ocultar campo de senha na edição
        }
        
        // Caso especial para formulário de funcionário
        if (formId === "formFuncionario") {
            // Carregar setores para o select
            STORAGE.getAll("setores").then(setores => {
                const setorSelect = form.elements["setorId"];
                if (setorSelect) {
                    setorSelect.innerHTML = '<option value="">Selecione...</option>';
                    setores.forEach(setor => {
                        const option = document.createElement("option");
                        option.value = setor.id;
                        option.textContent = setor.nome;
                        option.selected = setor.id === data.setorId;
                        setorSelect.appendChild(option);
                    });
                }
            }).catch(err => console.error("Erro ao carregar setores para formulário:", err));
        }
    },
    
    // --- Funções de Salvamento --- //
    
    /**
     * Salva usuário (novo ou edição)
     */
    salvarUsuario: function() {
        const form = document.getElementById("formUsuario");
        const id = form.getAttribute("data-id");
        
        const username = form.elements["username"].value.trim();
        const nome = form.elements["nome"].value.trim();
        const email = form.elements["email"].value.trim();
        const nivel = parseInt(form.elements["nivel"].value);
        const senha = form.elements["senha"]?.value;
        
        if (!username || !nome || !email || isNaN(nivel)) {
            this.exibirNotificacao("Preencha todos os campos obrigatórios.", "error");
            return;
        }
        
        // Verificar se username já existe (para novos usuários)
        const verificarUsername = id ? Promise.resolve(false) : STORAGE.getAll("usuarios").then(usuarios => {
            return usuarios.some(u => u.username === username);
        });
        
        verificarUsername.then(usernameExiste => {
            if (usernameExiste) {
                this.exibirNotificacao("Nome de usuário já existe. Escolha outro.", "error");
                return;
            }
            
            const usuario = {
                username: username,
                nome: nome,
                email: email,
                nivel: nivel
            };
            
            // Adicionar senha apenas para novos usuários ou se foi preenchida
            if (!id && senha) {
                usuario.senha = this.hashSenha(senha);
            } else if (id && senha) {
                usuario.senha = this.hashSenha(senha);
            }
            
            const storeName = "usuarios";
            const promise = id 
                ? STORAGE.update(storeName, { ...usuario, id: parseInt(id) }) 
                : STORAGE.add(storeName, { ...usuario, dataCadastro: new Date().toISOString() });
                
            promise.then(() => {
                this.exibirNotificacao(`Usuário ${id ? "atualizado" : "cadastrado"} com sucesso!`, "success");
                this.registrarLog("usuarios", id ? "edição" : "criação", `Usuário ${username} ${id ? "atualizado" : "cadastrado"}`);
                this.ocultarFormulario("formUsuario");
                this.carregarUsuarios();
            }).catch(err => {
                console.error("Erro ao salvar usuário:", err);
                this.exibirNotificacao("Erro ao salvar usuário.", "error");
            });
        }).catch(err => {
            console.error("Erro ao verificar username:", err);
            this.exibirNotificacao("Erro ao verificar disponibilidade do nome de usuário.", "error");
        });
    },
    
    /**
     * Salva setor (novo ou edição)
     */
    salvarSetor: function() {
        const form = document.getElementById("formSetor");
        const id = form.getAttribute("data-id");
        
        const nome = form.elements["nome"].value.trim();
        const descricao = form.elements["descricao"].value.trim();
        
        if (!nome) {
            this.exibirNotificacao("Nome do setor é obrigatório.", "error");
            return;
        }
        
        const setor = {
            nome: nome,
            descricao: descricao
        };
        
        const storeName = "setores";
        const promise = id 
            ? STORAGE.update(storeName, { ...setor, id: parseInt(id) }) 
            : STORAGE.add(storeName, { ...setor, dataCadastro: new Date().toISOString() });
            
        promise.then(() => {
            this.exibirNotificacao(`Setor ${id ? "atualizado" : "cadastrado"} com sucesso!`, "success");
            this.registrarLog("setores", id ? "edição" : "criação", `Setor ${nome} ${id ? "atualizado" : "cadastrado"}`);
            this.ocultarFormulario("formSetor");
            this.carregarDadosEmpresa();
        }).catch(err => {
            console.error("Erro ao salvar setor:", err);
            this.exibirNotificacao("Erro ao salvar setor.", "error");
        });
    },
    
    /**
     * Salva funcionário (novo ou edição)
     */
    salvarFuncionario: function() {
        const form = document.getElementById("formFuncionario");
        const id = form.getAttribute("data-id");
        
        const nome = form.elements["nome"].value.trim();
        const cargo = form.elements["cargo"].value.trim();
        const setorId = parseInt(form.elements["setorId"].value);
        const matricula = form.elements["matricula"].value.trim();
        const dataAdmissao = form.elements["dataAdmissao"].value;
        const ativo = form.elements["ativo"].checked;
        
        if (!nome || isNaN(setorId)) {
            this.exibirNotificacao("Nome e Setor são obrigatórios.", "error");
            return;
        }
        
        const funcionario = {
            nome: nome,
            cargo: cargo,
            setorId: setorId,
            matricula: matricula,
            dataAdmissao: dataAdmissao || null,
            ativo: ativo
        };
        
        const storeName = "funcionarios";
        const promise = id 
            ? STORAGE.update(storeName, { ...funcionario, id: parseInt(id) }) 
            : STORAGE.add(storeName, { ...funcionario, dataCadastro: new Date().toISOString() });
            
        promise.then(() => {
            this.exibirNotificacao(`Funcionário ${id ? "atualizado" : "cadastrado"} com sucesso!`, "success");
            this.registrarLog("funcionarios", id ? "edição" : "criação", `Funcionário ${nome} ${id ? "atualizado" : "cadastrado"}`);
            this.ocultarFormulario("formFuncionario");
            this.carregarDadosEmpresa();
        }).catch(err => {
            console.error("Erro ao salvar funcionário:", err);
            this.exibirNotificacao("Erro ao salvar funcionário.", "error");
        });
    },
    
    /**
     * Salva configurações do sistema
     */
    salvarConfiguracoes: function() {
        const form = document.getElementById("formConfiguracoes");
        if (!form) return;
        
        const config = {
            // Configurações gerais
            nomeEmpresa: form.elements["nomeEmpresa"].value.trim(),
            cnpjEmpresa: form.elements["cnpjEmpresa"].value.trim(),
            logoEmpresa: form.elements["logoEmpresa"].value.trim(),
            
            // Configurações de e-Social
            ambienteEsocial: form.elements["ambienteEsocial"].value,
            certificadoDigital: form.elements["certificadoDigital"].value.trim(),
            
            // Configurações de notificações
            notificacoesVencimentos: form.elements["notificacoesVencimentos"].checked,
            diasAntecedenciaNotificacao: parseInt(form.elements["diasAntecedenciaNotificacao"].value) || 30,
            
            // Configurações de backup
            backupAutomatico: form.elements["backupAutomatico"].checked,
            intervaloBackup: parseInt(form.elements["intervaloBackup"].value) || 7
        };
        
        STORAGE.setConfig(config).then(() => {
            this.exibirNotificacao("Configurações salvas com sucesso!", "success");
            this.registrarLog("configuracoes", "atualização", "Configurações do sistema atualizadas");
        }).catch(err => {
            console.error("Erro ao salvar configurações:", err);
            this.exibirNotificacao("Erro ao salvar configurações.", "error");
        });
    },
    
    /**
     * Salva permissão de módulo
     * @param {string} moduloId - ID do módulo
     * @param {number} nivelMinimo - Nível mínimo de permissão
     */
    salvarPermissaoModulo: function(moduloId, nivelMinimo) {
        // Atualizar configuração local
        const modulo = this.config.modulosPermissoes.find(m => m.id === moduloId);
        if (modulo) {
            modulo.nivelMinimo = nivelMinimo;
            
            // Registrar alteração
            this.registrarLog("permissoes", "atualização", `Permissão do módulo ${modulo.nome} alterada para nível ${nivelMinimo}`);
            this.exibirNotificacao(`Permissão do módulo ${modulo.nome} atualizada.`, "success");
            
            // Em um sistema real, salvaria em banco de dados
            // Aqui apenas simulamos o salvamento
            console.log(`Permissão do módulo ${moduloId} atualizada para nível ${nivelMinimo}`);
        }
    },
    
    // --- Funções de Ação --- //
    
    /**
     * Edita usuário existente
     * @param {number} id - ID do usuário
     */
    editarUsuario: function(id) {
        this.mostrarFormulario("formUsuario", id);
    },
    
    /**
     * Exclui usuário
     * @param {number} id - ID do usuário
     */
    excluirUsuario: function(id) {
        if (!confirm("Tem certeza que deseja excluir este usuário?")) {
            return;
        }
        
        STORAGE.get("usuarios", id).then(usuario => {
            if (!usuario) {
                this.exibirNotificacao("Usuário não encontrado.", "error");
                return;
            }
            
            // Não permitir excluir o próprio usuário
            const usuarioAtual = STORAGE.getUsuarioAtual();
            if (usuarioAtual && usuarioAtual.id === id) {
                this.exibirNotificacao("Não é possível excluir seu próprio usuário.", "error");
                return;
            }
            
            STORAGE.remove("usuarios", id).then(() => {
                this.exibirNotificacao("Usuário excluído com sucesso!", "success");
                this.registrarLog("usuarios", "exclusão", `Usuário ${usuario.username} excluído`);
                this.carregarUsuarios();
            }).catch(err => {
                console.error("Erro ao excluir usuário:", err);
                this.exibirNotificacao("Erro ao excluir usuário.", "error");
            });
        }).catch(err => {
            console.error("Erro ao buscar usuário para exclusão:", err);
            this.exibirNotificacao("Erro ao buscar usuário para exclusão.", "error");
        });
    },
    
    /**
     * Reseta senha de usuário
     * @param {number} id - ID do usuário
     */
    resetarSenhaUsuario: function(id) {
        STORAGE.get("usuarios", id).then(usuario => {
            if (!usuario) {
                this.exibirNotificacao("Usuário não encontrado.", "error");
                return;
            }
            
            const novaSenha = this.gerarSenhaAleatoria();
            usuario.senha = this.hashSenha(novaSenha);
            
            STORAGE.update("usuarios", usuario).then(() => {
                this.exibirNotificacao(`Senha resetada com sucesso! Nova senha: ${novaSenha}`, "success");
                this.registrarLog("usuarios", "reset_senha", `Senha do usuário ${usuario.username} resetada`);
            }).catch(err => {
                console.error("Erro ao resetar senha:", err);
                this.exibirNotificacao("Erro ao resetar senha.", "error");
            });
        }).catch(err => {
            console.error("Erro ao buscar usuário para reset de senha:", err);
            this.exibirNotificacao("Erro ao buscar usuário para reset de senha.", "error");
        });
    },
    
    /**
     * Edita setor existente
     * @param {number} id - ID do setor
     */
    editarSetor: function(id) {
        this.mostrarFormulario("formSetor", id);
    },
    
    /**
     * Exclui setor
     * @param {number} id - ID do setor
     */
    excluirSetor: function(id) {
        if (!confirm("Tem certeza que deseja excluir este setor? Isso pode afetar funcionários vinculados.")) {
            return;
        }
        
        // Verificar se há funcionários vinculados
        STORAGE.getAll("funcionarios").then(funcionarios => {
            const funcionariosVinculados = funcionarios.filter(f => f.setorId === id);
            
            if (funcionariosVinculados.length > 0) {
                if (!confirm(`Existem ${funcionariosVinculados.length} funcionários vinculados a este setor. Deseja continuar?`)) {
                    return;
                }
            }
            
            STORAGE.get("setores", id).then(setor => {
                if (!setor) {
                    this.exibirNotificacao("Setor não encontrado.", "error");
                    return;
                }
                
                STORAGE.remove("setores", id).then(() => {
                    this.exibirNotificacao("Setor excluído com sucesso!", "success");
                    this.registrarLog("setores", "exclusão", `Setor ${setor.nome} excluído`);
                    this.carregarDadosEmpresa();
                }).catch(err => {
                    console.error("Erro ao excluir setor:", err);
                    this.exibirNotificacao("Erro ao excluir setor.", "error");
                });
            }).catch(err => {
                console.error("Erro ao buscar setor para exclusão:", err);
                this.exibirNotificacao("Erro ao buscar setor para exclusão.", "error");
            });
        }).catch(err => {
            console.error("Erro ao verificar funcionários vinculados:", err);
            this.exibirNotificacao("Erro ao verificar funcionários vinculados ao setor.", "error");
        });
    },
    
    /**
     * Edita funcionário existente
     * @param {number} id - ID do funcionário
     */
    editarFuncionario: function(id) {
        this.mostrarFormulario("formFuncionario", id);
    },
    
    /**
     * Exclui funcionário
     * @param {number} id - ID do funcionário
     */
    excluirFuncionario: function(id) {
        if (!confirm("Tem certeza que deseja excluir este funcionário? Isso pode afetar registros vinculados.")) {
            return;
        }
        
        STORAGE.get("funcionarios", id).then(funcionario => {
            if (!funcionario) {
                this.exibirNotificacao("Funcionário não encontrado.", "error");
                return;
            }
            
            STORAGE.remove("funcionarios", id).then(() => {
                this.exibirNotificacao("Funcionário excluído com sucesso!", "success");
                this.registrarLog("funcionarios", "exclusão", `Funcionário ${funcionario.nome} excluído`);
                this.carregarDadosEmpresa();
            }).catch(err => {
                console.error("Erro ao excluir funcionário:", err);
                this.exibirNotificacao("Erro ao excluir funcionário.", "error");
            });
        }).catch(err => {
            console.error("Erro ao buscar funcionário para exclusão:", err);
            this.exibirNotificacao("Erro ao buscar funcionário para exclusão.", "error");
        });
    },
    
    /**
     * Limpa logs do sistema
     */
    limparLogs: function() {
        STORAGE.clearStore("logs").then(() => {
            this.exibirNotificacao("Logs limpos com sucesso!", "success");
            this.registrarLog("logs", "limpeza", "Logs do sistema foram limpos");
            this.carregarLogs();
        }).catch(err => {
            console.error("Erro ao limpar logs:", err);
            this.exibirNotificacao("Erro ao limpar logs.", "error");
        });
    },
    
    /**
     * Exporta logs para CSV
     */
    exportarLogs: function() {
        STORAGE.getAll("logs").then(logs => {
            if (logs.length === 0) {
                this.exibirNotificacao("Não há logs para exportar.", "warning");
                return;
            }
            
            let csv = "Data,Usuário,Tipo,Ação,Detalhes\n";
            
            logs.forEach(log => {
                const data = new Date(log.data).toLocaleString("pt-BR");
                const usuario = log.usuario || "Sistema";
                const tipo = log.tipo || "";
                const acao = log.acao || "";
                const detalhes = log.detalhes || "";
                
                csv += `"${data}","${usuario}","${tipo}","${acao}","${detalhes}"\n`;
            });
            
            const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
            const link = document.createElement("a");
            const url = URL.createObjectURL(blob);
            
            link.setAttribute("href", url);
            link.setAttribute("download", `logs_sistema_${new Date().toISOString().split("T")[0]}.csv`);
            link.style.visibility = "hidden";
            
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            
            this.exibirNotificacao("Logs exportados com sucesso!", "success");
            this.registrarLog("logs", "exportação", "Logs do sistema foram exportados");
        }).catch(err => {
            console.error("Erro ao exportar logs:", err);
            this.exibirNotificacao("Erro ao exportar logs.", "error");
        });
    },
    
    /**
     * Realiza backup do sistema
     */
    backupSistema: function() {
        this.exibirNotificacao("Iniciando backup do sistema...", "info");
        
        // Coletar dados de todas as stores
        Promise.all([
            STORAGE.getAll("usuarios"),
            STORAGE.getAll("setores"),
            STORAGE.getAll("funcionarios"),
            STORAGE.getAll("logs"),
            STORAGE.getConfig()
        ]).then(([usuarios, setores, funcionarios, logs, config]) => {
            const backup = {
                data: new Date().toISOString(),
                versao: "1.0",
                dados: {
                    usuarios: usuarios,
                    setores: setores,
                    funcionarios: funcionarios,
                    logs: logs,
                    config: config
                }
            };
            
            const json = JSON.stringify(backup);
            const blob = new Blob([json], { type: "application/json" });
            const link = document.createElement("a");
            const url = URL.createObjectURL(blob);
            
            link.setAttribute("href", url);
            link.setAttribute("download", `backup_sistema_${new Date().toISOString().split("T")[0]}.json`);
            link.style.visibility = "hidden";
            
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            
            this.exibirNotificacao("Backup realizado com sucesso!", "success");
            this.registrarLog("sistema", "backup", "Backup do sistema realizado");
        }).catch(err => {
            console.error("Erro ao realizar backup:", err);
            this.exibirNotificacao("Erro ao realizar backup do sistema.", "error");
        });
    },
    
    /**
     * Restaura backup do sistema
     */
    restaurarBackup: function() {
        if (!confirm("Tem certeza que deseja restaurar um backup? Isso substituirá todos os dados atuais.")) {
            return;
        }
        
        const input = document.createElement("input");
        input.type = "file";
        input.accept = "application/json";
        
        input.onchange = (e) => {
            const file = e.target.files[0];
            if (!file) return;
            
            const reader = new FileReader();
            reader.onload = (event) => {
                try {
                    const backup = JSON.parse(event.target.result);
                    
                    // Validar estrutura do backup
                    if (!backup.data || !backup.versao || !backup.dados) {
                        throw new Error("Formato de backup inválido.");
                    }
                    
                    // Confirmar restauração
                    const dataBackup = new Date(backup.data).toLocaleString("pt-BR");
                    if (!confirm(`Backup de ${dataBackup} será restaurado. Continuar?`)) {
                        return;
                    }
                    
                    // Restaurar dados
                    this.exibirNotificacao("Restaurando backup...", "info");
                    
                    // Em um sistema real, faria a restauração completa
                    // Aqui apenas simulamos
                    setTimeout(() => {
                        this.exibirNotificacao("Backup restaurado com sucesso! Recarregue a página para ver as alterações.", "success");
                        this.registrarLog("sistema", "restauração", `Backup de ${dataBackup} restaurado`);
                    }, 1500);
                    
                } catch (error) {
                    console.error("Erro ao processar arquivo de backup:", error);
                    this.exibirNotificacao("Erro ao processar arquivo de backup. Verifique se o formato é válido.", "error");
                }
            };
            reader.readAsText(file);
        };
        
        input.click();
    },
    
    // --- Funções Utilitárias --- //
    
    /**
     * Registra log no sistema
     * @param {string} tipo - Tipo de log
     * @param {string} acao - Ação realizada
     * @param {string} detalhes - Detalhes adicionais
     */
    registrarLog: function(tipo, acao, detalhes) {
        const usuarioAtual = STORAGE.getUsuarioAtual();
        const log = {
            data: new Date().toISOString(),
            usuario: usuarioAtual ? usuarioAtual.username : "Sistema",
            tipo: tipo,
            acao: acao,
            detalhes: detalhes
        };
        
        STORAGE.add("logs", log).catch(err => {
            console.error("Erro ao registrar log:", err);
        });
    },
    
    /**
     * Gera hash simples para senha (simulação)
     * @param {string} senha - Senha em texto plano
     * @returns {string} - Hash da senha
     */
    hashSenha: function(senha) {
        // Em um sistema real, usaria bcrypt ou similar
        // Aqui apenas simulamos um hash simples
        let hash = 0;
        for (let i = 0; i < senha.length; i++) {
            const char = senha.charCodeAt(i);
            hash = ((hash << 5) - hash) + char;
            hash = hash & hash; // Converter para inteiro de 32 bits
        }
        return "hash_" + Math.abs(hash).toString(16);
    },
    
    /**
     * Gera senha aleatória
     * @returns {string} - Senha aleatória
     */
    gerarSenhaAleatoria: function() {
        const caracteres = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        let senha = "";
        for (let i = 0; i < 8; i++) {
            senha += caracteres.charAt(Math.floor(Math.random() * caracteres.length));
        }
        return senha;
    },
    
    /**
     * Exibe notificação para o usuário
     * @param {string} mensagem - Mensagem a ser exibida
     * @param {string} tipo - Tipo de notificação (success, error, warning, info)
     */
    exibirNotificacao: function(mensagem, tipo) {
        if (typeof DASHBOARD !== "undefined" && DASHBOARD.exibirNotificacao) {
            DASHBOARD.exibirNotificacao(mensagem, tipo);
        } else {
            alert(`[${tipo.toUpperCase()}] ${mensagem}`);
        }
    }
};

// Inicializar módulo
document.addEventListener("DOMContentLoaded", () => {
    if (document.querySelector(".admin-container")) {
        ADMIN.init();
    }
});
