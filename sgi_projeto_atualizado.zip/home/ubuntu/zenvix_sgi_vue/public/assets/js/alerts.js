// js/alerts.js - Sistema de alertas e notificações

/**
 * Módulo de serviço para gerenciar alertas e notificações
 * Fornece métodos para exibir mensagens de alerta, confirmações e modais
 */
const AlertService = {
    // Configurações padrão
    config: {
        displayTime: 5000, // Tempo de exibição em ms
        position: 'bottom-right', // Posição na tela
        animationDuration: 300, // Duração da animação em ms
        maxNotifications: 5, // Número máximo de notificações simultâneas
    },

    // Container de notificações
    container: null,

    /**
     * Inicializa o serviço de alertas
     */
    init() {
        // Verifica se o container já existe
        this.container = document.getElementById('notification-container');
        
        if (!this.container) {
            // Cria o container se não existir
            this.container = document.createElement('div');
            this.container.id = 'notification-container';
            document.body.appendChild(this.container);
        }
        
        // Carrega notificações do sistema
        this.carregarNotificacoesSistema();
    },

    /**
     * Exibe um alerta na tela
     * @param {string} message - Mensagem a ser exibida
     * @param {string} type - Tipo de alerta: 'success', 'error', 'warning', 'info'
     * @param {number} duration - Duração em ms (opcional)
     */
    showAlert(message, type = 'info', duration = this.config.displayTime) {
        // Inicializa o serviço se ainda não foi inicializado
        if (!this.container) this.init();
        
        // Cria o elemento de notificação
        const notification = document.createElement('div');
        notification.className = `alert-notification alert-${type}`;
        
        // Adiciona o conteúdo
        notification.innerHTML = `
            ${message}
            <button class="alert-close-btn">&times;</button>
        `;
        
        // Adiciona ao container
        this.container.appendChild(notification);
        
        // Limita o número de notificações
        this.limitNotifications();
        
        // Exibe a notificação com animação
        setTimeout(() => {
            notification.classList.add('show');
        }, 10);
        
        // Configura o botão de fechar
        const closeBtn = notification.querySelector('.alert-close-btn');
        closeBtn.addEventListener('click', () => {
            this.closeNotification(notification);
        });
        
        // Configura o fechamento automático
        if (duration > 0) {
            setTimeout(() => {
                this.closeNotification(notification);
            }, duration);
        }
        
        // Retorna a notificação para possível manipulação posterior
        return notification;
    },

    /**
     * Fecha uma notificação com animação
     * @param {HTMLElement} notification - Elemento de notificação
     */
    closeNotification(notification) {
        notification.classList.add('hide');
        notification.classList.remove('show');
        
        setTimeout(() => {
            if (notification.parentNode) {
                notification.parentNode.removeChild(notification);
            }
        }, this.config.animationDuration);
    },

    /**
     * Limita o número de notificações exibidas
     */
    limitNotifications() {
        const notifications = this.container.querySelectorAll('.alert-notification');
        
        if (notifications.length > this.config.maxNotifications) {
            // Remove as notificações mais antigas
            for (let i = 0; i < notifications.length - this.config.maxNotifications; i++) {
                this.container.removeChild(notifications[i]);
            }
        }
    },

    /**
     * Exibe uma caixa de confirmação
     * @param {string} message - Mensagem de confirmação
     * @param {string} title - Título da confirmação (opcional)
     * @returns {boolean} - Resultado da confirmação
     */
    showConfirm(message, title = 'Confirmação') {
        return confirm(message);
    },

    /**
     * Exibe um modal personalizado
     * @param {string} title - Título do modal
     * @param {string} content - Conteúdo HTML do modal
     * @param {Object} options - Opções adicionais
     */
    showModal(title, content, options = {}) {
        // Cria o elemento do modal
        const modalOverlay = document.createElement('div');
        modalOverlay.className = 'modal-overlay';
        
        const modalContainer = document.createElement('div');
        modalContainer.className = 'modal-container';
        
        // Adiciona o conteúdo
        modalContainer.innerHTML = `
            <div class="modal-header">
                <h3>${title}</h3>
                <button class="modal-close-btn">&times;</button>
            </div>
            <div class="modal-body">
                ${content}
            </div>
            <div class="modal-footer">
                <button class="button btn-primary modal-ok-btn">OK</button>
            </div>
        `;
        
        // Adiciona o modal ao DOM
        modalOverlay.appendChild(modalContainer);
        document.body.appendChild(modalOverlay);
        
        // Adiciona a classe para exibir com animação
        setTimeout(() => {
            modalOverlay.classList.add('show');
        }, 10);
        
        // Configura os botões
        const closeBtn = modalContainer.querySelector('.modal-close-btn');
        const okBtn = modalContainer.querySelector('.modal-ok-btn');
        
        const closeModal = () => {
            modalOverlay.classList.remove('show');
            setTimeout(() => {
                document.body.removeChild(modalOverlay);
            }, 300);
        };
        
        closeBtn.addEventListener('click', closeModal);
        okBtn.addEventListener('click', closeModal);
        
        // Fecha o modal ao clicar fora dele
        modalOverlay.addEventListener('click', (e) => {
            if (e.target === modalOverlay) {
                closeModal();
            }
        });
        
        // Adiciona estilo CSS para o modal se ainda não existir
        this.addModalStyles();
    },

    /**
     * Adiciona estilos CSS para o modal
     */
    addModalStyles() {
        // Verifica se os estilos já foram adicionados
        if (document.getElementById('modal-styles')) return;
        
        const style = document.createElement('style');
        style.id = 'modal-styles';
        
        style.textContent = `
            .modal-overlay {
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background-color: rgba(0, 0, 0, 0.5);
                display: flex;
                align-items: center;
                justify-content: center;
                z-index: 9999;
                opacity: 0;
                transition: opacity 0.3s ease;
            }
            
            .modal-overlay.show {
                opacity: 1;
            }
            
            .modal-container {
                background-color: var(--card-bg, #fff);
                border-radius: 8px;
                box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
                width: 90%;
                max-width: 600px;
                max-height: 90vh;
                overflow-y: auto;
                transform: translateY(-20px);
                transition: transform 0.3s ease;
            }
            
            .modal-overlay.show .modal-container {
                transform: translateY(0);
            }
            
            .modal-header {
                padding: 15px 20px;
                border-bottom: 1px solid var(--border-color, #ddd);
                display: flex;
                justify-content: space-between;
                align-items: center;
            }
            
            .modal-header h3 {
                margin: 0;
                font-size: 1.2rem;
                color: var(--primary-color, #0077b6);
            }
            
            .modal-close-btn {
                background: none;
                border: none;
                font-size: 1.5rem;
                cursor: pointer;
                color: var(--text-color, #333);
                padding: 0;
                line-height: 1;
            }
            
            .modal-body {
                padding: 20px;
                overflow-y: auto;
                max-height: 60vh;
            }
            
            .modal-footer {
                padding: 15px 20px;
                border-top: 1px solid var(--border-color, #ddd);
                text-align: right;
            }
        `;
        
        document.head.appendChild(style);
    },

    /**
     * Carrega e exibe notificações do sistema
     */
    carregarNotificacoesSistema() {
        // Obtém notificações não lidas
        const notificacoes = StorageService.getNotificacoes();
        const naoLidas = notificacoes.filter(n => !n.lida);
        
        if (naoLidas.length > 0) {
            // Exibe contador de notificações
            this.atualizarContadorNotificacoes(naoLidas.length);
            
            // Exibe notificações recentes (opcional)
            if (naoLidas.length <= 3) {
                setTimeout(() => {
                    naoLidas.forEach(notif => {
                        const tipo = notif.prioridade === 'alta' ? 'error' : 
                                    notif.prioridade === 'media' ? 'warning' : 'info';
                        
                        this.showAlert(notif.titulo, tipo, 8000);
                    });
                }, 2000);
            }
        }
    },

    /**
     * Atualiza o contador de notificações
     * @param {number} count - Número de notificações
     */
    atualizarContadorNotificacoes(count) {
        // Procura pelo elemento de contador
        let contador = document.getElementById('notificacao-contador');
        
        if (!contador) {
            // Cria o contador se não existir
            contador = document.createElement('span');
            contador.id = 'notificacao-contador';
            contador.className = 'notificacao-contador';
            
            // Adiciona ao botão de notificações ou ao header
            const btnNotificacoes = document.querySelector('.btn-notificacoes');
            if (btnNotificacoes) {
                btnNotificacoes.appendChild(contador);
            } else {
                // Adiciona ao header como fallback
                const header = document.querySelector('.page-header');
                if (header) {
                    header.appendChild(contador);
                }
            }
        }
        
        // Atualiza o contador
        contador.textContent = count;
        contador.style.display = count > 0 ? 'block' : 'none';
        
        // Adiciona estilo CSS para o contador se ainda não existir
        this.addNotificationCounterStyles();
    },

    /**
     * Adiciona estilos CSS para o contador de notificações
     */
    addNotificationCounterStyles() {
        // Verifica se os estilos já foram adicionados
        if (document.getElementById('notification-counter-styles')) return;
        
        const style = document.createElement('style');
        style.id = 'notification-counter-styles';
        
        style.textContent = `
            .notificacao-contador {
                position: absolute;
                top: -5px;
                right: -5px;
                background-color: var(--danger-color, #dc3545);
                color: white;
                border-radius: 50%;
                width: 20px;
                height: 20px;
                display: flex;
                align-items: center;
                justify-content: center;
                font-size: 0.75rem;
                font-weight: bold;
            }
            
            .btn-notificacoes {
                position: relative;
            }
        `;
        
        document.head.appendChild(style);
    }
};

// Inicializa o serviço quando o DOM estiver pronto
document.addEventListener('DOMContentLoaded', () => {
    AlertService.init();
});
