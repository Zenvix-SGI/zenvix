/**
 * ZENVIX SGI - Módulo de Acessibilidade
 * 
 * Este módulo implementa recursos de acessibilidade para o sistema ZENVIX SGI,
 * incluindo navegação por teclado e outras melhorias de acessibilidade.
 */

const ACCESSIBILITY = {
    // Configurações
    config: {
        enableKeyboardNavigation: true,
        enableHighContrast: false,
        enableFontSize: true,
        defaultFontSize: 16 // em pixels
    },
    
    // Estado
    state: {
        currentFocusIndex: -1,
        focusableElements: [],
        highContrastEnabled: false,
        currentFontSize: 16 // em pixels
    },
    
    /**
     * Inicializa o módulo de acessibilidade
     */
    init: function() {
        console.log("Inicializando módulo de acessibilidade...");
        
        // Carregar preferências do usuário
        this.loadUserPreferences();
        
        // Configurar navegação por teclado
        if (this.config.enableKeyboardNavigation) {
            this.setupKeyboardNavigation();
        }
        
        // Configurar controles de acessibilidade
        this.setupAccessibilityControls();
        
        console.log("Módulo de acessibilidade inicializado.");
    },
    
    /**
     * Carrega preferências de acessibilidade do usuário
     */
    loadUserPreferences: function() {
        // Verificar se há preferências salvas
        const savedHighContrast = localStorage.getItem('accessibility_highContrast');
        const savedFontSize = localStorage.getItem('accessibility_fontSize');
        
        // Aplicar preferências salvas
        if (savedHighContrast === 'true') {
            this.toggleHighContrast(true);
        }
        
        if (savedFontSize) {
            this.setFontSize(parseInt(savedFontSize));
        }
    },
    
    /**
     * Configura navegação por teclado
     */
    setupKeyboardNavigation: function() {
        // Atualizar lista de elementos focáveis
        this.updateFocusableElements();
        
        // Adicionar listener para tecla Tab
        document.addEventListener('keydown', (e) => {
            // Tecla Tab para navegação
            if (e.key === 'Tab') {
                this.updateFocusableElements();
            }
            
            // Alt + teclas de atalho
            if (e.altKey) {
                switch (e.key) {
                    case 'h': // Alt+H: Ir para Home/Dashboard
                        e.preventDefault();
                        window.location.href = 'dashboard.html';
                        break;
                    case 'm': // Alt+M: Abrir/fechar menu
                        e.preventDefault();
                        const menuToggle = document.querySelector('.menu-toggle') || document.querySelector('.sidebar-toggle');
                        if (menuToggle) menuToggle.click();
                        break;
                    case 'c': // Alt+C: Alternar contraste
                        e.preventDefault();
                        this.toggleHighContrast();
                        break;
                    case '+': // Alt++: Aumentar fonte
                        e.preventDefault();
                        this.changeFontSize(2);
                        break;
                    case '-': // Alt+-: Diminuir fonte
                        e.preventDefault();
                        this.changeFontSize(-2);
                        break;
                }
            }
            
            // Tecla Escape para fechar modais ou dropdowns
            if (e.key === 'Escape') {
                this.handleEscapeKey();
            }
        });
        
        // Adicionar listener para mudanças no DOM
        const observer = new MutationObserver(() => {
            this.updateFocusableElements();
        });
        
        observer.observe(document.body, {
            childList: true,
            subtree: true
        });
    },
    
    /**
     * Atualiza lista de elementos focáveis na página
     */
    updateFocusableElements: function() {
        this.state.focusableElements = Array.from(document.querySelectorAll(
            'a[href], button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])'
        )).filter(el => {
            // Verificar se o elemento está visível
            const style = window.getComputedStyle(el);
            return style.display !== 'none' && style.visibility !== 'hidden' && el.offsetParent !== null;
        });
    },
    
    /**
     * Configura controles de acessibilidade na interface
     */
    setupAccessibilityControls: function() {
        // Adicionar barra de acessibilidade se não existir
        let accessibilityBar = document.getElementById('accessibilityBar');
        
        if (!accessibilityBar) {
            accessibilityBar = document.createElement('div');
            accessibilityBar.id = 'accessibilityBar';
            accessibilityBar.className = 'accessibility-bar';
            accessibilityBar.innerHTML = `
                <button id="btnHighContrast" title="Alternar alto contraste (Alt+C)">
                    <i class="fas fa-adjust"></i>
                </button>
                <button id="btnDecreaseFontSize" title="Diminuir tamanho da fonte (Alt+-)">
                    <i class="fas fa-font"></i><i class="fas fa-minus"></i>
                </button>
                <button id="btnIncreaseFontSize" title="Aumentar tamanho da fonte (Alt++)">
                    <i class="fas fa-font"></i><i class="fas fa-plus"></i>
                </button>
                <button id="btnAccessibilityHelp" title="Ajuda de acessibilidade">
                    <i class="fas fa-question-circle"></i>
                </button>
            `;
            
            document.body.appendChild(accessibilityBar);
            
            // Adicionar eventos aos botões
            document.getElementById('btnHighContrast').addEventListener('click', () => this.toggleHighContrast());
            document.getElementById('btnDecreaseFontSize').addEventListener('click', () => this.changeFontSize(-2));
            document.getElementById('btnIncreaseFontSize').addEventListener('click', () => this.changeFontSize(2));
            document.getElementById('btnAccessibilityHelp').addEventListener('click', () => this.showAccessibilityHelp());
        }
    },
    
    /**
     * Alterna modo de alto contraste
     * @param {boolean} [force] - Força um estado específico
     */
    toggleHighContrast: function(force) {
        const newState = force !== undefined ? force : !this.state.highContrastEnabled;
        this.state.highContrastEnabled = newState;
        
        if (newState) {
            document.body.classList.add('high-contrast');
        } else {
            document.body.classList.remove('high-contrast');
        }
        
        // Salvar preferência
        localStorage.setItem('accessibility_highContrast', newState);
        
        // Atualizar botão
        const btnHighContrast = document.getElementById('btnHighContrast');
        if (btnHighContrast) {
            btnHighContrast.setAttribute('aria-pressed', newState);
        }
    },
    
    /**
     * Altera o tamanho da fonte
     * @param {number} delta - Alteração no tamanho (positivo para aumentar, negativo para diminuir)
     */
    changeFontSize: function(delta) {
        const newSize = Math.max(12, Math.min(24, this.state.currentFontSize + delta));
        this.setFontSize(newSize);
    },
    
    /**
     * Define o tamanho da fonte
     * @param {number} size - Tamanho da fonte em pixels
     */
    setFontSize: function(size) {
        this.state.currentFontSize = size;
        document.documentElement.style.fontSize = `${size}px`;
        
        // Salvar preferência
        localStorage.setItem('accessibility_fontSize', size);
    },
    
    /**
     * Trata tecla Escape
     */
    handleEscapeKey: function() {
        // Fechar dropdowns abertos
        document.querySelectorAll('.dropdown-menu.show').forEach(dropdown => {
            dropdown.classList.remove('show');
        });
        
        // Fechar modais abertos
        const modalBackdrops = document.querySelectorAll('.modal-backdrop');
        if (modalBackdrops.length > 0) {
            document.querySelectorAll('.modal.show').forEach(modal => {
                modal.classList.remove('show');
                modal.style.display = 'none';
            });
            
            modalBackdrops.forEach(backdrop => {
                backdrop.parentNode.removeChild(backdrop);
            });
            
            document.body.classList.remove('modal-open');
            document.body.style.overflow = '';
            document.body.style.paddingRight = '';
        }
    },
    
    /**
     * Exibe ajuda de acessibilidade
     */
    showAccessibilityHelp: function() {
        // Criar modal de ajuda
        const helpModal = document.createElement('div');
        helpModal.className = 'modal fade show';
        helpModal.style.display = 'block';
        helpModal.setAttribute('tabindex', '-1');
        helpModal.setAttribute('role', 'dialog');
        helpModal.setAttribute('aria-modal', 'true');
        
        helpModal.innerHTML = `
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Ajuda de Acessibilidade</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Fechar">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <h6>Atalhos de Teclado</h6>
                        <ul>
                            <li><strong>Tab</strong>: Navegar entre elementos</li>
                            <li><strong>Enter/Espaço</strong>: Ativar elemento selecionado</li>
                            <li><strong>Alt+H</strong>: Ir para Dashboard</li>
                            <li><strong>Alt+M</strong>: Abrir/fechar menu</li>
                            <li><strong>Alt+C</strong>: Alternar alto contraste</li>
                            <li><strong>Alt++</strong>: Aumentar tamanho da fonte</li>
                            <li><strong>Alt+-</strong>: Diminuir tamanho da fonte</li>
                            <li><strong>Esc</strong>: Fechar janelas/dropdowns</li>
                        </ul>
                        
                        <h6>Recursos de Acessibilidade</h6>
                        <ul>
                            <li><strong>Alto Contraste</strong>: Melhora a legibilidade para pessoas com baixa visão</li>
                            <li><strong>Tamanho da Fonte</strong>: Ajusta o tamanho do texto para melhor leitura</li>
                            <li><strong>Navegação por Teclado</strong>: Permite usar o sistema sem mouse</li>
                        </ul>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Fechar</button>
                    </div>
                </div>
            </div>
        `;
        
        // Adicionar backdrop
        const backdrop = document.createElement('div');
        backdrop.className = 'modal-backdrop fade show';
        
        document.body.appendChild(backdrop);
        document.body.appendChild(helpModal);
        document.body.classList.add('modal-open');
        
        // Adicionar evento para fechar
        helpModal.querySelector('[data-dismiss="modal"]').addEventListener('click', () => {
            helpModal.remove();
            backdrop.remove();
            document.body.classList.remove('modal-open');
        });
        
        // Focar no modal
        setTimeout(() => {
            helpModal.focus();
        }, 100);
    },
    
    /**
     * Adiciona atributos ARIA a um elemento
     * @param {HTMLElement} element - Elemento a receber atributos
     * @param {Object} attributes - Objeto com atributos ARIA
     */
    addAriaAttributes: function(element, attributes) {
        if (!element) return;
        
        for (const [key, value] of Object.entries(attributes)) {
            element.setAttribute(`aria-${key}`, value);
        }
    }
};

// Inicializar quando o DOM estiver pronto
document.addEventListener('DOMContentLoaded', () => {
    ACCESSIBILITY.init();
});
