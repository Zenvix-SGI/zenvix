## Planejamento - Autenticação e Menus Funcionais

**Objetivo:** Implementar autenticação real (simulada), logout funcional e tornar todos os itens do menu lateral funcionais, substituindo placeholders.

**Fluxo de Autenticação:**

1.  **Login (`Login.vue`):**
    *   Usuário insere credenciais (ex: `admin`/`password` para simulação).
    *   Ao submeter, chama `authService.login(username, password)`.
    *   `authService.login`:
        *   Valida as credenciais (simulação).
        *   Se válidas: Armazena um indicador de sessão no `localStorage` (ex: `localStorage.setItem('authToken', 'mock-token')`).
        *   Retorna sucesso.
    *   Se login bem-sucedido, `Login.vue` redireciona para `/dashboard` (`router.push('/dashboard')`).
    *   Se falhar, exibe mensagem de erro.

2.  **Armazenamento de Sessão:**
    *   Utilizar `localStorage` para persistir o estado de autenticação entre recarregamentos da página.
    *   Chave: `authToken` (ou similar).
    *   Valor: Um token simulado (`'mock-token'`) ou um objeto simples.

3.  **Proteção de Rotas (`router/index.js`):**
    *   O `beforeEach` guard verificará a existência do `authToken` no `localStorage`.
    *   Função `isAuthenticated()` lerá `localStorage.getItem('authToken')`.
    *   Se `to.meta.requiresAuth` for `true` e `isAuthenticated()` for `false`, redireciona para `/login`.
    *   Se `to.meta.requiresGuest` for `true` (página de login) e `isAuthenticated()` for `true`, redireciona para `/dashboard`.

4.  **Logout (`Sidebar.vue` / `AppLayout.vue`):**
    *   O botão "Sair" chamará `authService.logout()`.
    *   `authService.logout`:
        *   Remove o indicador de sessão do `localStorage` (`localStorage.removeItem('authToken')`).
    *   Após a chamada ao `authService.logout`, redireciona para `/login` (`router.push('/login')`).

**Menus Funcionais:**

1.  **Criar Views:** Criar componentes Vue básicos para cada item do menu que ainda usa `PlaceholderView.vue`:
    *   `Funcionarios.vue`
    *   `Empresas.vue`
    *   `Exames.vue`
    *   `Relatorios.vue`
    *   `Auditoria.vue`
    *   `Brigada.vue`
    *   (Manter os módulos SST já criados: `GestaoRiscos.vue`, `GestaoEPIs.vue`, etc.)
2.  **Atualizar Rotas (`router/index.js`):**
    *   Importar os novos componentes de view.
    *   Substituir `PlaceholderView` pelos componentes correspondentes nas definições de rota.

**Arquivo de Serviço (`authService.js`):**

*   Criar ou atualizar `src/services/authService.js` para conter as funções `login()`, `logout()`, e `isAuthenticated()` (ou uma função para obter o status de autenticação a ser usada pelo router guard).

