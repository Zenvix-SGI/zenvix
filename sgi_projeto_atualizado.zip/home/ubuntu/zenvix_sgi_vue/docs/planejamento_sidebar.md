## Planejamento de Melhorias Visuais - Menu Lateral

Com base na análise do componente `Sidebar.vue` e na solicitação do usuário por um menu mais fluido, dinâmico e visualmente rico, as seguintes melhorias são planejadas:

1.  **Transições e Animações:**
    *   **Expansão/Colapso:** Refinar a animação de transição da largura (`width`) e do `margin-left` do conteúdo principal (`AppLayout.vue`) para maior suavidade. Utilizar `cubic-bezier` para uma aceleração mais natural.
    *   **Itens de Menu:** Animar a aparição/desaparecimento dos textos (`<span>`) com `opacity` e um leve `transform: translateX()` para um efeito de deslizamento suave.
    *   **Ícone de Toggle:** Animar a rotação do ícone de chevron (`fas fa-chevron-left`/`right`) no botão de toggle.
    *   **Hover/Active:** Adicionar transições suaves (`transition`) aos efeitos de `background-color` e `color` nos estados `:hover` e `.active` dos links do menu.

2.  **Melhorias Visuais:**
    *   **Indicador Ativo:** Tornar o indicador de link ativo (`a.active`) mais destacado. Sugestões: uma barra vertical colorida à esquerda do item, um fundo mais distinto com bordas arredondadas, ou uma animação sutil no ícone.
    *   **Ícones:** Avaliar a possibilidade de usar ícones ligeiramente maiores ou de um conjunto mais moderno (se disponível ou integrando outra biblioteca). Adicionar um leve efeito de escala (`transform: scale(1.1)`) ou mudança de cor no ícone durante o `:hover`.
    *   **Título da Seção (SST):** Melhorar a visibilidade do título da seção "Módulos SST", talvez com uma linha separadora sutil (`border-top` ou `border-bottom`) ou um fundo ligeiramente diferente para o título.
    *   **Estilo Geral:** Considerar a aplicação de um leve efeito *glassmorphism* (blur no fundo e borda sutil) ou *neumorphism* (sombras internas e externas suaves) para modernizar a aparência, mantendo a consistência com outros elementos da interface (como o `glass-card` do login).
    *   **Scrollbar (se aplicável):** Estilizar a barra de rolagem interna (`nav`) para que se integre melhor ao design do tema claro/escuro.

3.  **Responsividade (Mobile):** Revisar e refinar a animação de abertura/fechamento do menu lateral no modo mobile (controlado em `AppLayout.vue`), garantindo que seja fluida (ex: `transform: translateX()`).

Estas melhorias visam atender à solicitação de um menu mais dinâmico e visualmente agradável, sem comprometer a usabilidade.

