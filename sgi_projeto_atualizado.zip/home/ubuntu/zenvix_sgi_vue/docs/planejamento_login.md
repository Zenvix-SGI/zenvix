## Planejamento de Melhorias Visuais - Tela de Login

Com base na análise do componente `Login.vue` e na solicitação do usuário por uma tela de login com mais elementos visuais e um plano de fundo aprimorado, as seguintes melhorias são planejadas:

1.  **Plano de Fundo:**
    *   **Substituição do Padrão:** Remover o `div.bg-pattern` atual.
    *   **Novo Fundo:** Implementar um fundo mais dinâmico e visualmente atraente. Opções:
        *   **Imagem de Alta Qualidade:** Utilizar uma imagem de fundo relevante (tecnologia, segurança, ambiente de trabalho moderno) com um overlay de cor semi-transparente (usando `::before` ou `::after` no `login-page`) para garantir o contraste e a legibilidade do formulário. A imagem deve ser otimizada e responsiva (`background-size: cover`).
        *   **Gradiente Animado:** Criar um gradiente sutil com múltiplas cores (alinhadas à identidade visual da ZENVIX) que se move lentamente (`animation`).
        *   **Vídeo Curto (Opcional/Avançado):** Um vídeo curto e leve em loop (relacionado a segurança ou tecnologia) como fundo, com overlay para contraste. Requer cuidado com performance.
    *   **Adaptação ao Tema:** Garantir que o fundo (ou o overlay) se ajuste bem aos temas claro e escuro.

2.  **Formulário de Login (`login-container` / `glass-card`):**
    *   **Refinamento Visual:** Aprimorar o efeito *glassmorphism* existente, ajustando `backdrop-filter: blur()`, `background-color` (com transparência), e `border` para um visual mais polido e moderno.
    *   **Animação de Entrada:** Aplicar uma animação de entrada mais sofisticada ao carregar a página (após o loader sumir), combinando `opacity` e `transform: translateY()` ou `scale()`.
    *   **Microinterações:**
        *   **Campos de Input:** Adicionar transições suaves (`transition`) para a mudança de cor da borda ou sombra (`box-shadow`) no estado `:focus`.
        *   **Erro de Login:** Implementar uma animação de "tremor" (`shake`) sutil no container do formulário quando ocorrer um erro de login (`errorLogin`).
        *   **Botão Entrar:** Adicionar feedback visual ao clicar no botão (`:active`), como um leve `transform: scale(0.98)`.

3.  **Elementos Visuais Adicionais:**
    *   **Logo/Título:** Destacar mais o título "ZENVIX SGI" e o ícone `fas fa-shield-alt`, talvez com um tamanho ligeiramente maior ou um efeito de sombra sutil.
    *   **Ilustração (Opcional):** Considerar adicionar uma pequena ilustração vetorial temática (segurança, tecnologia) ao lado ou dentro do card de login, que se adapte aos temas claro/escuro.

4.  **Botão de Tema:**
    *   **Estilo:** Melhorar o design do botão `theme-toggle`, tornando-o mais integrado ao visual geral (talvez com o mesmo efeito *glassmorphism* do card).
    *   **Animação:** Adicionar uma transição suave (ex: `cross-fade` ou rotação) entre os ícones de sol e lua ao alternar o tema.

5.  **Responsividade:** Garantir que o fundo, o formulário e todos os elementos visuais se adaptem perfeitamente a diferentes tamanhos de tela, especialmente em dispositivos móveis.

Estas melhorias visam criar uma experiência de login mais moderna, envolvente e profissional, alinhada com as expectativas do usuário.

