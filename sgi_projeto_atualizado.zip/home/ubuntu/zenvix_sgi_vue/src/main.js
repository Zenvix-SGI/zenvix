import { createApp } from 'vue'
import App from './App.vue'
import router from './router' // Importar o router

// Importar CSS global principal (se necessário, ou importar dentro dos componentes/App.vue)
// import '/public/assets/css/style.css'; 

const app = createApp(App)

app.use(router) // Usar o router

app.mount('#app')

