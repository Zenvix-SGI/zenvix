<template>
  <div class="empresas-view">
    <h1 class="page-title">Gestão de Empresas</h1>
    
    <div class="content-card">
      <p>Este módulo permitirá o cadastro e gerenciamento das informações das empresas clientes ou unidades da própria empresa.</p>
      <p>Funcionalidades planejadas:</p>
      <ul>
        <li>Cadastro de Dados da Empresa (CNPJ, Razão Social, Endereço, etc.)</li>
        <li>Cadastro de Contatos</li>
        <li>Associação com Funcionários (lotação)</li>
        <li>Gestão de Contratos (se aplicável)</li>
        <li>Busca e Filtros</li>
      </ul>
      <p><em>(Página funcional - Conteúdo detalhado a ser implementado)</em></p>

      <!-- Exemplo de estrutura futura (Tabela de Empresas) -->
      <div class="table-container placeholder-table">
          <h3>Lista de Empresas (Exemplo)</h3>
          <table>
              <thead>
                  <tr>
                      <th>ID</th>
                      <th>Razão Social</th>
                      <th>CNPJ</th>
                      <th>Cidade</th>
                      <th>Status</th>
                      <th>Ações</th>
                  </tr>
              </thead>
              <tbody>
                  <tr>
                      <td>EMP-001</td>
                      <td>Empresa Mock Ltda</td>
                      <td>00.000.000/0001-00</td>
                      <td>Cidade Mock</td>
                      <td><span class="status status-ativo">Ativo</span></td>
                      <td><button class="btn-sm btn-secondary">Ver Detalhes</button></td>
                  </tr>
                   <tr>
                      <td>EMP-002</td>
                      <td>Consultoria Mock S/A</td>
                      <td>11.111.111/0001-11</td>
                      <td>Outra Cidade</td>
                       <td><span class="status status-ativo">Ativo</span></td>
                      <td><button class="btn-sm btn-secondary">Ver Detalhes</button></td>
                  </tr>
                  <!-- Mais linhas aqui -->
              </tbody>
          </table>
      </div>
    </div>

  </div>
</template>

<script setup>
// Lógica futura para buscar e gerenciar dados de empresas
import { ref, onMounted } from 'vue';

const empresas = ref([]);
const loading = ref(false);

onMounted(async () => {
  // Lógica para carregar dados iniciais se necessário
});

</script>

<style scoped>
/* Reutilizar estilos comuns */
.empresas-view {
  padding: 1.5rem;
}

.page-title {
  margin-bottom: 1.5rem;
  color: var(--primary-color);
}

.content-card {
  background-color: var(--card-bg-color, #fff);
  padding: 1.5rem;
  border-radius: 8px;
  box-shadow: var(--card-shadow, 0 2px 4px rgba(0,0,0,0.1));
}

.content-card ul {
    margin-top: 1rem;
    margin-bottom: 1rem;
    padding-left: 20px;
}

.content-card li {
    margin-bottom: 0.5rem;
}

.placeholder-table {
    margin-top: 2rem;
    padding: 1rem;
    border-radius: 6px;
}

.placeholder-table h3 {
    margin-bottom: 1rem;
    color: var(--text-secondary-color);
}

/* Estilos básicos de tabela */
table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 1rem;
}

thead {
    background-color: var(--primary-color-light, #e0f7fa);
}

th, td {
    border: 1px solid var(--border-color, #dee2e6);
    padding: 0.75rem;
    text-align: left;
    font-size: 0.9rem;
}

th {
    font-weight: 600;
    color: var(--primary-color);
}

/* Estilos de Status (exemplo) */
.status {
    padding: 0.2rem 0.5rem;
    border-radius: 12px;
    font-size: 0.8rem;
    font-weight: 500;
    white-space: nowrap;
}

.status-ativo {
    background-color: rgba(40, 167, 69, 0.1);
    color: #198754; /* Verde */
}

.status-inativo {
    background-color: rgba(108, 117, 125, 0.1);
    color: #6c757d; /* Cinza */
}

/* Botões pequenos */
.btn-sm {
    padding: 0.25rem 0.5rem;
    font-size: 0.8rem;
    border-radius: 4px;
    cursor: pointer;
    border: none;
    transition: background-color 0.2s ease;
}

.btn-secondary {
    background-color: var(--text-secondary-color);
    color: white;
}

.btn-secondary:hover {
    background-color: #5a6268;
}
</style>
