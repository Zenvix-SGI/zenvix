<template>
  <div class="gestao-documentos-view">
    <h1 class="page-title">Gestão de Documentos</h1>
    
    <div class="content-card">
      <p>Este módulo centralizará a gestão de todos os documentos relacionados à segurança e saúde no trabalho.</p>
      <p>Funcionalidades planejadas:</p>
      <ul>
        <li>Cadastro e Upload de Documentos (ASO, Certificados, Laudos, Ordens de Serviço, etc.)</li>
        <li>Organização por Funcionário, Empresa ou Tipo de Documento</li>
        <li>Controle de Validade e Vencimento</li>
        <li>Alertas de documentos vencendo ou vencidos</li>
        <li>Busca e Filtros avançados</li>
        <li>Relatórios de status documental</li>
      </ul>
      <p><em>(Componente em desenvolvimento)</em></p>

      <!-- Exemplo de estrutura futura (Tabela de Documentos) -->
      <div class="table-container placeholder-table">
          <h3>Documentos Recentes (Exemplo)</h3>
          <table>
              <thead>
                  <tr>
                      <th>ID Doc</th>
                      <th>Nome Documento</th>
                      <th>Tipo</th>
                      <th>Funcionário/Empresa</th>
                      <th>Data Emissão</th>
                      <th>Data Vencimento</th>
                      <th>Status</th>
                      <th>Ações</th>
                  </tr>
              </thead>
              <tbody>
                  <tr>
                      <td>D001</td>
                      <td>ASO Admissional - João</td>
                      <td>ASO</td>
                      <td>João Mock Silva</td>
                      <td>2025-01-10</td>
                      <td>2026-01-10</td>
                      <td><span class="status status-valido">Válido</span></td>
                      <td><button class="btn-sm btn-secondary">Visualizar</button></td>
                  </tr>
                   <tr>
                      <td>D002</td>
                      <td>Certificado NR-35 - Maria</td>
                      <td>Certificado</td>
                      <td>Maria Mock Oliveira</td>
                      <td>2024-06-15</td>
                      <td>2026-06-15</td>
                       <td><span class="status status-valido">Válido</span></td>
                      <td><button class="btn-sm btn-secondary">Visualizar</button></td>
                  </tr>
                   <tr>
                      <td>D003</td>
                      <td>Laudo LTCAT - Empresa X</td>
                      <td>Laudo</td>
                      <td>Empresa Mock X</td>
                      <td>2024-11-01</td>
                      <td>2025-11-01</td>
                       <td><span class="status status-avencer">A Vencer</span></td>
                      <td><button class="btn-sm btn-secondary">Visualizar</button></td>
                  </tr>
                  <!-- Mais linhas aqui -->
              </tbody>
          </table>
      </div>
    </div>

  </div>
</template>

<script setup>
// Lógica futura para buscar e gerenciar dados de documentos
import { ref, onMounted } from 'vue';
// import apiService from '../services/apiService'; // Descomentar quando implementar API

const documentos = ref([]);
const loading = ref(false);

onMounted(async () => {
  // loading.value = true;
  // try {
  //   documentos.value = await apiService.getDocumentos(); // Exemplo de chamada API
  // } catch (error) {
  //   console.error("Erro ao buscar documentos:", error);
  //   // Tratar erro
  // } finally {
  //   loading.value = false;
  // }
});

</script>

<style scoped>
/* Reutilizar estilos comuns */
.gestao-documentos-view {
  padding: 1.5rem;
}

.page-title {
  margin-bottom: 1.5rem;
  color: var(--primary-color);
}

.content-card {
  background-color: var(--card-bg-color, #fff);
  padding: 1.5rem;
  border-radius: 8px;
  box-shadow: var(--card-shadow, 0 2px 4px rgba(0,0,0,0.1));
}

.content-card ul {
    margin-top: 1rem;
    margin-bottom: 1rem;
    padding-left: 20px;
}

.content-card li {
    margin-bottom: 0.5rem;
}

.placeholder-table {
    margin-top: 2rem;
    opacity: 0.7;
    border: 1px dashed var(--border-color);
    padding: 1rem;
    border-radius: 6px;
}

.placeholder-table h3 {
    margin-bottom: 1rem;
    color: var(--text-secondary-color);
}

/* Estilos básicos de tabela */
table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 1rem;
}

thead {
    background-color: var(--primary-color-light, #e0f7fa);
}

th, td {
    border: 1px solid var(--border-color, #dee2e6);
    padding: 0.75rem;
    text-align: left;
    font-size: 0.9rem;
}

th {
    font-weight: 600;
    color: var(--primary-color);
}

/* Estilos de Status (exemplo) */
.status {
    padding: 0.2rem 0.5rem;
    border-radius: 12px;
    font-size: 0.8rem;
    font-weight: 500;
    white-space: nowrap;
}

.status-valido {
    background-color: rgba(40, 167, 69, 0.1);
    color: #198754; /* Verde */
}

.status-avencer {
    background-color: rgba(255, 193, 7, 0.1);
    color: #ffc107; /* Amarelo */
}

.status-vencido {
    background-color: rgba(220, 53, 69, 0.1);
    color: #dc3545; /* Vermelho */
}

/* Botões pequenos */
.btn-sm {
    padding: 0.25rem 0.5rem;
    font-size: 0.8rem;
    border-radius: 4px;
    cursor: pointer;
    border: none;
    transition: background-color 0.2s ease;
}

.btn-secondary {
    background-color: var(--text-secondary-color);
    color: white;
}

.btn-secondary:hover {
    background-color: #5a6268;
}

</style>
