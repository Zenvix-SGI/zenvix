<template>
  <div class="gestao-riscos-view">
    <h1 class="page-title">Gestão de Riscos (PGR)</h1>
    
    <div class="content-card">
      <p>Este módulo permitirá o gerenciamento completo dos riscos ocupacionais, conforme exigido pelo Programa de Gerenciamento de Riscos (PGR).</p>
      <p>Funcionalidades planejadas:</p>
      <ul>
        <li>Cadastro de Ambientes de Trabalho</li>
        <li>Identificação de Perigos</li>
        <li>Avaliação de Riscos (Probabilidade x Severidade)</li>
        <li>Plano de Ação para controle dos riscos</li>
        <li>Inventário de Riscos</li>
        <li>Geração de Relatórios do PGR</li>
      </ul>
      <p><em>(Componente em desenvolvimento)</em></p>

      <!-- Exemplo de estrutura futura (Tabela de Riscos) -->
      <div class="table-container placeholder-table">
          <h3>Inventário de Riscos (Exemplo)</h3>
          <table>
              <thead>
                  <tr>
                      <th>ID Risco</th>
                      <th>Ambiente</th>
                      <th>Perigo Identificado</th>
                      <th>Risco Avaliado</th>
                      <th>Nível</th>
                      <th>Controles</th>
                      <th>Ações</th>
                  </tr>
              </thead>
              <tbody>
                  <tr>
                      <td>R001</td>
                      <td>Oficina Mecânica</td>
                      <td>Ruído Contínuo</td>
                      <td>Perda Auditiva</td>
                      <td>Alto</td>
                      <td>Protetor Auricular, Enclausuramento</td>
                      <td><button class="btn-sm btn-secondary">Detalhes</button></td>
                  </tr>
                   <tr>
                      <td>R002</td>
                      <td>Escritório</td>
                      <td>Postura Inadequada</td>
                      <td>LER/DORT</td>
                      <td>Médio</td>
                      <td>Cadeira Ergonômica, Pausas</td>
                      <td><button class="btn-sm btn-secondary">Detalhes</button></td>
                  </tr>
                  <!-- Mais linhas aqui -->
              </tbody>
          </table>
      </div>
    </div>

  </div>
</template>

<script setup>
// Lógica futura para buscar e gerenciar dados de riscos
import { ref, onMounted } from 'vue';
// import apiService from '../services/apiService'; // Descomentar quando implementar API

const riscos = ref([]);
const loading = ref(false);

onMounted(async () => {
  // loading.value = true;
  // try {
  //   riscos.value = await apiService.getRiscos(); // Exemplo de chamada API
  // } catch (error) {
  //   console.error("Erro ao buscar riscos:", error);
  //   // Tratar erro
  // } finally {
  //   loading.value = false;
  // }
});

</script>

<style scoped>
.gestao-riscos-view {
  padding: 1.5rem;
}

.page-title {
  margin-bottom: 1.5rem;
  color: var(--primary-color);
}

.content-card {
  background-color: var(--card-bg-color, #fff);
  padding: 1.5rem;
  border-radius: 8px;
  box-shadow: var(--card-shadow, 0 2px 4px rgba(0,0,0,0.1));
}

.content-card ul {
    margin-top: 1rem;
    margin-bottom: 1rem;
    padding-left: 20px;
}

.content-card li {
    margin-bottom: 0.5rem;
}

.placeholder-table {
    margin-top: 2rem;
    opacity: 0.7;
    border: 1px dashed var(--border-color);
    padding: 1rem;
    border-radius: 6px;
}

.placeholder-table h3 {
    margin-bottom: 1rem;
    color: var(--text-secondary-color);
}

/* Estilos básicos de tabela */
table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 1rem;
}

thead {
    background-color: var(--primary-color-light, #e0f7fa);
}

th, td {
    border: 1px solid var(--border-color, #dee2e6);
    padding: 0.75rem;
    text-align: left;
    font-size: 0.9rem;
}

th {
    font-weight: 600;
    color: var(--primary-color);
}

/* Botões pequenos */
.btn-sm {
    padding: 0.25rem 0.5rem;
    font-size: 0.8rem;
    border-radius: 4px;
    cursor: pointer;
    border: none;
    transition: background-color 0.2s ease;
}

.btn-secondary {
    background-color: var(--text-secondary-color);
    color: white;
}

.btn-secondary:hover {
    background-color: #5a6268;
}

</style>
