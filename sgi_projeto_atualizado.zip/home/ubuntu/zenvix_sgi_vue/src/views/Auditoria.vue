<template>
  <div class="auditoria-view">
    <h1 class="page-title">Auditorias Internas e Externas</h1>
    
    <div class="content-card">
      <p>Este módulo permitirá o planejamento, execução e acompanhamento de auditorias de segurança e saúde no trabalho.</p>
      <p>Funcionalidades planejadas:</p>
      <ul>
        <li>Cadastro de Tipos de Auditoria (Interna, Externa, Certificação)</li>
        <li>Planejamento e Agendamento de Auditorias</li>
        <li>Registro de Não Conformidades e Observações</li>
        <li>Plano de Ação para tratamento das não conformidades</li>
        <li>Acompanhamento do status das ações</li>
        <li>Geração de Relatórios de Auditoria</li>
      </ul>
      <p><em>(Página funcional - Conteúdo detalhado a ser implementado)</em></p>

      <!-- Exemplo de estrutura futura (Tabela de Auditorias) -->
      <div class="table-container placeholder-table">
          <h3>Auditorias Agendadas/Realizadas (Exemplo)</h3>
          <table>
              <thead>
                  <tr>
                      <th>ID Auditoria</th>
                      <th>Tipo</th>
                      <th>Data Planejada</th>
                      <th>Data Realizada</th>
                      <th>Auditor Líder</th>
                      <th>Status</th>
                      <th>Ações</th>
                  </tr>
              </thead>
              <tbody>
                  <tr>
                      <td>AUD-2025-005</td>
                      <td>Interna - Processos</td>
                      <td>2025-05-10</td>
                      <td>2025-05-12</td>
                      <td>Auditor Mock A</td>
                      <td><span class="status status-concluida">Concluída</span></td>
                      <td><button class="btn-sm btn-secondary">Ver Relatório</button></td>
                  </tr>
                   <tr>
                      <td>AUD-2025-006</td>
                      <td>Externa - ISO 45001</td>
                      <td>2025-08-20</td>
                      <td>-</td>
                       <td>Organismo Cert.</td>
                      <td><span class="status status-agendada">Agendada</span></td>
                      <td><button class="btn-sm btn-secondary">Ver Plano</button></td>
                  </tr>
                  <!-- Mais linhas aqui -->
              </tbody>
          </table>
      </div>
    </div>

  </div>
</template>

<script setup>
// Lógica futura para buscar e gerenciar dados de auditorias
import { ref, onMounted } from 'vue';

const auditorias = ref([]);
const loading = ref(false);

onMounted(async () => {
  // Lógica para carregar dados iniciais se necessário
});

</script>

<style scoped>
/* Reutilizar estilos comuns */
.auditoria-view {
  padding: 1.5rem;
}

.page-title {
  margin-bottom: 1.5rem;
  color: var(--primary-color);
}

.content-card {
  background-color: var(--card-bg-color, #fff);
  padding: 1.5rem;
  border-radius: 8px;
  box-shadow: var(--card-shadow, 0 2px 4px rgba(0,0,0,0.1));
}

.content-card ul {
    margin-top: 1rem;
    margin-bottom: 1rem;
    padding-left: 20px;
}

.content-card li {
    margin-bottom: 0.5rem;
}

.placeholder-table {
    margin-top: 2rem;
    padding: 1rem;
    border-radius: 6px;
}

.placeholder-table h3 {
    margin-bottom: 1rem;
    color: var(--text-secondary-color);
}

/* Estilos básicos de tabela */
table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 1rem;
}

thead {
    background-color: var(--primary-color-light, #e0f7fa);
}

th, td {
    border: 1px solid var(--border-color, #dee2e6);
    padding: 0.75rem;
    text-align: left;
    font-size: 0.9rem;
}

th {
    font-weight: 600;
    color: var(--primary-color);
}

/* Estilos de Status (exemplo) */
.status {
    padding: 0.2rem 0.5rem;
    border-radius: 12px;
    font-size: 0.8rem;
    font-weight: 500;
    white-space: nowrap;
}

.status-agendada {
    background-color: rgba(13, 110, 253, 0.1);
    color: #0d6efd; /* Azul */
}

.status-concluida {
    background-color: rgba(40, 167, 69, 0.1);
    color: #198754; /* Verde */
}

.status-cancelada {
    background-color: rgba(108, 117, 125, 0.1);
    color: #6c757d; /* Cinza */
}

/* Botões pequenos */
.btn-sm {
    padding: 0.25rem 0.5rem;
    font-size: 0.8rem;
    border-radius: 4px;
    cursor: pointer;
    border: none;
    transition: background-color 0.2s ease;
}

.btn-secondary {
    background-color: var(--text-secondary-color);
    color: white;
}

.btn-secondary:hover {
    background-color: #5a6268;
}
</style>
