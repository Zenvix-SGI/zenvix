<template>
  <div class="gestao-treinamentos-view">
    <h1 class="page-title">Gestão de Treinamentos</h1>
    
    <div class="content-card">
      <p>Este módulo permitirá o planejamento, agendamento, registro e controle dos treinamentos de segurança e saúde no trabalho.</p>
      <p>Funcionalidades planejadas:</p>
      <ul>
        <li>Cadastro de Tipos de Treinamento (NRs, específicos)</li>
        <li>Agendamento de Turmas</li>
        <li>Registro de Participantes e Presença</li>
        <li>Controle de Validade e Reciclagem</li>
        <li>Emissão de Certificados (placeholder/integração)</li>
        <li>Alertas de treinamentos vencendo</li>
        <li>Relatórios de participação e validade</li>
      </ul>
      <p><em>(Componente em desenvolvimento)</em></p>

      <!-- Exemplo de estrutura futura (Tabela de Treinamentos Agendados) -->
      <div class="table-container placeholder-table">
          <h3>Treinamentos Agendados (Exemplo)</h3>
          <table>
              <thead>
                  <tr>
                      <th>ID Turma</th>
                      <th>Treinamento</th>
                      <th>Data Início</th>
                      <th>Data Fim</th>
                      <th>Instrutor</th>
                      <th>Status</th>
                      <th>Ações</th>
                  </tr>
              </thead>
              <tbody>
                  <tr>
                      <td>T2025-010</td>
                      <td>NR-35 Trabalho em Altura</td>
                      <td>2025-06-10</td>
                      <td>2025-06-11</td>
                      <td>Instrutor Mock</td>
                      <td><span class="status status-agendado">Agendado</span></td>
                      <td><button class="btn-sm btn-secondary">Ver Turma</button></td>
                  </tr>
                   <tr>
                      <td>T2025-011</td>
                      <td>NR-33 Espaços Confinados</td>
                      <td>2025-07-05</td>
                      <td>2025-07-05</td>
                      <td>Instrutor Mock</td>
                      <td><span class="status status-agendado">Agendado</span></td>
                      <td><button class="btn-sm btn-secondary">Ver Turma</button></td>
                  </tr>
                  <!-- Mais linhas aqui -->
              </tbody>
          </table>
      </div>
    </div>

  </div>
</template>

<script setup>
// Lógica futura para buscar e gerenciar dados de treinamentos
import { ref, onMounted } from 'vue';
// import apiService from '../services/apiService'; // Descomentar quando implementar API

const turmas = ref([]);
const loading = ref(false);

onMounted(async () => {
  // loading.value = true;
  // try {
  //   turmas.value = await apiService.getTurmasTreinamento(); // Exemplo de chamada API
  // } catch (error) {
  //   console.error("Erro ao buscar turmas:", error);
  //   // Tratar erro
  // } finally {
  //   loading.value = false;
  // }
});

</script>

<style scoped>
/* Reutilizar estilos comuns */
.gestao-treinamentos-view {
  padding: 1.5rem;
}

.page-title {
  margin-bottom: 1.5rem;
  color: var(--primary-color);
}

.content-card {
  background-color: var(--card-bg-color, #fff);
  padding: 1.5rem;
  border-radius: 8px;
  box-shadow: var(--card-shadow, 0 2px 4px rgba(0,0,0,0.1));
}

.content-card ul {
    margin-top: 1rem;
    margin-bottom: 1rem;
    padding-left: 20px;
}

.content-card li {
    margin-bottom: 0.5rem;
}

.placeholder-table {
    margin-top: 2rem;
    opacity: 0.7;
    border: 1px dashed var(--border-color);
    padding: 1rem;
    border-radius: 6px;
}

.placeholder-table h3 {
    margin-bottom: 1rem;
    color: var(--text-secondary-color);
}

/* Estilos básicos de tabela */
table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 1rem;
}

thead {
    background-color: var(--primary-color-light, #e0f7fa);
}

th, td {
    border: 1px solid var(--border-color, #dee2e6);
    padding: 0.75rem;
    text-align: left;
    font-size: 0.9rem;
}

th {
    font-weight: 600;
    color: var(--primary-color);
}

/* Estilos de Status (exemplo) */
.status {
    padding: 0.2rem 0.5rem;
    border-radius: 12px;
    font-size: 0.8rem;
    font-weight: 500;
    white-space: nowrap;
}

.status-agendado {
    background-color: rgba(13, 110, 253, 0.1);
    color: #0d6efd; /* Azul */
}

.status-concluido {
    background-color: rgba(40, 167, 69, 0.1);
    color: #198754; /* Verde */
}

.status-cancelado {
    background-color: rgba(108, 117, 125, 0.1);
    color: #6c757d; /* Cinza */
}

/* Botões pequenos */
.btn-sm {
    padding: 0.25rem 0.5rem;
    font-size: 0.8rem;
    border-radius: 4px;
    cursor: pointer;
    border: none;
    transition: background-color 0.2s ease;
}

.btn-secondary {
    background-color: var(--text-secondary-color);
    color: white;
}

.btn-secondary:hover {
    background-color: #5a6268;
}

</style>
