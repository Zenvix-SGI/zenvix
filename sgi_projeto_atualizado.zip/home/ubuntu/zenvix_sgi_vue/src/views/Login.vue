
<template>
  <div class="login-wrapper">
    <Particles id="tsparticles" :options="particlesOptions" />
    <div class="login-container glass-card" :class="{ shake: errorLogin }">
      <div class="login-header">
        <h1><i class="fas fa-shield-alt"></i> ZENVIX SGI</h1>
        <p class="subtitle">Sistema de Gestão em Segurança e Saúde no Trabalho</p>
      </div>

      <form @submit.prevent="handleLogin">
        <div class="form-group">
          <label for="username">Usuário</label>
          <div class="input-wrapper">
            <i class="fas fa-user input-icon"></i>
            <input type="text" id="username" v-model="username" class="with-icon" placeholder="Digite seu usuário" required>
          </div>
        </div>

        <div class="form-group">
          <label for="password">Senha</label>
          <div class="input-wrapper">
            <i class="fas fa-lock input-icon"></i>
            <input type="password" id="password" v-model="password" class="with-icon" placeholder="Digite sua senha" required>
          </div>
        </div>

        <button type="submit" class="login-btn">Entrar</button>
      </form>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import Particles from "vue3-particles"

const username = ref("")
const password = ref("")
const errorLogin = ref(false)

const handleLogin = () => {
  // lógica de login
}

const particlesOptions = {
  background: {
    color: "#003b46" // azul petróleo
  },
  particles: {
    number: { value: 60 },
    size: { value: 3 },
    move: { enable: true, speed: 1 },
    color: { value: "#ffffff" },
    line_linked: {
      enable: true,
      color: "#ffffff",
      opacity: 0.2
    }
  }
}
</script>

<style scoped>
.login-wrapper {
  height: 100vh;
  width: 100vw;
  position: relative;
  overflow: hidden;
}

.login-container {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  z-index: 1;
  background: rgba(255, 255, 255, 0.15);
  padding: 2rem;
  border-radius: 10px;
  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);
  backdrop-filter: blur(8px);
  color: #fff;
}

.login-header h1 {
  font-size: 2rem;
  margin-bottom: 0.5rem;
}

.subtitle {
  font-size: 1rem;
  color: #ccc;
}

.login-btn {
  margin-top: 1rem;
  width: 100%;
  padding: 0.7rem;
  background: #005566;
  color: white;
  border: none;
  border-radius: 5px;
  font-weight: bold;
}
</style>
