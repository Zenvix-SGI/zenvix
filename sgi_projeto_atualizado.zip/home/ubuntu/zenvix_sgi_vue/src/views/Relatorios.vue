<template>
  <div class="relatorios-view">
    <h1 class="page-title">Relatórios Gerenciais</h1>
    
    <div class="content-card">
      <p>Este módulo centralizará a geração de relatórios consolidados de todos os módulos do sistema.</p>
      <p>Relatórios Planejados:</p>
      <ul>
        <li>Relatório Geral de Status (vencimentos, pendências)</li>
        <li>Relatórios de Funcionários (ativos, por setor, etc.)</li>
        <li>Relatórios de Exames (realizados, vencidos, por tipo)</li>
        <li>Relatórios de Treinamentos (realizados, vencidos, por tipo)</li>
        <li>Relatórios de EPIs (consumo, entrega, CAs vencidos)</li>
        <li>Relatórios de Acidentes (estatísticas, por tipo, por setor)</li>
        <li>Relatórios de Riscos (mapa de riscos, por GHE)</li>
        <li>Relatórios de Documentos (vencidos, por tipo)</li>
        <li>Relatórios da CIPA</li>
        <li>Relatórios customizáveis (futuro)</li>
      </ul>
      <p><em>(Página funcional - Conteúdo detalhado a ser implementado)</em></p>

       <!-- Exemplo de estrutura futura (Lista de Relatórios Disponíveis) -->
      <div class="placeholder-reports">
          <h3>Relatórios Disponíveis (Exemplo)</h3>
          <ul class="report-list">
              <li><a href="#" @click.prevent><i class="fas fa-file-alt"></i> Relatório de Vencimentos Gerais (Próximos 30 dias)</a></li>
              <li><a href="#" @click.prevent><i class="fas fa-chart-pie"></i> Estatísticas de Acidentes por Setor</a></li>
              <li><a href="#" @click.prevent><i class="fas fa-clipboard-list"></i> Fichas de EPI Pendentes de Devolução</a></li>
              <li><a href="#" @click.prevent><i class="fas fa-calendar-check"></i> Treinamentos Vencidos ou a Vencer</a></li>
              <!-- Mais relatórios -->
          </ul>
          <button class="btn-primary btn-generate"><i class="fas fa-cogs"></i> Gerar Relatório Customizado (Em breve)</button>
      </div>
    </div>

  </div>
</template>

<script setup>
// Lógica futura para gerar e exibir relatórios
import { ref, onMounted } from 'vue';

const reports = ref([]);
const loading = ref(false);

onMounted(async () => {
  // Lógica para carregar lista de relatórios disponíveis
});

</script>

<style scoped>
/* Reutilizar estilos comuns */
.relatorios-view {
  padding: 1.5rem;
}

.page-title {
  margin-bottom: 1.5rem;
  color: var(--primary-color);
}

.content-card {
  background-color: var(--card-bg-color, #fff);
  padding: 1.5rem;
  border-radius: 8px;
  box-shadow: var(--card-shadow, 0 2px 4px rgba(0,0,0,0.1));
}

.content-card ul:not(.report-list) {
    margin-top: 1rem;
    margin-bottom: 1rem;
    padding-left: 20px;
}

.content-card li:not(.report-list li) {
    margin-bottom: 0.5rem;
}

.placeholder-reports {
    margin-top: 2rem;
    padding: 1rem;
    border-radius: 6px;
    border: 1px solid var(--border-color, #dee2e6);
}

.placeholder-reports h3 {
    margin-bottom: 1rem;
    color: var(--text-secondary-color);
}

.report-list {
    list-style: none;
    padding: 0;
    margin: 0 0 1.5rem 0;
}

.report-list li {
    margin-bottom: 0.75rem;
}

.report-list a {
    color: var(--primary-color);
    text-decoration: none;
    transition: color 0.2s ease;
    display: inline-flex;
    align-items: center;
    gap: 8px;
}

.report-list a:hover {
    color: var(--secondary-color);
    text-decoration: underline;
}

.report-list i {
    color: var(--text-secondary-color);
}

/* Botão Primário (reutilizado) */
.btn-primary {
    background-color: var(--primary-color);
    color: white;
    border: none;
    padding: 0.7rem 1.2rem;
    border-radius: 6px;
    cursor: pointer;
    font-size: 0.9rem;
    font-weight: 500;
    transition: background-color 0.2s ease, transform 0.1s ease;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
}
.btn-primary:hover {
    background-color: var(--secondary-color);
}
.btn-primary:active {
    transform: scale(0.98);
}
.btn-primary:disabled {
    background-color: #adb5bd;
    cursor: not-allowed;
}
.btn-generate {
    margin-top: 1rem;
}

</style>
