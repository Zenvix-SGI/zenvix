<template>
  <div class="dashboard-page">
    <!-- Cabeçalho da página (pode ser parte do layout ou específico aqui) -->
    <!-- O cabeçalho com boas-vindas e perfil já está no AppLayout.vue -->
    
    <h1><i class="fas fa-tachometer-alt"></i> Painel de Controle</h1>

    <section class="card glass-card slide-in-up">
      <h3>Visão Geral do Sistema</h3>
      <p>Use o menu lateral para navegar pelos módulos do sistema.</p>
    </section>

    <div class="dashboard-grid">
      <section class="card status-card slide-in-left">
        <h3><i class="fas fa-chart-pie"></i> Status Geral</h3>
        <ul class="status-list" id="statusList">
          <li><i class="fas fa-user-check"></i> Funcionários ativos: <span id="funcionariosAtivos">{{ statusGeral.funcionariosAtivos }}</span></li>
          <li><i class="fas fa-building"></i> Empresas cadastradas: <span id="empresasCadastradas">{{ statusGeral.empresasCadastradas }}</span></li>
          <li><i class="fas fa-hard-hat"></i> Tipos de EPIs: <span id="tiposEPI">{{ statusGeral.tiposEPI }}</span></li>
          <li><i class="fas fa-file-alt"></i> Tipos de Documentos: <span id="tiposDocumento">{{ statusGeral.tiposDocumento }}</span></li>
        </ul>
        <div v-if="loadingStatus" class="loading-placeholder">Carregando...</div>
      </section>

      <section class="card alert-card slide-in-right">
        <h3><i class="fas fa-exclamation-triangle"></i> Alertas de Vencimento (Próximos 30 dias)</h3>
        <ul class="alert-list" id="alertasList" v-if="!loadingAlertas && alertasVencimento.total > 0">
          <li id="alertasExames"><i class="fas fa-stethoscope"></i> Exames: <span :class="getAlertCountClass(alertasVencimento.exames)">{{ alertasVencimento.exames }}</span></li>
          <li id="alertasTreinamentos"><i class="fas fa-chalkboard-teacher"></i> Treinamentos: <span :class="getAlertCountClass(alertasVencimento.treinamentos)">{{ alertasVencimento.treinamentos }}</span></li>
          <li id="alertasEpis"><i class="fas fa-hard-hat"></i> Validade CA EPIs: <span :class="getAlertCountClass(alertasVencimento.epis)">{{ alertasVencimento.epis }}</span></li>
          <li id="alertasDocumentos"><i class="fas fa-file-alt"></i> Documentos: <span :class="getAlertCountClass(alertasVencimento.documentos)">{{ alertasVencimento.documentos }}</span></li>
        </ul>
         <p v-if="!loadingAlertas && alertasVencimento.total === 0" id="noAlertsMessage">Nenhum item próximo do vencimento.</p>
         <div v-if="loadingAlertas" class="loading-placeholder">Carregando...</div>
      </section>
    </div>

    <!-- Histórico de Atividades Recentes -->
    <section class="card recent-activities-card fade-in">
      <h3><i class="fas fa-history"></i> Atividades Recentes</h3>
      <div class="activities-timeline" id="activitiesTimeline">
        <div v-if="loadingAtividades">Carregando atividades...</div>
        <div v-else-if="atividadesRecentes.length === 0">Nenhuma atividade recente.</div>
        <div v-else v-for="(atividade, index) in atividadesRecentes" :key="index" class="timeline-item">
          <div class="timeline-icon"><i :class="atividade.icon"></i></div>
          <div class="timeline-content">
            <h4>{{ atividade.titulo }}</h4>
            <p>{{ atividade.descricao }}</p>
            <span class="timeline-date">{{ formatarData(atividade.data) }}</span>
          </div>
        </div>
      </div>
    </section>

    <!-- Seção de Gráfico -->
    <section class="card chart-container fade-in">
      <h3><i class="fas fa-chart-line"></i> Exames Realizados Mensalmente</h3>
      <canvas id="graficoExames" ref="graficoExamesCanvas"></canvas>
      <div v-if="loadingGrafico" class="loading-placeholder">Carregando gráfico...</div>
    </section>

    <!-- Seção de Relatório Rápido -->
    <section class="card report-container fade-in" id="relatorioRapido">
      <h3><i class="fas fa-table"></i> Relatório Rápido de Atendimentos</h3>
      <div class="report-actions">
           <input id="filtroTabela" v-model="filtroRelatorio" placeholder="Buscar por nome..." type="text"/>
           <button @click="gerarPDFRelatorioRapido" class="btn-primary" :disabled="gerandoPDF">
             <i v-if="!gerandoPDF" class="fas fa-file-pdf"></i>
             <i v-else class="fas fa-spinner fa-spin"></i>
             {{ gerandoPDF ? 'Gerando...' : 'Exportar PDF' }}
           </button>
      </div>
      <div class="table-container">
          <table id="tabelaDadosRapida">
              <thead>
                  <tr>
                      <th>Nome</th>
                      <th>Data</th>
                      <th>Tipo</th>
                      <th>Status</th>
                  </tr>
              </thead>
              <tbody>
                  <tr v-if="loadingRelatorio"> <td colspan="4">Carregando relatório...</td></tr>
                  <tr v-else-if="filteredRelatorioRapido.length === 0"><td colspan="4">Nenhum registro encontrado.</td></tr>
                  <tr v-else v-for="item in filteredRelatorioRapido" :key="item.id">
                      <td data-label="Nome">{{ item.nome }}</td>
                      <td data-label="Data">{{ formatarDataSimples(item.data) }}</td>
                      <td data-label="Tipo">{{ item.tipo }}</td>
                      <td data-label="Status"><span :class="getStatusBadgeClass(item.status)">{{ item.status }}</span></td>
                  </tr>
              </tbody>
          </table>
      </div>
    </section>

  </div>
</template>

<script setup>
import { ref, onMounted, computed, nextTick } from 'vue';
import Chart from 'chart.js/auto'; // Importar Chart.js
import html2pdf from 'html2pdf.js'; // Importar html2pdf
// Importar serviços de API (serão criados)
// import { getDashboardStatus, getAlertasVencimento, getAtividadesRecentes, getGraficoData, getRelatorioRapido } from '@/services/dashboardService';

// Refs para controle de loading
const loadingStatus = ref(true);
const loadingAlertas = ref(true);
const loadingAtividades = ref(true);
const loadingGrafico = ref(true);
const loadingRelatorio = ref(true);
const gerandoPDF = ref(false);

// Refs para dados
const statusGeral = ref({ funcionariosAtivos: '--', empresasCadastradas: '--', tiposEPI: '--', tiposDocumento: '--' });
const alertasVencimento = ref({ exames: 0, treinamentos: 0, epis: 0, documentos: 0, total: 0 });
const atividadesRecentes = ref([]);
const relatorioRapido = ref([]);
const filtroRelatorio = ref('');

// Ref para o canvas do gráfico
const graficoExamesCanvas = ref(null);
let graficoExamesInstance = null;

// Dados simulados (substituir por chamadas de API)
const fetchData = async () => {
  try {
    // Simular chamadas API
    await new Promise(res => setTimeout(res, 1000));
    statusGeral.value = { funcionariosAtivos: 152, empresasCadastradas: 15, tiposEPI: 45, tiposDocumento: 23 };
    loadingStatus.value = false;

    await new Promise(res => setTimeout(res, 800));
    alertasVencimento.value = { exames: 5, treinamentos: 2, epis: 8, documentos: 1, total: 16 };
    loadingAlertas.value = false;

    await new Promise(res => setTimeout(res, 1200));
    atividadesRecentes.value = [
      { icon: 'fas fa-user-plus', titulo: 'Novo funcionário cadastrado', descricao: 'Maria Silva foi adicionada ao sistema', data: new Date(2025, 4, 30, 10, 45) },
      { icon: 'fas fa-file-medical', titulo: 'Exame registrado', descricao: 'Exame periódico de João Santos', data: new Date(2025, 4, 29, 15, 30) },
      { icon: 'fas fa-hard-hat', titulo: 'EPI entregue', descricao: '5 capacetes entregues ao setor de produção', data: new Date(2025, 4, 23, 9, 15) },
    ];
    loadingAtividades.value = false;

    await new Promise(res => setTimeout(res, 1500));
    const graficoData = {
        labels: ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun'],
        data: [12, 19, 8, 15, 22, 14]
    };
    renderizarGrafico(graficoData);
    loadingGrafico.value = false;

    await new Promise(res => setTimeout(res, 900));
    relatorioRapido.value = [
        { id: 1, nome: 'João Silva', data: '2025-05-10', tipo: 'Admissional', status: 'Concluído' },
        { id: 2, nome: 'Maria Oliveira', data: '2025-05-14', tipo: 'Periódico', status: 'Concluído' },
        { id: 3, nome: 'Carlos Pereira', data: '2025-05-20', tipo: 'Demissional', status: 'Pendente' },
        { id: 4, nome: 'Ana Santos', data: '2025-05-25', tipo: 'Periódico', status: 'Agendado' },
    ];
    loadingRelatorio.value = false;

  } catch (error) {
    console.error("Erro ao buscar dados do dashboard:", error);
    // Tratar erros, talvez mostrar notificações
    loadingStatus.value = false;
    loadingAlertas.value = false;
    loadingAtividades.value = false;
    loadingGrafico.value = false;
    loadingRelatorio.value = false;
  }
};

const renderizarGrafico = (data) => {
  if (graficoExamesInstance) {
      graficoExamesInstance.destroy(); // Destruir gráfico anterior se existir
  }
  if (graficoExamesCanvas.value) {
    const ctx = graficoExamesCanvas.value.getContext('2d');
    graficoExamesInstance = new Chart(ctx, {
      type: 'bar',
      data: {
        labels: data.labels,
        datasets: [{
          label: 'Exames Realizados',
          data: data.data,
          backgroundColor: 'rgba(0, 95, 115, 0.7)', // Cor primária com transparência
          borderColor: 'rgba(0, 56, 68, 1)', // Cor primária mais escura
          borderWidth: 1
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
          y: {
            beginAtZero: true
          }
        }
      }
    });
  }
};

const filteredRelatorioRapido = computed(() => {
  if (!filtroRelatorio.value) {
    return relatorioRapido.value;
  }
  const filtro = filtroRelatorio.value.toLowerCase();
  return relatorioRapido.value.filter(item => 
    item.nome.toLowerCase().includes(filtro)
  );
});

const gerarPDFRelatorioRapido = () => {
  gerandoPDF.value = true;
  const element = document.getElementById('relatorioRapido');
  const opt = {
      margin: 1,
      filename: 'relatorio_atendimentos_zenvix.pdf',
      image: { type: 'jpeg', quality: 0.98 },
      html2canvas: { scale: 2, useCORS: true }, // useCORS pode ser útil
      jsPDF: { unit: 'cm', format: 'a4', orientation: 'portrait' }
  };

  // Adicionar notificação de progresso (implementar sistema de notificação)
  console.log("Gerando PDF...");

  html2pdf().set(opt).from(element).save().then(() => {
      console.log("PDF gerado com sucesso!");
      // Adicionar notificação de sucesso
  }).catch(error => {
      console.error("Erro ao gerar PDF:", error);
      // Adicionar notificação de erro
  }).finally(() => {
      gerandoPDF.value = false;
  });
};

// Funções auxiliares de formatação e classes
const getAlertCountClass = (count) => {
  return count > 0 ? 'count warning' : 'count zero';
};

const formatarData = (dateString) => {
    if (!dateString) return '';
    const date = new Date(dateString);
    return date.toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' });
};

const formatarDataSimples = (dateString) => {
    if (!dateString) return '';
    const [year, month, day] = dateString.split('-');
    return `${day}/${month}/${year}`;
};

const getStatusBadgeClass = (status) => {
    switch (status.toLowerCase()) {
        case 'concluído': return 'status-badge status-valid';
        case 'pendente': return 'status-badge status-warning';
        case 'agendado': return 'status-badge status-info';
        default: return 'status-badge';
    }
};

onMounted(() => {
  fetchData();
});

</script>

<style scoped>
/* Importar ou adaptar estilos de assets/css/style.css e dashboard.css */
.dashboard-page {
  /* Estilos gerais da página */
}

.dashboard-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
  gap: 1.5rem;
  margin-bottom: 1.5rem;
}

.card {
  background-color: var(--card-bg-color, #fff);
  padding: 1.5rem;
  border-radius: 8px;
  box-shadow: var(--card-shadow, 0 2px 4px rgba(0,0,0,0.1));
  margin-bottom: 1.5rem;
}

.card h3 {
  margin-top: 0;
  margin-bottom: 1rem;
  color: var(--primary-color, #005f73);
  display: flex;
  align-items: center;
}

.card h3 i {
  margin-right: 0.5rem;
}

.status-list, .alert-list {
  list-style: none;
  padding: 0;
  margin: 0;
}

.status-list li, .alert-list li {
  margin-bottom: 0.5rem;
  display: flex;
  align-items: center;
}

.status-list li i, .alert-list li i {
  margin-right: 0.5rem;
  color: var(--text-secondary-color, #6c757d);
}

.alert-list .count {
  font-weight: bold;
  margin-left: auto; /* Alinha à direita */
  padding: 0.2rem 0.5rem;
  border-radius: 4px;
  font-size: 0.9em;
}

.alert-list .count.zero {
  color: var(--text-secondary-color, #6c757d);
  background-color: transparent;
}

.alert-list .count.warning {
  color: var(--warning-color-dark, #856404);
  background-color: var(--warning-color-light, #fff3cd);
}

.recent-activities-card .activities-timeline {
  max-height: 400px;
  overflow-y: auto;
}

.timeline-item {
  display: flex;
  margin-bottom: 1rem;
  padding-bottom: 1rem;
  border-bottom: 1px solid var(--border-color, #eee);
}
.timeline-item:last-child {
    border-bottom: none;
    margin-bottom: 0;
    padding-bottom: 0;
}

.timeline-icon {
  margin-right: 1rem;
  width: 40px;
  height: 40px;
  border-radius: 50%;
  background-color: var(--primary-color-light, #e0f7fa);
  color: var(--primary-color, #005f73);
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
}

.timeline-content h4 {
  margin: 0 0 0.3rem 0;
  font-size: 1rem;
}

.timeline-content p {
  margin: 0 0 0.3rem 0;
  font-size: 0.9rem;
  color: var(--text-secondary-color, #6c757d);
}

.timeline-date {
  font-size: 0.8rem;
  color: #aaa;
}

.chart-container {
  height: 400px; /* Altura fixa para o container do gráfico */
  position: relative;
}

#graficoExames {
    max-height: 350px; /* Limita altura do canvas */
}

.report-container .report-actions {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 1rem;
}

.report-container input[type="text"] {
    padding: 0.5rem;
    border: 1px solid var(--border-color, #ccc);
    border-radius: 4px;
    max-width: 250px;
}

.table-container {
    overflow-x: auto; /* Para tabelas responsivas */
}

table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 1rem;
}

thead {
    background-color: var(--table-header-bg, #f8f9fa);
}

th, td {
    padding: 0.8rem;
    text-align: left;
    border-bottom: 1px solid var(--border-color, #dee2e6);
}

.status-badge {
    padding: 0.2em 0.6em;
    border-radius: 0.25rem;
    font-size: 0.85em;
    font-weight: 500;
    display: inline-block;
}

.status-badge.status-valid {
    color: var(--success-color-dark, #155724);
    background-color: var(--success-color-light, #d4edda);
}

.status-badge.status-warning {
    color: var(--warning-color-dark, #856404);
    background-color: var(--warning-color-light, #fff3cd);
}

.status-badge.status-info {
    color: var(--info-color-dark, #0c5460);
    background-color: var(--info-color-light, #d1ecf1);
}

.loading-placeholder {
    color: var(--text-secondary-color, #6c757d);
    padding: 1rem;
    text-align: center;
}

/* Animações (slide-in, fade-in) - podem ser definidas globalmente */
.slide-in-up { animation: slideInUp 0.5s ease-out forwards; opacity: 0; }
.slide-in-left { animation: slideInLeft 0.5s ease-out forwards; opacity: 0; }
.slide-in-right { animation: slideInRight 0.5s ease-out forwards; opacity: 0; }
.fade-in { animation: fadeIn 0.6s ease-out forwards; opacity: 0; }

@keyframes slideInUp { from { transform: translateY(20px); opacity: 0; } to { transform: translateY(0); opacity: 1; } }
@keyframes slideInLeft { from { transform: translateX(-20px); opacity: 0; } to { transform: translateX(0); opacity: 1; } }
@keyframes slideInRight { from { transform: translateX(20px); opacity: 0; } to { transform: translateX(0); opacity: 1; } }
@keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }

</style>
