<template>
  <div class="brigada-view">
    <h1 class="page-title">Gestão da Brigada de Incêndio</h1>
    
    <div class="content-card">
      <p>Este módulo auxiliará na gestão da Brigada de Incêndio da empresa.</p>
      <p>Funcionalidades planejadas:</p>
      <ul>
        <li>Cadastro de Membros da Brigada</li>
        <li>Controle de Treinamentos Específicos (Primeiros Socorros, Combate a Incêndio)</li>
        <li>Registro de Simulados e Exercícios</li>
        <li>Controle de Equipamentos da Brigada (extintores, hidrantes, etc. - link com EPIs?)</li>
        <li>Plano de Emergência e Abandono</li>
        <li>Relatórios de atividades da Brigada</li>
      </ul>
      <p><em>(Página funcional - Conteúdo detalhado a ser implementado)</em></p>

      <!-- Exemplo de estrutura futura (Tabela de Brigadistas) -->
      <div class="table-container placeholder-table">
          <h3>Membros da Brigada (Exemplo)</h3>
          <table>
              <thead>
                  <tr>
                      <th>Nome</th>
                      <th>Setor</th>
                      <th>Função na Brigada</th>
                      <th>Treinamento Combate Incêndio (Validade)</th>
                      <th>Treinamento Primeiros Socorros (Validade)</th>
                      <th>Status</th>
                      <th>Ações</th>
                  </tr>
              </thead>
              <tbody>
                  <tr>
                      <td>Roberto Mock Santos</td>
                      <td>Produção</td>
                      <td>Líder</td>
                      <td>2026-04-10</td>
                      <td>2026-04-10</td>
                      <td><span class="status status-ativo">Ativo</span></td>
                      <td><button class="btn-sm btn-secondary">Ver Detalhes</button></td>
                  </tr>
                   <tr>
                      <td>Fernanda Mock Costa</td>
                      <td>Administrativo</td>
                      <td>Membro</td>
                      <td>2025-11-15</td>
                      <td>2025-11-15</td>
                       <td><span class="status status-ativo">Ativo</span></td>
                      <td><button class="btn-sm btn-secondary">Ver Detalhes</button></td>
                  </tr>
                  <!-- Mais linhas aqui -->
              </tbody>
          </table>
      </div>
    </div>

  </div>
</template>

<script setup>
// Lógica futura para buscar e gerenciar dados da Brigada
import { ref, onMounted } from 'vue';

const brigadistas = ref([]);
const loading = ref(false);

onMounted(async () => {
  // Lógica para carregar dados iniciais se necessário
});

</script>

<style scoped>
/* Reutilizar estilos comuns */
.brigada-view {
  padding: 1.5rem;
}

.page-title {
  margin-bottom: 1.5rem;
  color: var(--primary-color);
}

.content-card {
  background-color: var(--card-bg-color, #fff);
  padding: 1.5rem;
  border-radius: 8px;
  box-shadow: var(--card-shadow, 0 2px 4px rgba(0,0,0,0.1));
}

.content-card ul {
    margin-top: 1rem;
    margin-bottom: 1rem;
    padding-left: 20px;
}

.content-card li {
    margin-bottom: 0.5rem;
}

.placeholder-table {
    margin-top: 2rem;
    padding: 1rem;
    border-radius: 6px;
}

.placeholder-table h3 {
    margin-bottom: 1rem;
    color: var(--text-secondary-color);
}

/* Estilos básicos de tabela */
table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 1rem;
}

thead {
    background-color: var(--primary-color-light, #e0f7fa);
}

th, td {
    border: 1px solid var(--border-color, #dee2e6);
    padding: 0.75rem;
    text-align: left;
    font-size: 0.9rem;
}

th {
    font-weight: 600;
    color: var(--primary-color);
}

/* Estilos de Status (exemplo) */
.status {
    padding: 0.2rem 0.5rem;
    border-radius: 12px;
    font-size: 0.8rem;
    font-weight: 500;
    white-space: nowrap;
}

.status-ativo {
    background-color: rgba(40, 167, 69, 0.1);
    color: #198754; /* Verde */
}

.status-inativo {
    background-color: rgba(108, 117, 125, 0.1);
    color: #6c757d; /* Cinza */
}

/* Botões pequenos */
.btn-sm {
    padding: 0.25rem 0.5rem;
    font-size: 0.8rem;
    border-radius: 4px;
    cursor: pointer;
    border: none;
    transition: background-color 0.2s ease;
}

.btn-secondary {
    background-color: var(--text-secondary-color);
    color: white;
}

.btn-secondary:hover {
    background-color: #5a6268;
}
</style>
