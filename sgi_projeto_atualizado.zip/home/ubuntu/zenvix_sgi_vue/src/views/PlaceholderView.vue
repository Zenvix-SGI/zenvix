<template>
  <div class="placeholder-view">
    <h1><i class="fas fa-tools"></i> Página em Construção</h1>
    <p>Esta seção ({{ $route.name }}) ainda está sendo refatorada para a nova versão.</p>
    <p>Volte em breve!</p>
    <router-link to="/dashboard">Voltar para o Dashboard</router-link>
  </div>
</template>

<script setup>
// Nenhuma lógica específica necessária para o placeholder
</script>

<style scoped>
.placeholder-view {
  text-align: center;
  padding: 3rem;
  color: var(--text-secondary-color);
}

.placeholder-view h1 {
  color: var(--primary-color);
  margin-bottom: 1rem;
}

.placeholder-view h1 i {
  margin-right: 0.5rem;
}

.placeholder-view p {
  margin-bottom: 1.5rem;
}

.placeholder-view a {
  color: var(--primary-color);
  text-decoration: none;
  font-weight: 500;
}

.placeholder-view a:hover {
  text-decoration: underline;
}
</style>
