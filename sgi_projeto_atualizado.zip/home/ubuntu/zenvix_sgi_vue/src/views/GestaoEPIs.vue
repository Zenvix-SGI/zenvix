<template>
  <div class="gestao-epis-view">
    <h1 class="page-title">Gestão de EPIs</h1>
    
    
    <div class="content-card">
      <button @click="exportarPDF" class="export-btn">Exportar para PDF</button>
    
      <p>Este módulo permitirá o controle completo dos Equipamentos de Proteção Individual (EPIs).</p>
      <p>Funcionalidades planejadas:</p>
      <ul>
        <li>Cadastro de Tipos de EPIs (com CA, validade, etc.)</li>
        <li>Registro de Entrega de EPIs aos funcionários</li>
        <li>Controle de Validade do CA</li>
        <li>Geração de Ficha de EPI por funcionário</li>
        <li>Alertas de vencimento de CA</li>
        <li>Relatórios de consumo e entrega</li>
      </ul>
      <p><em>(Componente em desenvolvimento)</em></p>

      <!-- Exemplo de estrutura futura (Tabela de Entregas) -->
      <div class="table-container placeholder-table">
          <h3>Controle de Entregas (Exemplo)</h3>
          <table>
              <thead>
                  <tr>
                      <th>ID Entrega</th>
                      <th>Funcionário</th>
                      <th>EPI</th>
                      <th>CA</th>
                      <th>Data Entrega</th>
                      <th>Data Devolução</th>
                      <th>Status</th>
                      <th>Ações</th>
                  </tr>
              </thead>
              <tbody>
                  <tr>
                      <td>E001</td>
                      <td>João Mock Silva</td>
                      <td>Capacete Segurança</td>
                      <td>12345</td>
                      <td>2025-01-15</td>
                      <td>-</td>
                      <td><span class="status status-ativo">Ativo</span></td>
                      <td><button class="btn-sm btn-secondary">Ver Ficha</button></td>
                  </tr>
                   <tr>
                      <td>E002</td>
                      <td>Maria Mock Oliveira</td>
                      <td>Luva Nitrílica</td>
                      <td>67890</td>
                      <td>2025-03-10</td>
                      <td>-</td>
                       <td><span class="status status-ativo">Ativo</span></td>
                      <td><button class="btn-sm btn-secondary">Ver Ficha</button></td>
                  </tr>
                  <!-- Mais linhas aqui -->
              </tbody>
          </table>
      </div>
    </div>

  </div>
</template>

<script setup>
// Lógica futura para buscar e gerenciar dados de EPIs
import { ref, onMounted } from 'vue';
// import apiService from '../services/apiService'; // Descomentar quando implementar API

const entregas = ref([]);
const loading = ref(false);

onMounted(async () => {
  // loading.value = true;
  // try {
  //   entregas.value = await apiService.getEntregasEPI(); // Exemplo de chamada API
  // } catch (error) {
  //   console.error("Erro ao buscar entregas de EPIs:", error);
  //   // Tratar erro
  // } finally {
  //   loading.value = false;
  // }
});


import jsPDF from 'jspdf'
import html2canvas from 'html2canvas'

const exportarPDF = async () => {
  const input = document.querySelector('.table-container')
  const canvas = await html2canvas(input)
  const imgData = canvas.toDataURL('image/png')
  const pdf = new jsPDF()
  const imgProps = pdf.getImageProperties(imgData)
  const pdfWidth = pdf.internal.pageSize.getWidth()
  const pdfHeight = (imgProps.height * pdfWidth) / imgProps.width
  pdf.addImage(imgData, 'PNG', 0, 10, pdfWidth, pdfHeight)
  pdf.save('relatorio_epis.pdf')
}
</script>


<style scoped>
/* Reutilizar estilos comuns ou criar um CSS global para módulos */
.gestao-epis-view {
  padding: 1.5rem;
}

.page-title {
  margin-bottom: 1.5rem;
  color: var(--primary-color);
}

.content-card {
  background-color: var(--card-bg-color, #fff);
  padding: 1.5rem;
  border-radius: 8px;
  box-shadow: var(--card-shadow, 0 2px 4px rgba(0,0,0,0.1));
}

.content-card ul {
    margin-top: 1rem;
    margin-bottom: 1rem;
    padding-left: 20px;
}

.content-card li {
    margin-bottom: 0.5rem;
}

.placeholder-table {
    margin-top: 2rem;
    opacity: 0.7;
    border: 1px dashed var(--border-color);
    padding: 1rem;
    border-radius: 6px;
}

.placeholder-table h3 {
    margin-bottom: 1rem;
    color: var(--text-secondary-color);
}

/* Estilos básicos de tabela */
table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 1rem;
}

thead {
    background-color: var(--primary-color-light, #e0f7fa);
}

th, td {
    border: 1px solid var(--border-color, #dee2e6);
    padding: 0.75rem;
    text-align: left;
    font-size: 0.9rem;
}

th {
    font-weight: 600;
    color: var(--primary-color);
}

/* Estilos de Status (exemplo) */
.status {
    padding: 0.2rem 0.5rem;
    border-radius: 12px;
    font-size: 0.8rem;
    font-weight: 500;
    white-space: nowrap;
}

.status-ativo {
    background-color: rgba(40, 167, 69, 0.1);
    color: #198754; /* Cor verde mais escura */
}

.status-inativo {
    background-color: rgba(108, 117, 125, 0.1);
    color: #6c757d; /* Cinza */
}

.status-vencido {
    background-color: rgba(220, 53, 69, 0.1);
    color: #dc3545; /* Vermelho */
}

/* Botões pequenos */
.btn-sm {
    padding: 0.25rem 0.5rem;
    font-size: 0.8rem;
    border-radius: 4px;
    cursor: pointer;
    border: none;
    transition: background-color 0.2s ease;
}

.btn-secondary {
    background-color: var(--text-secondary-color);
    color: white;
}

.btn-secondary:hover {
    background-color: #5a6268;
}


.export-btn {
  background-color: #005566;
  color: white;
  border: none;
  padding: 10px 20px;
  margin: 10px 0;
  border-radius: 5px;
  cursor: pointer;
  font-weight: bold;
}
.export-btn:hover {
  background-color: #007799;
}
</style>

