<template>
  <div class="gestao-cipa-view">
    <h1 class="page-title">Gestão da CIPA</h1>
    
    <div class="content-card">
      <p>Este módulo auxiliará na gestão da Comissão Interna de Prevenção de Acidentes (CIPA).</p>
      <p>Funcionalidades planejadas:</p>
      <ul>
        <li>Cadastro de Membros da CIPA (eleitos, indicados, suplentes)</li>
        <li>Controle de Mandatos</li>
        <li>Registro de Reuniões e Atas</li>
        <li>Acompanhamento do Processo Eleitoral</li>
        <li>Plano de Trabalho da CIPA</li>
        <li>Relatórios de atividades da CIPA</li>
      </ul>
      <p><em>(Componente em desenvolvimento)</em></p>

      <!-- Exemplo de estrutura futura (Tabela de Membros) -->
      <div class="table-container placeholder-table">
          <h3>Membros da CIPA - Gestão 2025/2026 (Exemplo)</h3>
          <table>
              <thead>
                  <tr>
                      <th>Nome</th>
                      <th>Representação</th>
                      <th>Cargo (Presidente, Vice, etc.)</th>
                      <th>Início Mandato</th>
                      <th>Fim Mandato</th>
                      <th>Status</th>
                      <th>Ações</th>
                  </tr>
              </thead>
              <tbody>
                  <tr>
                      <td>Carlos Mock Souza</td>
                      <td>Empregador</td>
                      <td>Presidente</td>
                      <td>2025-03-01</td>
                      <td>2026-02-28</td>
                      <td><span class="status status-ativo">Ativo</span></td>
                      <td><button class="btn-sm btn-secondary">Ver Detalhes</button></td>
                  </tr>
                   <tr>
                      <td>Ana Mock Pereira</td>
                      <td>Empregados</td>
                      <td>Vice-Presidente</td>
                      <td>2025-03-01</td>
                      <td>2026-02-28</td>
                       <td><span class="status status-ativo">Ativo</span></td>
                      <td><button class="btn-sm btn-secondary">Ver Detalhes</button></td>
                  </tr>
                  <!-- Mais linhas aqui -->
              </tbody>
          </table>
      </div>
    </div>

  </div>
</template>

<script setup>
// Lógica futura para buscar e gerenciar dados da CIPA
import { ref, onMounted } from 'vue';
// import apiService from '../services/apiService'; // Descomentar quando implementar API

const membrosCipa = ref([]);
const loading = ref(false);

onMounted(async () => {
  // loading.value = true;
  // try {
  //   membrosCipa.value = await apiService.getMembrosCipa(); // Exemplo de chamada API
  // } catch (error) {
  //   console.error("Erro ao buscar membros da CIPA:", error);
  //   // Tratar erro
  // } finally {
  //   loading.value = false;
  // }
});

</script>

<style scoped>
/* Reutilizar estilos comuns */
.gestao-cipa-view {
  padding: 1.5rem;
}

.page-title {
  margin-bottom: 1.5rem;
  color: var(--primary-color);
}

.content-card {
  background-color: var(--card-bg-color, #fff);
  padding: 1.5rem;
  border-radius: 8px;
  box-shadow: var(--card-shadow, 0 2px 4px rgba(0,0,0,0.1));
}

.content-card ul {
    margin-top: 1rem;
    margin-bottom: 1rem;
    padding-left: 20px;
}

.content-card li {
    margin-bottom: 0.5rem;
}

.placeholder-table {
    margin-top: 2rem;
    opacity: 0.7;
    border: 1px dashed var(--border-color);
    padding: 1rem;
    border-radius: 6px;
}

.placeholder-table h3 {
    margin-bottom: 1rem;
    color: var(--text-secondary-color);
}

/* Estilos básicos de tabela */
table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 1rem;
}

thead {
    background-color: var(--primary-color-light, #e0f7fa);
}

th, td {
    border: 1px solid var(--border-color, #dee2e6);
    padding: 0.75rem;
    text-align: left;
    font-size: 0.9rem;
}

th {
    font-weight: 600;
    color: var(--primary-color);
}

/* Estilos de Status (exemplo) */
.status {
    padding: 0.2rem 0.5rem;
    border-radius: 12px;
    font-size: 0.8rem;
    font-weight: 500;
    white-space: nowrap;
}

.status-ativo {
    background-color: rgba(40, 167, 69, 0.1);
    color: #198754; /* Verde */
}

.status-inativo {
    background-color: rgba(108, 117, 125, 0.1);
    color: #6c757d; /* Cinza */
}

/* Botões pequenos */
.btn-sm {
    padding: 0.25rem 0.5rem;
    font-size: 0.8rem;
    border-radius: 4px;
    cursor: pointer;
    border: none;
    transition: background-color 0.2s ease;
}

.btn-secondary {
    background-color: var(--text-secondary-color);
    color: white;
}

.btn-secondary:hover {
    background-color: #5a6268;
}

</style>
