<template>
  <div class="not-found-page">
    <h1><i class="fas fa-exclamation-triangle"></i> 404 - Página Não Encontrada</h1>
    <p>Desculpe, a página que você está procurando não existe ou foi movida.</p>
    <router-link to="/dashboard">Voltar para o Dashboard</router-link>
    <span v-if="!isLoggedIn"> ou <router-link to="/login">Ir para o Login</router-link></span>
  </div>
</template>

<script setup>
import { computed } from 'vue';

// Simulação simples para verificar se o usuário está logado
// Idealmente, isso viria de um store de autenticação (Pinia/Vuex)
const isLoggedIn = computed(() => {
  // return !!localStorage.getItem('userToken'); // Exemplo
  // Para este exemplo, vamos assumir que se não estiver no /login, está logado
  // Esta lógica precisa ser refinada com o sistema de autenticação real
  return window.location.pathname !== '/login'; 
});
</script>

<style scoped>
.not-found-page {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  min-height: 80vh; /* Ajustar altura conforme necessário */
  text-align: center;
  padding: 2rem;
  color: var(--text-secondary-color);
}

.not-found-page h1 {
  color: var(--warning-color, #ffc107);
  margin-bottom: 1rem;
  font-size: 2rem;
}

.not-found-page h1 i {
  margin-right: 0.5rem;
}

.not-found-page p {
  margin-bottom: 1.5rem;
  font-size: 1.1rem;
}

.not-found-page a {
  color: var(--primary-color);
  text-decoration: none;
  font-weight: 500;
}

.not-found-page a:hover {
  text-decoration: underline;
}

.not-found-page span {
    margin-left: 0.5rem;
}
</style>
