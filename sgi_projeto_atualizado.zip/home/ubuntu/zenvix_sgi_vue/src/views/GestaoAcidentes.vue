<template>
  <div class="gestao-acidentes-view">
    <h1 class="page-title">Gestão de Acidentes (CAT)</h1>
    
    <div class="content-card">
      <p>Este módulo permitirá o registro, investigação e acompanhamento de acidentes de trabalho, incluindo a emissão da Comunicação de Acidente de Trabalho (CAT).</p>
      <p>Funcionalidades planejadas:</p>
      <ul>
        <li>Registro detalhado do acidente (data, hora, local, descrição, testemunhas)</li>
        <li>Informações do acidentado</li>
        <li>Dados do atendimento médico</li>
        <li>Análise e investigação das causas do acidente</li>
        <li>Plano de ação para prevenção de recorrências</li>
        <li>Geração da CAT para envio</li>
        <li>Relatórios e estatísticas de acidentes</li>
      </ul>
      <p><em>(Componente em desenvolvimento)</em></p>

      <!-- Exemplo de estrutura futura (Tabela de CATs) -->
      <div class="table-container placeholder-table">
          <h3>Comunicações de Acidente de Trabalho (Exemplo)</h3>
          <table>
              <thead>
                  <tr>
                      <th>Nº CAT</th>
                      <th>Acidentado</th>
                      <th>Data Acidente</th>
                      <th>Tipo</th>
                      <th>Status Investigação</th>
                      <th>Ações</th>
                  </tr>
              </thead>
              <tbody>
                  <tr>
                      <td>CAT-2025-001</td>
                      <td>João Mock Silva</td>
                      <td>2025-02-20</td>
                      <td>Típico</td>
                      <td><span class="status status-concluido">Concluída</span></td>
                      <td><button class="btn-sm btn-secondary">Ver Detalhes</button></td>
                  </tr>
                   <tr>
                      <td>CAT-2025-002</td>
                      <td>Maria Mock Oliveira</td>
                      <td>2025-04-05</td>
                      <td>Trajeto</td>
                      <td><span class="status status-pendente">Pendente</span></td>
                      <td><button class="btn-sm btn-secondary">Ver Detalhes</button></td>
                  </tr>
                  <!-- Mais linhas aqui -->
              </tbody>
          </table>
      </div>
    </div>

  </div>
</template>

<script setup>
// Lógica futura para buscar e gerenciar dados de acidentes/CATs
import { ref, onMounted } from 'vue';
// import apiService from '../services/apiService'; // Descomentar quando implementar API

const cats = ref([]);
const loading = ref(false);

onMounted(async () => {
  // loading.value = true;
  // try {
  //   cats.value = await apiService.getCats(); // Exemplo de chamada API
  // } catch (error) {
  //   console.error("Erro ao buscar CATs:", error);
  //   // Tratar erro
  // } finally {
  //   loading.value = false;
  // }
});

</script>

<style scoped>
/* Reutilizar estilos comuns */
.gestao-acidentes-view {
  padding: 1.5rem;
}

.page-title {
  margin-bottom: 1.5rem;
  color: var(--primary-color);
}

.content-card {
  background-color: var(--card-bg-color, #fff);
  padding: 1.5rem;
  border-radius: 8px;
  box-shadow: var(--card-shadow, 0 2px 4px rgba(0,0,0,0.1));
}

.content-card ul {
    margin-top: 1rem;
    margin-bottom: 1rem;
    padding-left: 20px;
}

.content-card li {
    margin-bottom: 0.5rem;
}

.placeholder-table {
    margin-top: 2rem;
    opacity: 0.7;
    border: 1px dashed var(--border-color);
    padding: 1rem;
    border-radius: 6px;
}

.placeholder-table h3 {
    margin-bottom: 1rem;
    color: var(--text-secondary-color);
}

/* Estilos básicos de tabela */
table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 1rem;
}

thead {
    background-color: var(--primary-color-light, #e0f7fa);
}

th, td {
    border: 1px solid var(--border-color, #dee2e6);
    padding: 0.75rem;
    text-align: left;
    font-size: 0.9rem;
}

th {
    font-weight: 600;
    color: var(--primary-color);
}

/* Estilos de Status (exemplo) */
.status {
    padding: 0.2rem 0.5rem;
    border-radius: 12px;
    font-size: 0.8rem;
    font-weight: 500;
    white-space: nowrap;
}

.status-concluido {
    background-color: rgba(40, 167, 69, 0.1);
    color: #198754; /* Verde */
}

.status-pendente {
    background-color: rgba(255, 193, 7, 0.1);
    color: #ffc107; /* Amarelo */
}

/* Botões pequenos */
.btn-sm {
    padding: 0.25rem 0.5rem;
    font-size: 0.8rem;
    border-radius: 4px;
    cursor: pointer;
    border: none;
    transition: background-color 0.2s ease;
}

.btn-secondary {
    background-color: var(--text-secondary-color);
    color: white;
}

.btn-secondary:hover {
    background-color: #5a6268;
}

</style>
