<template>
  <div class="funcionarios-view">
    <h1 class="page-title">Gestão de Funcionários</h1>
    
    <div class="content-card">
      <p>Este módulo permitirá o cadastro e gerenciamento completo dos dados dos funcionários.</p>
      <p>Funcionalidades planejadas:</p>
      <ul>
        <li>Cadastro de Dados Pessoais e Contratuais</li>
        <li>Histórico Funcional</li>
        <li>Associação com Exames, Treinamentos, EPIs</li>
        <li>Controle de Férias e Afastamentos (simplificado)</li>
        <li>Busca e Filtros</li>
      </ul>
      <p><em>(Página funcional - Conteúdo detalhado a ser implementado)</em></p>

      <!-- Exemplo de estrutura futura (Tabela de Funcionários) -->
      <div class="table-container placeholder-table">
          <h3>Lista de Funcionários (Exemplo)</h3>
          <table>
              <thead>
                  <tr>
                      <th>Matrícula</th>
                      <th>Nome Completo</th>
                      <th>Cargo</th>
                      <th>Setor</th>
                      <th>Status</th>
                      <th>Ações</th>
                  </tr>
              </thead>
              <tbody>
                  <tr>
                      <td>1001</td>
                      <td>João Mock Silva</td>
                      <td>Mecânico</td>
                      <td>Manutenção</td>
                      <td><span class="status status-ativo">Ativo</span></td>
                      <td><button class="btn-sm btn-secondary">Ver Perfil</button></td>
                  </tr>
                   <tr>
                      <td>1002</td>
                      <td>Maria Mock Oliveira</td>
                      <td>Analista RH</td>
                      <td>Recursos Humanos</td>
                       <td><span class="status status-ativo">Ativo</span></td>
                      <td><button class="btn-sm btn-secondary">Ver Perfil</button></td>
                  </tr>
                  <!-- Mais linhas aqui -->
              </tbody>
          </table>
      </div>
    </div>

  </div>
</template>

<script setup>
// Lógica futura para buscar e gerenciar dados de funcionários
import { ref, onMounted } from 'vue';

const funcionarios = ref([]);
const loading = ref(false);

onMounted(async () => {
  // Lógica para carregar dados iniciais se necessário
});

</script>

<style scoped>
/* Reutilizar estilos comuns de outras views */
.funcionarios-view {
  padding: 1.5rem;
}

.page-title {
  margin-bottom: 1.5rem;
  color: var(--primary-color);
}

.content-card {
  background-color: var(--card-bg-color, #fff);
  padding: 1.5rem;
  border-radius: 8px;
  box-shadow: var(--card-shadow, 0 2px 4px rgba(0,0,0,0.1));
}

.content-card ul {
    margin-top: 1rem;
    margin-bottom: 1rem;
    padding-left: 20px;
}

.content-card li {
    margin-bottom: 0.5rem;
}

.placeholder-table {
    margin-top: 2rem;
    /* opacity: 0.7; */ /* Remover opacidade para tabela real */
    /* border: 1px dashed var(--border-color); */ /* Remover borda tracejada */
    padding: 1rem;
    border-radius: 6px;
}

.placeholder-table h3 {
    margin-bottom: 1rem;
    color: var(--text-secondary-color);
}

/* Estilos básicos de tabela */
table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 1rem;
}

thead {
    background-color: var(--primary-color-light, #e0f7fa);
}

th, td {
    border: 1px solid var(--border-color, #dee2e6);
    padding: 0.75rem;
    text-align: left;
    font-size: 0.9rem;
}

th {
    font-weight: 600;
    color: var(--primary-color);
}

/* Estilos de Status (exemplo) */
.status {
    padding: 0.2rem 0.5rem;
    border-radius: 12px;
    font-size: 0.8rem;
    font-weight: 500;
    white-space: nowrap;
}

.status-ativo {
    background-color: rgba(40, 167, 69, 0.1);
    color: #198754; /* Verde */
}

.status-inativo {
    background-color: rgba(108, 117, 125, 0.1);
    color: #6c757d; /* Cinza */
}

/* Botões pequenos */
.btn-sm {
    padding: 0.25rem 0.5rem;
    font-size: 0.8rem;
    border-radius: 4px;
    cursor: pointer;
    border: none;
    transition: background-color 0.2s ease;
}

.btn-secondary {
    background-color: var(--text-secondary-color);
    color: white;
}

.btn-secondary:hover {
    background-color: #5a6268;
}
</style>
