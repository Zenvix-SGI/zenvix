<template>
  <div class="exames-view">
    <h1 class="page-title">Gestão de Exames Ocupacionais</h1>
    
    <div class="content-card">
      <p>Este módulo permitirá o controle dos exames médicos ocupacionais (ASO - Atestado de Saúde Ocupacional).</p>
      <p>Funcionalidades planejadas:</p>
      <ul>
        <li>Cadastro de Tipos de Exame (Admissional, Periódico, Demissional, etc.)</li>
        <li>Agendamento de Exames</li>
        <li>Registro de Resultados e Aptidão</li>
        <li>Controle de Vencimento do ASO</li>
        <li>Integração com PCMSO (Programa de Controle Médico de Saúde Ocupacional)</li>
        <li>Alertas de exames vencendo</li>
        <li>Relatórios de exames realizados e vencimentos</li>
      </ul>
      <p><em>(Página funcional - Conteúdo detalhado a ser implementado)</em></p>

      <!-- Exemplo de estrutura futura (Tabela de ASOs) -->
      <div class="table-container placeholder-table">
          <h3>Controle de ASOs (Exemplo)</h3>
          <table>
              <thead>
                  <tr>
                      <th>ID ASO</th>
                      <th>Funcionário</th>
                      <th>Tipo Exame</th>
                      <th>Data Exame</th>
                      <th>Data Vencimento</th>
                      <th>Resultado</th>
                      <th>Ações</th>
                  </tr>
              </thead>
              <tbody>
                  <tr>
                      <td>ASO-001</td>
                      <td>João Mock Silva</td>
                      <td>Periódico</td>
                      <td>2025-01-10</td>
                      <td>2026-01-10</td>
                      <td><span class="status status-apto">Apto</span></td>
                      <td><button class="btn-sm btn-secondary">Ver ASO</button></td>
                  </tr>
                   <tr>
                      <td>ASO-002</td>
                      <td>Maria Mock Oliveira</td>
                      <td>Admissional</td>
                      <td>2025-03-01</td>
                      <td>2026-03-01</td>
                       <td><span class="status status-apto">Apto</span></td>
                      <td><button class="btn-sm btn-secondary">Ver ASO</button></td>
                  </tr>
                  <!-- Mais linhas aqui -->
              </tbody>
          </table>
      </div>
    </div>

  </div>
</template>

<script setup>
// Lógica futura para buscar e gerenciar dados de exames/ASOs
import { ref, onMounted } from 'vue';

const asos = ref([]);
const loading = ref(false);

onMounted(async () => {
  // Lógica para carregar dados iniciais se necessário
});

</script>

<style scoped>
/* Reutilizar estilos comuns */
.exames-view {
  padding: 1.5rem;
}

.page-title {
  margin-bottom: 1.5rem;
  color: var(--primary-color);
}

.content-card {
  background-color: var(--card-bg-color, #fff);
  padding: 1.5rem;
  border-radius: 8px;
  box-shadow: var(--card-shadow, 0 2px 4px rgba(0,0,0,0.1));
}

.content-card ul {
    margin-top: 1rem;
    margin-bottom: 1rem;
    padding-left: 20px;
}

.content-card li {
    margin-bottom: 0.5rem;
}

.placeholder-table {
    margin-top: 2rem;
    padding: 1rem;
    border-radius: 6px;
}

.placeholder-table h3 {
    margin-bottom: 1rem;
    color: var(--text-secondary-color);
}

/* Estilos básicos de tabela */
table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 1rem;
}

thead {
    background-color: var(--primary-color-light, #e0f7fa);
}

th, td {
    border: 1px solid var(--border-color, #dee2e6);
    padding: 0.75rem;
    text-align: left;
    font-size: 0.9rem;
}

th {
    font-weight: 600;
    color: var(--primary-color);
}

/* Estilos de Status (exemplo) */
.status {
    padding: 0.2rem 0.5rem;
    border-radius: 12px;
    font-size: 0.8rem;
    font-weight: 500;
    white-space: nowrap;
}

.status-apto {
    background-color: rgba(40, 167, 69, 0.1);
    color: #198754; /* Verde */
}

.status-inapto {
    background-color: rgba(220, 53, 69, 0.1);
    color: #dc3545; /* Vermelho */
}

/* Botões pequenos */
.btn-sm {
    padding: 0.25rem 0.5rem;
    font-size: 0.8rem;
    border-radius: 4px;
    cursor: pointer;
    border: none;
    transition: background-color 0.2s ease;
}

.btn-secondary {
    background-color: var(--text-secondary-color);
    color: white;
}

.btn-secondary:hover {
    background-color: #5a6268;
}
</style>
