<template>
  <div class="integracao-esocial-view">
    <h1 class="page-title">Integração eSocial SST</h1>
    
    <div class="content-card">
      <p>Este módulo facilitará a geração e o gerenciamento dos eventos de Saúde e Segurança no Trabalho (SST) para o eSocial.</p>
      <p>Funcionalidades planejadas:</p>
      <ul>
        <li>Geração do evento S-2210 (Comunicação de Acidente de Trabalho) a partir dos registros de CAT.</li>
        <li>Geração do evento S-2220 (Monitoramento da Saúde do Trabalhador) a partir dos registros de ASO/Exames.</li>
        <li>Geração do evento S-2240 (Condições Ambientais do Trabalho - Agentes Nocivos) a partir do PGR/LTCAT.</li>
        <li>Gerenciamento do status de envio dos eventos.</li>
        <li>Histórico de envios e recibos.</li>
        <li>Validações pré-envio.</li>
      </ul>
      <p><em>(Componente em desenvolvimento - Requer integração complexa com sistema de folha/contabilidade ou API do governo)</em></p>

      <!-- Exemplo de estrutura futura (Tabela de Eventos Pendentes) -->
      <div class="table-container placeholder-table">
          <h3>Eventos eSocial Pendentes (Exemplo)</h3>
          <table>
              <thead>
                  <tr>
                      <th>ID Evento</th>
                      <th>Tipo Evento</th>
                      <th>Funcionário</th>
                      <th>Data Fato Gerador</th>
                      <th>Status</th>
                      <th>Ações</th>
                  </tr>
              </thead>
              <tbody>
                  <tr>
                      <td>ES2210-001</td>
                      <td>S-2210 (CAT)</td>
                      <td>João Mock Silva</td>
                      <td>2025-02-20</td>
                      <td><span class="status status-pendente">Pendente Geração</span></td>
                      <td><button class="btn-sm btn-primary">Gerar XML</button></td>
                  </tr>
                   <tr>
                      <td>ES2220-005</td>
                      <td>S-2220 (ASO)</td>
                      <td>Maria Mock Oliveira</td>
                      <td>2025-05-15</td>
                       <td><span class="status status-gerado">XML Gerado</span></td>
                      <td><button class="btn-sm btn-secondary">Enviar</button> <button class="btn-sm btn-info">Ver XML</button></td>
                  </tr>
                   <tr>
                      <td>ES2240-012</td>
                      <td>S-2240 (Agentes Nocivos)</td>
                      <td>Carlos Mock Souza</td>
                      <td>2025-01-01</td>
                       <td><span class="status status-enviado">Enviado</span></td>
                      <td><button class="btn-sm btn-success">Ver Recibo</button></td>
                  </tr>
                  <!-- Mais linhas aqui -->
              </tbody>
          </table>
      </div>
    </div>

  </div>
</template>

<script setup>
// Lógica futura para gerar e gerenciar eventos eSocial
import { ref, onMounted } from 'vue';
// import apiService from '../services/apiService'; // Descomentar quando implementar API

const eventosEsocial = ref([]);
const loading = ref(false);

onMounted(async () => {
  // loading.value = true;
  // try {
  //   eventosEsocial.value = await apiService.getEventosEsocialPendentes(); // Exemplo
  // } catch (error) {
  //   console.error("Erro ao buscar eventos eSocial:", error);
  //   // Tratar erro
  // } finally {
  //   loading.value = false;
  // }
});

</script>

<style scoped>
/* Reutilizar estilos comuns */
.integracao-esocial-view {
  padding: 1.5rem;
}

.page-title {
  margin-bottom: 1.5rem;
  color: var(--primary-color);
}

.content-card {
  background-color: var(--card-bg-color, #fff);
  padding: 1.5rem;
  border-radius: 8px;
  box-shadow: var(--card-shadow, 0 2px 4px rgba(0,0,0,0.1));
}

.content-card ul {
    margin-top: 1rem;
    margin-bottom: 1rem;
    padding-left: 20px;
}

.content-card li {
    margin-bottom: 0.5rem;
}

.placeholder-table {
    margin-top: 2rem;
    opacity: 0.7;
    border: 1px dashed var(--border-color);
    padding: 1rem;
    border-radius: 6px;
}

.placeholder-table h3 {
    margin-bottom: 1rem;
    color: var(--text-secondary-color);
}

/* Estilos básicos de tabela */
table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 1rem;
}

thead {
    background-color: var(--primary-color-light, #e0f7fa);
}

th, td {
    border: 1px solid var(--border-color, #dee2e6);
    padding: 0.75rem;
    text-align: left;
    font-size: 0.9rem;
}

th {
    font-weight: 600;
    color: var(--primary-color);
}

/* Estilos de Status (exemplo) */
.status {
    padding: 0.2rem 0.5rem;
    border-radius: 12px;
    font-size: 0.8rem;
    font-weight: 500;
    white-space: nowrap;
}

.status-pendente {
    background-color: rgba(255, 193, 7, 0.1);
    color: #ffc107; /* Amarelo */
}

.status-gerado {
    background-color: rgba(13, 202, 240, 0.1);
    color: #0dcaf0; /* Info/Azul Claro */
}

.status-enviado {
    background-color: rgba(40, 167, 69, 0.1);
    color: #198754; /* Verde */
}

.status-erro {
    background-color: rgba(220, 53, 69, 0.1);
    color: #dc3545; /* Vermelho */
}

/* Botões pequenos */
.btn-sm {
    padding: 0.25rem 0.5rem;
    font-size: 0.8rem;
    border-radius: 4px;
    cursor: pointer;
    border: none;
    transition: background-color 0.2s ease;
    margin-right: 0.3rem; /* Espaço entre botões */
}

.btn-primary {
    background-color: var(--primary-color);
    color: white;
}
.btn-primary:hover {
    background-color: var(--secondary-color);
}

.btn-secondary {
    background-color: var(--text-secondary-color);
    color: white;
}
.btn-secondary:hover {
    background-color: #5a6268;
}

.btn-info {
    background-color: #0dcaf0;
    color: white;
}
.btn-info:hover {
    background-color: #31d2f2;
}

.btn-success {
    background-color: #198754;
    color: white;
}
.btn-success:hover {
    background-color: #157347;
}

</style>
