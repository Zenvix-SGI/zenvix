// src/services/authService.js

const AUTH_TOKEN_KEY = 'authToken';
const USER_DATA_KEY = 'userData'; // Chave para guardar dados do usuário

/**
 * Simula o processo de login.
 * Em um cenário real, faria uma chamada API para validar as credenciais.
 * @param {string} username
 * @param {string} password
 * @returns {Promise<object>} Resolve com dados do usuário simulados em caso de sucesso.
 * @throws {Error} Rejeita com erro em caso de falha.
 */
export const login = async (username, password) => {
  console.log(`[AuthService] Tentando login para: ${username}`);
  // Simulação de validação de credenciais
  if (username === 'admin' && password === 'password') {
    // Simula um token recebido do backend
    const mockToken = `mock-token-${Date.now()}`;
    localStorage.setItem(AUTH_TOKEN_KEY, mockToken);

    // Guarda dados básicos do usuário (simulado)
    const userData = { username: username, name: 'Administrador Mock', role: 'Admin' };
    localStorage.setItem(USER_DATA_KEY, JSON.stringify(userData)); 

    console.log('[AuthService] Login bem-sucedido, token e dados do usuário salvos:', mockToken, userData);
    return userData; // Retorna os dados do usuário
  } else {
    console.log('[AuthService] Credenciais inválidas.');
    throw new Error('Usuário ou senha inválidos.');
  }
};

/**
 * Realiza o logout do usuário.
 */
export const logout = () => {
  localStorage.removeItem(AUTH_TOKEN_KEY);
  localStorage.removeItem(USER_DATA_KEY); // Remove dados do usuário ao sair
  console.log('[AuthService] Logout realizado, token e dados do usuário removidos.');
};

/**
 * Verifica se o usuário está autenticado.
 * @returns {boolean} True se autenticado, false caso contrário.
 */
export const isAuthenticated = () => {
  const token = localStorage.getItem(AUTH_TOKEN_KEY);
  return !!token; // Retorna true se o token existir e não for vazio
};

/**
 * Obtém o token de autenticação atual (se existir).
 * @returns {string|null} O token ou null.
 */
export const getToken = () => {
  return localStorage.getItem(AUTH_TOKEN_KEY);
};

/**
 * Obtém os dados do usuário armazenados (se existirem).
 * @returns {object|null} Objeto com dados do usuário ou null.
 */
export const getUserData = () => {
  const userDataString = localStorage.getItem(USER_DATA_KEY);
  if (userDataString) {
    try {
      return JSON.parse(userDataString);
    } catch (error) {
      console.error('[AuthService] Erro ao parsear dados do usuário:', error);
      // Limpar dados inválidos
      localStorage.removeItem(USER_DATA_KEY);
      return null;
    }
  } else {
    return null;
  }
};

