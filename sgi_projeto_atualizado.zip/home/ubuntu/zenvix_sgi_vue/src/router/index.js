import { createRouter, createWebHistory } from 'vue-router';
import AppLayout from '../layouts/AppLayout.vue';
import Login from '../views/Login.vue';
import Dashboard from '../views/Dashboard.vue';
// Importar views dos módulos SST
import GestaoRiscos from '../views/GestaoRiscos.vue';
import GestaoEPIs from '../views/GestaoEPIs.vue';
import GestaoAcidentes from '../views/GestaoAcidentes.vue';
import GestaoTreinamentos from '../views/GestaoTreinamentos.vue';
import GestaoDocumentos from '../views/GestaoDocumentos.vue';
import GestaoCIPA from '../views/GestaoCIPA.vue';
import IntegracaoEsocial from '../views/IntegracaoEsocial.vue';
// Importar views dos módulos principais
import Funcionarios from '../views/Funcionarios.vue';
import Empresas from '../views/Empresas.vue';
import Exames from '../views/Exames.vue';
import Relatorios from '../views/Relatorios.vue';
import Auditoria from '../views/Auditoria.vue';
import Brigada from '../views/Brigada.vue';
// Importar NotFound
import NotFound from '../views/NotFound.vue';
// Importar serviço de autenticação
import { isAuthenticated } from '../services/authService';

const routes = [
  {
    path: '/login',
    name: 'Login',
    component: Login,
    meta: { requiresGuest: true } // Rota para usuários não autenticados
  },
  {
    path: '/',
    component: AppLayout, // Layout principal para rotas autenticadas
    meta: { requiresAuth: true }, // Proteger todas as rotas filhas
    children: [
      {
        path: '',
        redirect: '/dashboard' // Redireciona a raiz para o dashboard
      },
      {
        path: 'dashboard',
        name: 'Dashboard',
        component: Dashboard
      },
      // Rotas para módulos principais agora funcionais
      {
        path: 'funcionarios',
        name: 'Funcionarios',
        component: Funcionarios 
      },
      {
        path: 'empresas',
        name: 'Empresas',
        component: Empresas
      },
       {
        path: 'exames',
        name: 'Exames',
        component: Exames
      },
       {
        path: 'relatorios',
        name: 'Relatorios',
        component: Relatorios
      },
       {
        path: 'auditoria',
        name: 'Auditoria',
        component: Auditoria
      },
       {
        path: 'brigada',
        name: 'Brigada',
        component: Brigada
      },
      // Rotas para módulos SST implementados
       {
        path: 'treinamentos',
        name: 'Treinamentos',
        component: GestaoTreinamentos
      },
       {
        path: 'epis',
        name: 'Epis',
        component: GestaoEPIs
      },
       {
        path: 'documentos',
        name: 'Documentos',
        component: GestaoDocumentos
      },
       {
        path: 'esocial',
        name: 'Esocial',
        component: IntegracaoEsocial
      },
       {
        path: 'cipa',
        name: 'Cipa',
        component: GestaoCIPA
      },
       {
        path: 'riscos',
        name: 'Riscos',
        component: GestaoRiscos // Rota para PGR
      },
       {
        path: 'acidentes',
        name: 'Acidentes',
        component: GestaoAcidentes // Rota para CAT
      },
      // Rota catch-all para páginas não encontradas dentro do layout
      {
        path: ':pathMatch(.*)*',
        name: 'NotFoundInApp',
        component: NotFound 
      }
    ]
  },
   // Rota catch-all global (fora do layout principal)
   {
    path: '/:pathMatch(.*)*',
    name: 'NotFoundGlobal',
    component: NotFound 
  }
];

const router = createRouter({
  history: createWebHistory(),
  routes,
  linkActiveClass: 'active', // Classe padrão para links ativos
  scrollBehavior(to, from, savedPosition) {
    if (savedPosition) {
      return savedPosition;
    } else {
      return { top: 0 };
    }
  },
});

// Navigation Guard (Controle de Acesso)
router.beforeEach((to, from, next) => {
  const requiresAuth = to.matched.some(record => record.meta.requiresAuth);
  const requiresGuest = to.matched.some(record => record.meta.requiresGuest);
  const authenticated = isAuthenticated(); // Usar a função real do authService

  console.log(`Navegando para: ${to.path}, Requer Auth: ${requiresAuth}, Requer Guest: ${requiresGuest}, Autenticado: ${authenticated}`);

  if (requiresAuth && !authenticated) {
    // Se a rota exige autenticação e o usuário não está autenticado, redireciona para login
    console.log('Redirecionando para /login (não autenticado)');
    next({ name: 'Login' });
  } else if (requiresGuest && authenticated) {
    // Se a rota é para convidados (login) e o usuário já está autenticado, redireciona para dashboard
    console.log('Redirecionando para /dashboard (já autenticado)');
    next({ name: 'Dashboard' });
  } else {
    // Caso contrário, permite a navegação
    console.log('Permitindo navegação');
    next();
  }
});

export default router;
