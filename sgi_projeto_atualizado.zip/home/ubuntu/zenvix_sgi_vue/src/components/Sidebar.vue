<template>
  <aside class="sidebar" :class="{ 'is-collapsed': isCollapsed, 'is-mobile': isMobile }" @transitionend="onTransitionEnd">
    <div class="sidebar-header">
      <h2 v-if="!isCollapsed"><i class="fas fa-shield-alt"></i> ZENVIX SGI</h2>
      <h2 v-else><i class="fas fa-shield-alt"></i></h2>
      <!-- Botão Desktop -->
      <button v-if="!isMobile" @click="toggleSidebar" class="sidebar-toggle-desktop" aria-label="Toggle Sidebar">
        <i :class="['fas', isCollapsed ? 'fa-chevron-right' : 'fa-chevron-left']"></i>
      </button>
       <!-- Botão Fechar Mobile -->
      <button v-if="isMobile" @click="closeMobileSidebar" class="sidebar-close-mobile" aria-label="Fechar Menu">
          <i class="fas fa-times"></i>
      </button>
    </div>
    <nav>
      <ul class="sidebar-menu">
        <li>
          <router-link to="/dashboard" active-class="active">
            <i class="fas fa-tachometer-alt"></i> 
            <span class="menu-text" v-if="!isCollapsed">Dashboard</span>
          </router-link>
        </li>
        <li>
          <router-link to="/funcionarios" active-class="active">
            <i class="fas fa-users"></i> 
            <span class="menu-text" v-if="!isCollapsed">Funcionários</span>
          </router-link>
        </li>
        <li>
          <router-link to="/empresas" active-class="active">
            <i class="fas fa-building"></i> 
            <span class="menu-text" v-if="!isCollapsed">Empresas</span>
          </router-link>
        </li>
        <li>
          <router-link to="/exames" active-class="active">
            <i class="fas fa-stethoscope"></i> 
            <span class="menu-text" v-if="!isCollapsed">Exames</span>
          </router-link>
        </li>
        <li>
          <router-link to="/treinamentos" active-class="active">
            <i class="fas fa-chalkboard-teacher"></i> 
            <span class="menu-text" v-if="!isCollapsed">Treinamentos</span>
          </router-link>
        </li>
        <li>
          <router-link to="/epis" active-class="active">
            <i class="fas fa-hard-hat"></i> 
            <span class="menu-text" v-if="!isCollapsed">EPIs</span>
          </router-link>
        </li>
        <li>
          <router-link to="/documentos" active-class="active">
            <i class="fas fa-file-alt"></i> 
            <span class="menu-text" v-if="!isCollapsed">Documentos</span>
          </router-link>
        </li>
        <li>
          <router-link to="/relatorios" active-class="active">
            <i class="fas fa-chart-bar"></i> 
            <span class="menu-text" v-if="!isCollapsed">Relatórios</span>
          </router-link>
        </li>
        
        <li class="sidebar-section-title" :class="{ 'is-collapsed': isCollapsed }">
            <span v-if="!isCollapsed">Módulos SST</span>
            <i v-else class="fas fa-heartbeat"></i> <!-- Ícone alternativo para colapsado -->
        </li>

        <li>
          <router-link to="/esocial" active-class="active">
            <i class="fas fa-file-invoice"></i> 
            <span class="menu-text" v-if="!isCollapsed">e-Social</span>
          </router-link>
        </li>
        <li>
          <router-link to="/cipa" active-class="active">
            <i class="fas fa-users-cog"></i> 
            <span class="menu-text" v-if="!isCollapsed">CIPA</span>
          </router-link>
        </li>
        <li>
          <router-link to="/auditoria" active-class="active">
            <i class="fas fa-clipboard-check"></i> 
            <span class="menu-text" v-if="!isCollapsed">Auditoria</span>
          </router-link>
        </li>
        <li>
          <router-link to="/riscos" active-class="active">
            <i class="fas fa-exclamation-triangle"></i> 
            <span class="menu-text" v-if="!isCollapsed">Gestão de Riscos</span> <!-- Nome atualizado -->
          </router-link>
        </li>
        <li>
          <router-link to="/acidentes" active-class="active">
            <i class="fas fa-first-aid"></i> 
            <span class="menu-text" v-if="!isCollapsed">Gestão de Acidentes</span> <!-- Nome atualizado -->
          </router-link>
        </li>
        <li>
          <router-link to="/brigada" active-class="active">
            <i class="fas fa-fire-extinguisher"></i> 
            <span class="menu-text" v-if="!isCollapsed">Brigada</span>
          </router-link>
        </li>
      </ul>
    </nav>
    <div class="logout-link">
      <a href="#" @click.prevent="handleLogout">
        <i class="fas fa-sign-out-alt"></i> 
        <span class="menu-text" v-if="!isCollapsed">Sair</span>
      </a>
    </div>
  </aside>
</template>

<script setup>
import { ref, onMounted, defineProps, defineEmits } from 'vue';
import { useRouter } from 'vue-router'; // Importar useRouter
import { logout } from '../services/authService'; // Importar logout

const props = defineProps({
  isMobile: {
    type: Boolean,
    default: false
  }
});

const emit = defineEmits(['close']);

const isCollapsed = ref(false);
const isTransitioning = ref(false);
const router = useRouter(); // Inicializar router

const toggleSidebar = () => {
  isTransitioning.value = true;
  isCollapsed.value = !isCollapsed.value;
  localStorage.setItem('sidebarCollapsed', isCollapsed.value);
};

const closeMobileSidebar = () => {
    emit('close');
};

const handleLogout = () => { // Não precisa ser async se logout for síncrono
  try {
    logout(); // Chamar a função de logout do authService
    router.push('/login'); // Redirecionar para a página de login
  } catch (error) {
    console.error('Erro no logout:', error);
    // Opcional: Mostrar notificação de erro ao usuário
  }
};

const onTransitionEnd = () => {
    isTransitioning.value = false;
};

onMounted(() => {
  if (!props.isMobile) {
      const savedState = localStorage.getItem('sidebarCollapsed');
      if (savedState !== null) {
        isCollapsed.value = JSON.parse(savedState);
      }
  }
});

</script>

<style scoped>
/* --- Variáveis (podem vir de um arquivo global) --- */
:root {
    --sidebar-width: 260px;
    --sidebar-width-collapsed: 75px;
    --sidebar-transition-duration: 0.35s;
    --sidebar-transition-timing: cubic-bezier(0.4, 0, 0.2, 1); /* Material Design standard curve */
}

/* --- Estilos Base --- */
.sidebar {
  width: var(--sidebar-width);
  background-color: var(--sidebar-bg-color, #ffffff);
  height: 100vh;
  position: fixed;
  left: 0;
  top: 0;
  display: flex;
  flex-direction: column;
  transition: width var(--sidebar-transition-duration) var(--sidebar-transition-timing);
  z-index: 1000;
  box-shadow: 2px 0 10px rgba(0, 0, 0, 0.1);
  overflow: hidden; /* Evita que conteúdo vaze durante a transição */
}

.sidebar.is-collapsed {
  width: var(--sidebar-width-collapsed);
}

/* --- Header --- */
.sidebar-header {
  padding: 1rem;
  display: flex; /* Usar flex para alinhar itens */
  align-items: center;
  justify-content: space-between; /* Espaçar logo/título e botão */
  border-bottom: 1px solid var(--border-color, #e9ecef);
  position: relative;
  height: 60px; /* Altura fixa para consistência */
  box-sizing: border-box;
}

.sidebar-header h2 {
  margin: 0;
  color: var(--primary-color, #005f73);
  font-size: 1.3rem;
  font-weight: 600;
  white-space: nowrap;
  overflow: hidden;
  display: flex;
  align-items: center;
  gap: 10px; /* Espaço entre ícone e texto */
  transition: opacity 0.2s ease-in-out;
}

.sidebar.is-collapsed .sidebar-header h2 {
    /* Oculta o texto, mantém o ícone */
    opacity: 0; /* Esconde o H2 inteiro para evitar reflow */
    width: 0;
}

.sidebar.is-collapsed .sidebar-header h2 i {
    /* Garante que o ícone ainda seja visível quando colapsado (se o H2 não for escondido) */
    margin-right: 0;
}

/* --- Botões de Toggle/Close --- */
.sidebar-toggle-desktop, .sidebar-close-mobile {
  background-color: transparent;
  border: none;
  color: var(--text-secondary-color, #6c757d);
  font-size: 1.2rem;
  cursor: pointer;
  padding: 5px;
  border-radius: 4px;
  transition: color 0.2s ease, background-color 0.2s ease;
  display: flex;
  align-items: center;
  justify-content: center;
}

.sidebar-toggle-desktop:hover, .sidebar-close-mobile:hover {
    color: var(--primary-color, #005f73);
    background-color: var(--primary-color-light, #e0f7fa);
}

.sidebar-toggle-desktop i {
    transition: transform var(--sidebar-transition-duration) var(--sidebar-transition-timing);
}

/* Não precisa mais rotacionar o chevron, ele troca */
/* .sidebar.is-collapsed .sidebar-toggle-desktop i {
  transform: rotate(180deg);
} */

.sidebar-close-mobile {
    /* Estilos específicos se necessário */
}

/* --- Navegação --- */
nav {
  flex-grow: 1;
  overflow-y: auto;
  overflow-x: hidden; /* Importante para esconder texto durante colapso */
  padding-top: 0.5rem;
  /* Estilização da barra de rolagem */
  scrollbar-width: thin; /* Firefox */
  scrollbar-color: var(--primary-color-light, #e0f7fa) transparent; /* Firefox */
}

nav::-webkit-scrollbar {
  width: 6px;
}

nav::-webkit-scrollbar-track {
  background: transparent;
}

nav::-webkit-scrollbar-thumb {
  background-color: var(--primary-color-light, #e0f7fa);
  border-radius: 3px;
}

nav::-webkit-scrollbar-thumb:hover {
  background-color: var(--primary-color, #005f73);
}

.sidebar-menu {
  list-style: none;
  padding: 0;
  margin: 0;
}

.sidebar-menu li a {
  display: flex;
  align-items: center;
  padding: 0.75rem 1.25rem; /* Ajuste no padding */
  margin: 0.1rem 0.5rem; /* Espaçamento entre itens e margem lateral */
  color: var(--text-secondary-color, #495057);
  text-decoration: none;
  transition: all 0.2s ease-in-out;
  white-space: nowrap;
  overflow: hidden;
  border-radius: 6px; /* Bordas arredondadas */
  position: relative; /* Para o indicador ::before */
}

.sidebar-menu li a i {
  width: 24px; /* Aumentar um pouco */
  min-width: 24px; /* Garantir largura mínima */
  margin-right: 15px;
  text-align: center;
  font-size: 1.2rem; /* Aumentar um pouco */
  transition: transform 0.2s ease, color 0.2s ease;
}

.menu-text {
    opacity: 1;
    transform: translateX(0);
    transition: opacity 0.2s var(--sidebar-transition-timing) 0.1s, transform 0.2s var(--sidebar-transition-timing) 0.1s;
}

.sidebar.is-collapsed .menu-text {
  opacity: 0;
  transform: translateX(-10px);
  transition: opacity 0.1s ease-out, transform 0.1s ease-out;
  pointer-events: none; /* Evita interação com texto invisível */
}

.sidebar.is-collapsed .sidebar-menu li a {
  justify-content: center;
  padding: 0.75rem 0;
  margin: 0.1rem 0.5rem;
}

.sidebar.is-collapsed .sidebar-menu li a i {
  margin-right: 0;
}

/* --- Efeitos Hover e Active --- */
.sidebar-menu li a:hover {
  background-color: var(--primary-color-light, #e0f7fa);
  color: var(--primary-color, #005f73);
}

.sidebar-menu li a:hover i {
    transform: scale(1.1); /* Leve aumento no hover */
}

.sidebar-menu li a.active {
  background-color: var(--primary-color, #005f73);
  color: #fff;
  font-weight: 500;
  box-shadow: 0 2px 5px rgba(0, 95, 115, 0.2);
}

/* Indicador ativo com ::before */
.sidebar-menu li a.active::before {
    content: '';
    position: absolute;
    left: 0;
    top: 15%;
    bottom: 15%;
    width: 4px;
    background-color: #fff; /* Cor do indicador */
    border-radius: 0 2px 2px 0;
    transition: all 0.2s ease;
}

.sidebar.is-collapsed .sidebar-menu li a.active::before {
    top: 10%;
    bottom: 10%;
    left: 4px; /* Ajuste para colapsado */
}

/* --- Título da Seção --- */
.sidebar-section-title {
  padding: 1.5rem 1.25rem 0.5rem;
  font-size: 0.75rem;
  color: var(--text-muted-color, #adb5bd);
  text-transform: uppercase;
  font-weight: 600;
  letter-spacing: 0.5px;
  white-space: nowrap;
  overflow: hidden;
  display: flex;
  align-items: center;
  transition: opacity 0.2s ease-in-out;
}

.sidebar-section-title i {
    font-size: 1.1rem;
    display: none; /* Escondido por padrão */
}

.sidebar.is-collapsed .sidebar-section-title {
    justify-content: center;
    padding: 1.5rem 0 0.5rem;
}

.sidebar.is-collapsed .sidebar-section-title span {
    display: none;
}
.sidebar.is-collapsed .sidebar-section-title i {
    display: inline-block; /* Mostra ícone quando colapsado */
}

/* --- Link de Logout --- */
.logout-link {
  padding: 0.5rem;
  margin-top: auto; /* Empurra para o final */
  border-top: 1px solid var(--border-color, #e9ecef);
}

.logout-link a {
  display: flex;
  align-items: center;
  padding: 0.75rem 1.25rem;
  margin: 0.1rem 0.5rem;
  color: var(--danger-color, #dc3545);
  text-decoration: none;
  transition: all 0.2s ease-in-out;
  white-space: nowrap;
  overflow: hidden;
  border-radius: 6px;
}

.logout-link a i {
  width: 24px;
  min-width: 24px;
  margin-right: 15px;
  text-align: center;
  font-size: 1.2rem;
  transition: transform 0.2s ease, color 0.2s ease;
}

.sidebar.is-collapsed .logout-link a {
    justify-content: center;
    padding: 0.75rem 0;
}

.sidebar.is-collapsed .logout-link a span {
    display: none;
}

.sidebar.is-collapsed .logout-link a i {
    margin-right: 0;
}

.logout-link a:hover {
  background-color: rgba(220, 53, 69, 0.1);
  color: darken(var(--danger-color, #dc3545), 10%);
}

.logout-link a:hover i {
    transform: scale(1.1);
}

/* --- Estilos Mobile (se usar o mesmo componente) --- */
.sidebar.is-mobile {
    /* Ajustes para quando for usado como sidebar mobile off-canvas */
    position: fixed;
    left: 0;
    top: 0;
    transform: translateX(-100%);
    transition: transform var(--sidebar-transition-duration) var(--sidebar-transition-timing);
    z-index: 1002; /* Acima do overlay */
    /* Garantir que não esteja colapsado por padrão no mobile */
    width: var(--sidebar-width);
}

.sidebar.is-mobile.is-open { /* Classe a ser adicionada via AppLayout */
    transform: translateX(0);
}

/* Esconder botão desktop no mobile */
@media (max-width: 768px) {
  .sidebar:not(.is-mobile) { /* Esconde sidebar desktop padrão */
      display: none;
  }
}

/* Mostrar botão close apenas no mobile */
.sidebar:not(.is-mobile) .sidebar-close-mobile {
    display: none;
}

</style>
