<template>
  <router-view />
</template>

<script setup>
// O App.vue principal geralmente só contém o router-view
// A lógica de layout é movida para AppLayout.vue

// Importar estilos globais aqui se não forem importados no main.js ou index.html
// Exemplo: import '@/assets/css/main.css';

</script>

<style>
/* Estilos globais podem ser colocados aqui ou em um arquivo CSS separado importado */
/* É importante garantir que as variáveis CSS e estilos base do style.css original sejam carregados */
/* Idealmente, mover o conteúdo de assets/css/style.css para src/assets/css/main.css e importá-lo */

/* Exemplo de importação (se o arquivo for movido para src/assets) */
/* @import 
'@/assets/css/style.css
'; */

/* Ou copiar o conteúdo relevante aqui */
:root {
    --primary-color: #005f73;
    --primary-color-light: #e0f7fa;
    --secondary-color: #0a9396;
    --accent-color: #94d2bd;
    --background-color-light: #eef2f5;
    --background-color-dark: #1a1a1a;
    --text-color-light: #333;
    --text-color-dark: #f1f1f1;
    --card-bg-light: #ffffff;
    --card-bg-dark: #2a2a2a;
    --border-color-light: #dee2e6;
    --border-color-dark: #444;
    --sidebar-bg-light: #f8f9fa;
    --sidebar-bg-dark: #222;
    --header-bg-light: #ffffff;
    --header-bg-dark: #252525;
    --danger-color: #dc3545;
    --warning-color: #ffc107;
    --success-color: #28a745;
    --info-color: #17a2b8;

    /* Mapeamento inicial */
    --main-bg-color: var(--background-color-light);
    --text-color: var(--text-color-light);
    --text-secondary-color: #6c757d;
    --card-bg-color: var(--card-bg-light);
    --border-color: var(--border-color-light);
    --sidebar-bg-color: var(--sidebar-bg-light);
    --header-bg-color: var(--header-bg-light);
    --card-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
}

[data-theme="dark"] {
    --main-bg-color: var(--background-color-dark);
    --text-color: var(--text-color-dark);
    --text-secondary-color: #aaa;
    --card-bg-color: var(--card-bg-dark);
    --border-color: var(--border-color-dark);
    --sidebar-bg-color: var(--sidebar-bg-dark);
    --header-bg-color: var(--header-bg-dark);
    --card-shadow: 0 2px 8px rgba(0, 0, 0, 0.4);
}

body {
    margin: 0;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
    background-color: var(--main-bg-color);
    color: var(--text-color);
    transition: background-color 0.3s ease, color 0.3s ease;
}

/* Adicionar outros estilos base globais do style.css original aqui */

/* Estilos para botões, inputs, etc., que devem ser globais */
.btn-primary {
    background-color: var(--primary-color);
    color: white;
    padding: 0.6rem 1.2rem;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    transition: background-color 0.2s ease;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 0.5rem;
}

.btn-primary:hover {
    background-color: #003f5c; /* Escurecer um pouco */
}

.btn-primary:disabled {
    background-color: #ccc;
    cursor: not-allowed;
}

input[type="text"],
input[type="password"],
input[type="email"],
input[type="number"],
select,
textarea {
    width: 100%;
    padding: 0.7rem;
    border: 1px solid var(--border-color);
    border-radius: 4px;
    box-sizing: border-box; /* Importante */
    background-color: var(--card-bg-color); /* Adaptar ao tema */
    color: var(--text-color);
}

/* Garantir que Font Awesome funcione */
@import url("https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css");

</style>
