<template>
  
    <div class="app-layout" style="font-family: 'Inter', sans-serif; background-color: #f4f7fa; color: #333;">
    
    <Sidebar />
    
    <div class="main-content-area" style="padding: 2rem; min-height: 100vh;"  :class="{ 'sidebar-collapsed': isSidebarCollapsed }">
      <!-- Cabeçalho pode ser um componente separado aqui -->
      
    <header class="main-header" style="
        background-color: #ffffff;
        padding: 1rem 2rem;
        box-shadow: 0 4px 6px rgba(0,0,0,0.05);
        display: flex;
        justify-content: space-between;
        align-items: center;
        border-bottom: 1px solid #e0e0e0;
    ">
    
         <!-- Botão de toggle do sidebar para mobile -->
        <button @click="toggleMobileSidebar" class="sidebar-toggle-mobile" aria-label="Menu">
            <i class="fas fa-bars"></i>
        </button>
        <div class="header-content">
            <!-- Conteúdo do cabeçalho (ex: boas vindas, perfil) -->
             <div class="user-welcome">
                <h2>Bem-vindo, <span id="usernameDisplay">{{ userData?.username || 'Usuário' }}</span>!</h2>
                <p class="current-datetime" id="currentDateTime">{{ currentDateTime }}</p>
            </div>
            <div class="user-profile">
                <!-- Dropdown do perfil -->
                 <div class="dropdown">
                    <button class="dropdown-toggle user-button">
                        <i class="fas fa-user-circle"></i>
                        <span id="userRoleDisplay">{{ userData?.role || 'Cargo' }}</span>
                        <i class="fas fa-chevron-down"></i>
                    </button>
                    <ul class="dropdown-menu">
                        <li><a href="#"><i class="fas fa-cog"></i> Configurações</a></li>
                        <li><a href="#"><i class="fas fa-bell"></i> Notificações</a></li>
                        <li><a href="#" @click.prevent="handleLogout"><i class="fas fa-sign-out-alt"></i> Sair</a></li>
                    </ul>
                </div>
            </div>
        </div>
         <!-- Botão de alternância de tema -->
        <button aria-label="Alternar Tema" class="theme-toggle" @click="toggleTheme">
            <i :class="isDarkTheme ? 'fas fa-sun' : 'fas fa-moon'"></i>
        </button>
      </header>
      <main class="content-router-view">
        <router-view v-slot="{ Component }">
          <transition name="fade" mode="out-in">
            <component :is="Component" />
          </transition>
        </router-view>
      </main>
       <!-- ZENVIX SGI Watermark -->
      <div class="soc-watermark">ZENVIX SGI</div>
       <!-- Notification Container -->
      <div id="notification-container"></div>
    </div>
     <!-- Overlay para sidebar mobile -->
    <div v-if="isMobileSidebarOpen" @click="closeMobileSidebar" class="mobile-sidebar-overlay"></div>
     <!-- Sidebar Mobile (pode ser o mesmo componente com props/classes diferentes) -->
    <Sidebar v-if="isMobileSidebarOpen" :is-mobile="true" @close="closeMobileSidebar" />
  </div>
</template>

<script setup>
import { ref, onMounted, computed } from 'vue';
import Sidebar from '../components/Sidebar.vue'; // Corrigido para caminho relativo
import { useRouter } from 'vue-router';
import { getUserData, logout } from '../services/authService'; // Corrigido para caminho relativo

const router = useRouter();
const isSidebarCollapsed = ref(false); // Estado do sidebar desktop
const isMobileSidebarOpen = ref(false); // Estado do sidebar mobile
const isDarkTheme = ref(false);
const currentDateTime = ref('');
const userData = ref(null);

const updateDateTime = () => {
    const now = new Date();
    const options = { 
        weekday: 'long', 
        year: 'numeric', 
        month: 'long', 
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    };
    currentDateTime.value = now.toLocaleDateString('pt-BR', options);
};

const toggleTheme = () => {
  const newTheme = isDarkTheme.value ? 'light' : 'dark';
  document.documentElement.setAttribute('data-theme', newTheme);
  isDarkTheme.value = !isDarkTheme.value;
  localStorage.setItem('theme', newTheme);
};

const checkSystemTheme = () => {
  if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
    return 'dark';
  }
  return 'light';
};

const handleLogout = async () => {
  try {
    await logout();
    router.push('/login');
  } catch (error) {
    console.error('Erro no logout:', error);
    // Mostrar notificação de erro
  }
};

// Lógica para sincronizar estado do sidebar (se necessário)
// Exemplo: ouvir evento do componente Sidebar ou usar store (Pinia/Vuex)
onMounted(() => {
  const savedCollapsedState = localStorage.getItem('sidebarCollapsed');
  if (savedCollapsedState !== null) {
    isSidebarCollapsed.value = JSON.parse(savedCollapsedState);
  }

  // Aplicar tema salvo ou do sistema
  const savedTheme = localStorage.getItem('theme');
  const systemTheme = checkSystemTheme();
  const initialTheme = savedTheme || systemTheme;
  document.documentElement.setAttribute('data-theme', initialTheme);
  isDarkTheme.value = initialTheme === 'dark';

  // Atualizar data/hora
  updateDateTime();
  setInterval(updateDateTime, 60000);

  // Obter dados do usuário
  userData.value = getUserData();
});

// Funções para controlar sidebar mobile
const toggleMobileSidebar = () => {
    isMobileSidebarOpen.value = !isMobileSidebarOpen.value;
};

const closeMobileSidebar = () => {
    isMobileSidebarOpen.value = false;
};

</script>

<style scoped>
.app-layout {
  display: flex;
}

.main-content-area {
  flex-grow: 1;
  margin-left: 250px; /* Largura inicial do sidebar */
  transition: margin-left 0.3s ease;
  position: relative; /* Para watermark e notificações */
  min-height: 100vh;
  background-color: var(--main-bg-color, #eef2f5);
}

.main-content-area.sidebar-collapsed {
  margin-left: 70px; /* Largura do sidebar colapsado */
}

.main-header {
    background-color: var(--header-bg-color, #fff);
    padding: 0.8rem 1.5rem;
    box-shadow: 0 1px 3px rgba(0,0,0,0.1);
    display: flex;
    align-items: center;
    justify-content: space-between;
    position: sticky; /* Fixar cabeçalho */
    top: 0;
    z-index: 999;
}

.header-content {
    display: flex;
    align-items: center;
    flex-grow: 1; /* Ocupa espaço disponível */
    justify-content: space-between; /* Empurra itens para as pontas */
    margin-left: 1rem; /* Espaço após botão mobile */
    margin-right: 1rem; /* Espaço antes do botão de tema */
}

.user-welcome h2 {
    margin: 0;
    font-size: 1.2rem;
    color: var(--text-color);
}
.user-welcome p {
    margin: 0;
    font-size: 0.9rem;
    color: var(--text-secondary-color);
}

/* Estilos Dropdown Perfil */
.user-profile .dropdown {
    position: relative;
}

.user-profile .user-button {
    background: none;
    border: none;
    cursor: pointer;
    display: flex;
    align-items: center;
    gap: 0.5rem;
    color: var(--text-color);
}

.user-profile .user-button i.fa-user-circle {
    font-size: 1.5rem;
}

.user-profile .dropdown-menu {
    display: none; /* Controlado por JS/hover/focus */
    position: absolute;
    right: 0;
    top: 100%;
    background-color: var(--card-bg-color);
    border: 1px solid var(--border-color);
    border-radius: 4px;
    box-shadow: 0 4px 8px rgba(0,0,0,0.1);
    list-style: none;
    padding: 0.5rem 0;
    margin: 0.5rem 0 0 0;
    min-width: 160px;
    z-index: 1000;
}

.user-profile .dropdown:hover .dropdown-menu,
.user-profile .dropdown:focus-within .dropdown-menu {
    display: block;
}

.user-profile .dropdown-menu li a {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    padding: 0.5rem 1rem;
    color: var(--text-color);
    text-decoration: none;
    white-space: nowrap;
}

.user-profile .dropdown-menu li a:hover {
    background-color: var(--primary-color-light);
}

.user-profile .dropdown-menu li a i {
    width: 16px;
    text-align: center;
}

.content-router-view {
  padding: 1.5rem;
}

/* Estilos para transição de rota */
.fade-enter-active,
.fade-leave-active {
  transition: opacity 0.3s ease;
}

.fade-enter-from,
.fade-leave-to {
  opacity: 0;
}

/* Botão de toggle mobile */
.sidebar-toggle-mobile {
    display: none; /* Escondido por padrão */
    background: none;
    border: none;
    font-size: 1.5rem;
    cursor: pointer;
    color: var(--text-color);
}

/* Watermark e Notificações (posicionamento) */
.soc-watermark {
    position: fixed;
    bottom: 10px;
    left: calc(70px + 10px); /* Ajustar com base na largura do sidebar colapsado */
    font-size: 0.8rem;
    color: rgba(0, 0, 0, 0.15);
    z-index: 1;
    pointer-events: none;
    transition: left 0.3s ease;
}
.main-content-area:not(.sidebar-collapsed) .soc-watermark {
    left: calc(250px + 10px); /* Ajustar com base na largura do sidebar expandido */
}

#notification-container {
    position: fixed;
    top: 80px; /* Abaixo do header */
    right: 20px;
    z-index: 1050;
    width: 300px;
}

.theme-toggle {
    background: none;
    border: 1px solid #ccc;
    border-radius: 50%;
    width: 35px;
    height: 35px;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
}

/* Overlay para sidebar mobile */
.mobile-sidebar-overlay {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, 0.5);
    z-index: 1001; /* Abaixo do sidebar mobile, acima do conteúdo */
    display: none; /* Controlado por v-if */
}

/* Estilos para Mobile */
@media (max-width: 768px) {
  .main-content-area {
    margin-left: 0; /* Sidebar some ou fica por cima */
  }
  .main-content-area.sidebar-collapsed {
    margin-left: 0;
  }
  .sidebar-toggle-mobile {
    display: block; /* Mostra o botão em mobile */
  }
  .header-content {
      margin-left: 0.5rem;
  }
  .soc-watermark {
      left: 10px; /* Ajuste para mobile */
  }
  /* Adicionar estilos para sidebar mobile (ex: off-canvas) */
  /* .sidebar { position: fixed; transform: translateX(-100%); } */
  /* .sidebar.is-mobile-open { transform: translateX(0); } */
  .mobile-sidebar-overlay[style*="display: block"] { /* Mostrar overlay quando sidebar mobile estiver aberto */
      display: block;
  }
}

</style>
